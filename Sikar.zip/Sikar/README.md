# Sikar — Kasir, Stok & Laba untuk Toko Kecil

Aplikasi kasir (POS) berbasis web yang **jalan tanpa server, tanpa langganan, dan tanpa internet**.
Buka `index.html` (klik dua kali) — langsung bisa jualan. Data tersimpan di perangkat, bukan di cloud.

Dibuat untuk toko/warung/kafe kecil yang butuh **angka akurat** (laba, bukan cuma omzet) tanpa
biaya bulanan dan tanpa instalasi.

---

## 1. Kenapa Sikar

Kebanyakan aplikasi kasir gratis memberi tahu **berapa uang masuk**. Yang bikin untung atau rugi
justru **berapa yang tersisa setelah modal**. Sikar menyimpan HPP di setiap produk dan setiap baris
transaksi, jadi:

- **Laba kotor** dihitung otomatis (omzet − HPP − pajak).
- **Produk rugi** (dijual di bawah modal) ditandai merah di laporan.
- **Barang mati** (tidak laku) dihitung berikut modal yang tertahan di rak.
- **Analisis ABC**: 20% produk yang menyumbang 80% omzet.
- **Selisih kas** saat tutup toko kelihatan per shift, bukan cuma "total penjualan".

Semua jalan di browser, termasuk **ekspor Excel asli (.xlsx)** dan **cetak struk thermal 58/80 mm**.

---

## 2. Cara menjalankan

**Cara cepat (paling simpel):**

1. Buka folder ini.
2. Klik dua kali `index.html`.
3. Selesai — data tersimpan di browser (Chrome/Edge/Firefox).

**Cara kedua (disarankan kalau mau bisa "Install app" / offline penuh / kamera scan):**

```bash
cd "Sikar"
python -m http.server 8099
```

Lalu buka `http://127.0.0.1:8099`. Dari menu browser pilih **Install app / Tambahkan ke layar utama**.
Service worker akan menyimpan seluruh aplikasi sehingga tetap terbuka walau internet mati.

> Catatan: kamera barcode & PWA butuh `http://` atau `https://`. Kalau dibuka lewat `file://`,
> semuanya tetap jalan kecuali dua hal itu (barcode bisa diketik manual atau pakai scanner USB).

---

## 3. Fitur

### Kasir (layar utama)
- Grid produk + pencarian instan + filter kategori.
- **Scan barcode**: kamera (BarcodeDetector) atau **scanner USB** — cukup tembak ke halaman kasir,
  tidak perlu klik apa pun.
- Keranjang dengan qty, diskon per item, catatan pesanan, dan pelanggan.
- **Diskon pesanan** (rupiah atau persen) + keterangan.
- **Split payment**: satu transaksi bisa dibayar tunai + QRIS + debit sekaligus, sisa tagihan
  otomatis menyesuaikan.
- **Bon / piutang** untuk pelanggan langganan (otomatis masuk buku bon).
- **Tahan pesanan (open bill)** — F4, lanjutkan kapan saja.
- Pembayaran cepat: tombol uang pas, 5rb/10rb/50rb/100rb, kembalian besar.
- Keranjang **tersimpan walau halaman ditutup** atau tidak sengaja ter-refresh.
- Peringatan kalau shift belum dibuka.
- Tampilan HP: keranjang jadi bottom sheet, target tombol besar.

### Struk & printer
- Cetak lewat dialog browser: ukuran **58 mm** atau **80 mm**, font monospace, rapi.
- **ESC/POS langsung ke printer thermal USB** (Web Serial) — tanpa driver tambahan di Chrome/Edge desktop.
- Kirim struk ke **WhatsApp** (teks) atau salin ke clipboard.
- QRIS toko bisa diunggah dan tampil di layar pembayaran + struk.
- **Z-report** saat tutup kasir.

### Produk
- CRUD produk: nama, kategori, barcode/SKU, harga jual, **HPP**, stok, stok minimum, satuan.
- Margin per produk langsung dihitung (peringatan kalau di bawah modal).
- **Impor massal** tempel dari Excel/CSV, **ekspor CSV**.
- Produk yang sudah pernah terjual dinonaktifkan, bukan dihapus — riwayat tetap utuh.

### Stok
- **Batch & kedaluwarsa** dengan **FEFO**: batch yang paling cepat kedaluwarsa otomatis keluar lebih dulu.
- **Stok masuk** per supplier; HPP dihitung ulang sebagai **rata-rata tertimbang**.
- **Stok opname** dengan selisih dan alasan.
- **Kartu stok**: seluruh mutasi (jual, masuk, opname, void, refund) + saldo berjalan.
- Peringatan stok kritis & batch yang hampir kedaluwarsa (30 hari).

### Laporan
- Periode: hari ini, 7/30/90 hari, bulan ini, semua.
- KPI: omzet, **laba kotor**, transaksi, rata-rata keranjang, tunai vs non-tunai.
- Grafik omzet harian + laba, heatmap jam sibuk, kontribusi kategori, metode pembayaran.
- Produk terlaris, produk rugi, barang mati + modal tertahan, analisis ABC.
- **Ekspor Excel 5 sheet**: Ringkasan, Harian, Produk, Transaksi, Stok (angka asli, bukan teks).
- Cetak ringkasan 80 mm.

### Shift kasir
- Buka kasir dengan **modal awal**.
- Ringkasan langsung: omzet shift, tunai, non-tunai, **kas seharusnya**.
- Tutup kasir dengan **hitungan per pecahan** (100rb … 100) → total, selisih, Z-report.
- Riwayat shift + selisih tiap shift (untuk serah-terima antar kasir).

### Pelanggan
- Member dengan poin (1 poin / Rp 10.000), nomor HP, catatan.
- Buku **bon/piutang** + pembayaran bon.
- Riwayat transaksi & riwayat bon per pelanggan.

### Keamanan & data
- **PIN pemilik** (bawaan `1234`) untuk void, refund, reset data.
- Refund sebagian/penuh dengan pengembalian stok otomatis.
- Void wajib alasan + tercatat siapa dan kapan.
- **Backup JSON** (unduh) dan **restore**.
- Data demo bisa dimuat ulang atau dikosongkan untuk mulai toko asli.
- Tema terang/gelap.

---

## 4. Alur harian yang disarankan

1. **Pagi** — Shift kasir → *Buka kasir*, isi modal awal (uang kembalian di laci).
2. **Jualan** — klik produk / scan barcode → F2 → pilih metode → selesai → cetak struk.
3. **Barang datang** — Stok → *Stok masuk*: qty, HPP baru, tanggal kedaluwarsa, supplier.
4. **Sore** — cek Stok (barang kritis) dan Laporan (laba, barang mati).
5. **Tutup** — Shift kasir → *Tutup kasir*, hitung pecahan, cetak Z-report.
6. **Mingguan** — Pengaturan → *Unduh backup (.json)*.

---

## 5. Pintasan keyboard

| Tombol | Fungsi |
|---|---|
| `F1` | Ke layar kasir |
| `F2` | Buka pembayaran |
| `F3` | Fokus kolom cari / scan |
| `F4` | Tahan pesanan (open bill) |
| `Alt` + `1…7` | Pindah menu |
| `Enter` | Tambah produk teratas / selesaikan pembayaran |
| `Esc` | Tutup dialog / keranjang HP |
| `?` | Panduan |

Scanner barcode USB bekerja seperti keyboard: tembak ke halaman kasir, kode langsung masuk.

---

## 6. Data, batas, dan kebiasaan aman

- Data disimpan di **localStorage** browser ini (satu perangkat, satu browser).
- Ukuran data demo ± 260 KB untuk 380 transaksi → kira-kira muat **5.000–7.000 transaksi**
  sebelum mendekati batas 5 MB. Setelah itu: unduh backup, lalu arsipkan.
- **Jangan pakai mode Incognito** — data hilang saat tab ditutup.
- Ganti browser/profil = data tidak ikut. Pindah perangkat: **backup → restore**.
- Dua tab bisa dibuka bersamaan (sinkron lewat BroadcastChannel), tapi jangan dipakai dua kasir
  pada dua perangkat sekaligus — ini aplikasi lokal, bukan multi-server.
- PIN bawaan `1234`. Ganti di **Pengaturan → Keamanan** sebelum dipakai jualan beneran.

---

## 7. Struktur berkas

```
index.html                 kerangka: rail, topbar, sprite ikon SVG
manifest.webmanifest       metadata PWA (install ke layar utama)
sw.js                      service worker: cache offline
assets/
  icon.svg, icon-192.png, icon-512.png
  css/
    tokens.css             warna, tipe, jarak, radius (tema terang/gelap)
    base.css               reset, utilitas, aturan cetak
    layout.css             shell aplikasi & responsif
    components.css         tombol, kartu, tabel, form, modal, toast
    views.css              tampilan kasir, struk, grafik, shift
  js/
    util.js                format rupiah, tanggal, modal, toast, unduhan
    xlsx.js                penulis .xlsx (ZIP + OOXML) tanpa pustaka
    seed.js                data demo deterministik (PRNG bersemai)
    store.js               state, transaksi, stok, shift, laporan
    print.js               struk 58/80mm, teks WA, Z-report, ESC/POS
    scan.js                kamera barcode + scanner USB
    views/kasir.js         layar transaksi & pembayaran
    views/katalog.js       produk, impor/ekspor
    views/stok.js          stok masuk, opname, kartu stok
    views/riwayat.js       transaksi, refund/void, pelanggan
    views/laporan.js       KPI, grafik, ABC, ekspor Excel
    views/shift.js         buka/tutup kasir, Z-report
    views/pengaturan.js    toko, pajak, QRIS, PIN, backup
    app.js                 rute, tema, pintasan, PWA
```

Tanpa build step, tanpa framework, tanpa CDN. Semua ikon berupa sprite SVG di `index.html`,
font memakai font sistem.

---

## 8. Hasil pengujian (bukan klaim)

Diuji langsung di Chrome lewat CDP:

- Semua 7 layar render tanpa error konsol, tanpa overflow horizontal di 390 / 1024 / 1258 px.
- Transaksi uji: keranjang Rp 6.000 → bayar uang pas → tersimpan, stok 140 → 139.
- Split payment: tunai 5.000 + QRIS 1.000 untuk total 6.000, kembalian 0.
- Diskon 10% pada Rp 5.000 → total Rp 4.500.
- Bon pelanggan: piutang 0 → Rp 4.500 dan tercatat di buku bon.
- Refund 1 item membuat transaksi refund negatif dan stok kembali.
- Void dengan PIN salah ditolak, PIN benar membatalkan dan stok pulih (26 → 27).
- FEFO: batch kedaluwarsa terdekat berkurang lebih dulu.
- HPP rata-rata: 14 × 62.000 + 10 × 64.000 → 62.833 (sesuai hitungan manual).
- Pajak 11% + pembulatan: 6.000 → 660 → total 6.700.
- Tutup kasir: kas seharusnya Rp 425.500, hitung otomatis = pas, selisih 0, Z-report muncul.
- Ekspor Excel: ZIP valid (`testzip` bersih), 5 sheet, dibaca openpyxl, nomor & tanggal berformat,
  omzet/laba/HPP konsisten dengan layar.
- ESC/POS: byte diawali `1B 40`, diakhiri perintah cut `1D 56 42 00`.
- `file://` (klik dua kali) jalan: 43 produk tampil, localStorage aktif.
- Persistensi: reload → 380 transaksi, 1 void, shift aktif tetap ada.

---

## 9. Kustomisasi cepat

- **Warna & radius**: `assets/css/tokens.css` (satu variabel `--accent` mengubah seluruh aksen).
- **Nama toko, alamat, footer struk**: Pengaturan (tanpa sentuh kode).
- **Data demo**: Pengaturan → *Muat demo* / *Mulai dari kosong*.
- **Lebar struk**: Pengaturan → 58/80 mm.
- **Pajak & service**: Pengaturan → persentase + sakelar.

---

## 10. Lisensi

Kode ditulis untuk dipakai dan dijual bebas oleh pemiliknya. Tidak ada dependensi pihak ketiga,
tidak ada telemetri, tidak ada panggilan jaringan sama sekali saat dipakai.
