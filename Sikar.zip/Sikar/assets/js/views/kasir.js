/* ============================================================
   views/kasir.js — layar transaksi (POS)
   ============================================================ */
(function (global) {
  'use strict';

  let R = null;
  const K = {
    q: '', cat: 'Semua', cart: [], pelangganId: null, catatan: '',
    diskonTipe: 'nominal', diskonNilai: 0, diskonKet: ''
  };

  function simpan() {
    Store.simpanKeranjang({
      cart: K.cart, pelangganId: K.pelangganId, catatan: K.catatan,
      diskonTipe: K.diskonTipe, diskonNilai: K.diskonNilai, diskonKet: K.diskonKet
    });
  }

  function total() {
    return Store.hitung(K.cart.map(x => ({ ...x, harga: harga(x), qty: x.qty })), {
      diskonTipe: K.diskonTipe, diskonNilai: K.diskonNilai
    });
  }

  function harga(it) {
    const p = Store.p(it.pid);
    return p ? Number(p.harga) || 0 : Number(it.harga) || 0;
  }

  function produkList() {
    let list = Store.s.produk.filter(p => p.aktif !== false);
    if (K.cat !== 'Semua') list = list.filter(p => (p.kategori || 'Lainnya') === K.cat);
    const q = K.q.toLowerCase().trim();
    if (q) {
      list = list.filter(p => (p.nama + ' ' + (p.kategori || '') + ' ' + (p.barcode || '')).toLowerCase().includes(q));
    }
    return list;
  }

  function renderKategori() {
    const cats = ['Semua'].concat(Store.kategori());
    const el = R.querySelector('#k-kategori');
    el.innerHTML = cats.map(c =>
      '<button class="chip ' + (K.cat === c ? 'is-active' : '') + '" data-act="cat" data-cat="' + Util.esc(c) + '">' +
      Util.esc(c) + '</button>').join('');
  }

  function renderProduk() {
    const list = produkList();
    const el = R.querySelector('#k-produk');
    if (!list.length) {
      el.innerHTML = '<div class="empty" style="grid-column:1/-1">' + Util.icon('search') +
        '<strong>Tidak ada produk</strong><p>Coba kata kunci lain, atau tambah produk baru di menu Produk.</p></div>';
      return;
    }
    el.innerHTML = list.slice(0, 200).map(p => {
      const stok = Number(p.stok) || 0;
      const cls = stok <= 0 ? 'out' : (stok <= Number(p.minStok || 0) ? 'low' : '');
      return '<button class="pcard ' + (stok <= 0 ? 'is-out' : '') + '" data-act="add" data-pid="' + p.id + '" title="' + Util.esc(p.nama) + '">' +
        '<span class="pcard-stok ' + cls + '">' + (stok <= 0 ? 'habis' : stok) + '</span>' +
        '<span class="pcard-name">' + Util.esc(p.nama) + '</span>' +
        '<span class="pcard-meta">' + Util.esc(p.kategori || '') + '</span>' +
        '<span class="pcard-price">' + Util.rp(p.harga) + '</span>' +
        '</button>';
    }).join('');
  }

  function renderCart() {
    const items = R.querySelector('#k-items');
    const sum = R.querySelector('#k-sum');
    const jml = R.querySelector('#k-jumlah');
    const t = total();
    jml.textContent = t.qty + ' item';

    if (!K.cart.length) {
      items.innerHTML = '<div class="empty" style="padding:36px 12px">' + Util.icon('cart') +
        '<strong>Belum ada item</strong><p>Pilih produk di kiri, atau scan barcode.</p></div>';
    } else {
      items.innerHTML = K.cart.map((it, i) => {
        const p = Store.p(it.pid);
        const h = harga(it);
        const stok = p ? Number(p.stok) : 0;
        const lebih = p && it.qty > stok;
        return '<div class="cart-row" data-idx="' + i + '">' +
          '<div class="cr-top"><div style="min-width:0">' +
          '<div class="cr-name">' + Util.esc(p ? p.nama : it.nama) + '</div>' +
          '<div class="cr-sub">' + it.qty + ' × ' + Util.rp(h) +
          (it.diskon ? ' · diskon ' + Util.rp(it.diskon) : '') +
          (lebih ? ' · <span style="color:var(--warn)">stok ' + stok + '</span>' : '') +
          '</div></div>' +
          '<div class="cr-total">' + Util.rp(h * it.qty - (it.diskon || 0)) + '</div></div>' +
          '<div class="cr-bot">' +
          '<div class="qty"><button data-act="qty-" data-idx="' + i + '" aria-label="Kurangi">' + Util.icon('minus') + '</button>' +
          '<span>' + it.qty + '</span>' +
          '<button data-act="qty+" data-idx="' + i + '" aria-label="Tambah">' + Util.icon('plus') + '</button></div>' +
          '<div class="cr-tools">' +
          '<button class="btn-icon" data-act="item-disc" data-idx="' + i + '" title="Diskon item">' + Util.icon('tag') + '</button>' +
          '<button class="btn-icon" data-act="item-del" data-idx="' + i + '" title="Hapus">' + Util.icon('x') + '</button>' +
          '</div></div></div>';
      }).join('');
    }

    let h = '<div class="sum-row"><span>Subtotal</span><span class="v">' + Util.rp(t.subtotal) + '</span></div>';
    if (t.diskon > 0) {
      h += '<div class="sum-row"><span>Diskon ' + (K.diskonTipe === 'persen' ? K.diskonNilai + '%' : '') +
        ' <button class="sum-link" data-act="diskon">ubah</button></span><span class="v">−' + Util.rp(t.diskon) + '</span></div>';
    }
    if (t.service) h += '<div class="sum-row"><span>Service ' + Store.s.toko.service + '%</span><span class="v">' + Util.rp(t.service) + '</span></div>';
    if (t.pajak) h += '<div class="sum-row"><span>Pajak ' + Store.s.toko.pajak + '%</span><span class="v">' + Util.rp(t.pajak) + '</span></div>';
    if (t.pembulatan) h += '<div class="sum-row"><span>Pembulatan</span><span class="v">' + Util.rp(t.pembulatan) + '</span></div>';
    h += '<div class="sum-row total"><span>Total</span><span class="v">' + Util.rp(t.total) + '</span></div>';
    sum.innerHTML = h;

    R.querySelector('#k-total').textContent = Util.rp(t.total);
    const mbar = document.getElementById('mbar-total');
    if (mbar) mbar.textContent = Util.rp(t.total);
    const mq = document.getElementById('mbar-qty');
    if (mq) mq.textContent = t.qty;

    const hc = R.querySelectorAll('[data-act="tahan-list"]');
    hc.forEach(b => { b.dataset.count = Store.s.tahan.length; });
    const badge = R.querySelector('#k-hold-badge');
    if (badge) { badge.textContent = Store.s.tahan.length; badge.hidden = !Store.s.tahan.length; }
    const warn = R.querySelector('#k-shift-warn');
    if (warn) warn.hidden = !!Store.shiftAktif();
    simpan();
  }

  function renderPelanggan() {
    const sel = R.querySelector('#k-pelanggan');
    if (!sel) return;
    const cur = K.pelangganId || '';
    sel.innerHTML = '<option value="">Pelanggan umum</option>' +
      Store.s.pelanggan.map(c => '<option value="' + c.id + '"' + (c.id === cur ? ' selected' : '') + '>' +
        Util.esc(c.nama) + (c.piutang ? ' · bon ' + Util.rp(c.piutang) : '') + '</option>').join('');
    if (!Store.s.pelanggan.some(c => c.id === cur)) K.pelangganId = null;
  }

  function add(pid, qty) {
    const p = Store.p(pid);
    if (!p) return;
    qty = qty || 1;
    const ada = K.cart.find(x => x.pid === pid);
    if (ada) ada.qty += qty;
    else K.cart.push({ pid, nama: p.nama, harga: p.harga, qty, diskon: 0 });
    if (Number(p.stok) <= 0) Util.toast(p.nama + ': stok tercatat habis', 'warn', 2200);
    renderCart();
  }

  /* ---------------- pembayaran ---------------- */
  function bukaBayar() {
    if (!K.cart.length) { Util.toast('Keranjang masih kosong', 'warn'); return; }
    const t = total();
    const pel = K.pelangganId ? Store.pel(K.pelangganId) : null;
    const P = {
      rows: [{ metode: 'Tunai', nominal: 0, auto: false }],
      qris: !!Store.s.toko.qris
    };

    const metodeList = [
      { id: 'Tunai', ic: 'wallet' },
      { id: 'QRIS', ic: 'barcode' },
      { id: 'Debit', ic: 'tag' },
      { id: 'E-Wallet', ic: 'bolt' },
      { id: 'Transfer', ic: 'share' },
      { id: 'Bon', ic: 'receipt' }
    ];

    const body =
      '<div class="pay-wrap">' +
      '<div>' +
      '<div class="pay-total"><div><div class="lbl">Total tagihan</div><div class="val">' + Util.rp(t.total) + '</div></div>' +
      '<div class="right tiny muted">' + t.qty + ' item' + (pel ? '<br>' + Util.esc(pel.nama) : '') + '</div></div>' +

      '<div class="field"><span class="label">Metode pembayaran</span>' +
      '<div class="metode-grid">' + metodeList.map(m =>
        '<button class="metode' + (m.id === 'Tunai' ? ' is-active' : '') + '" data-metode="' + m.id + '"' +
        (m.id === 'Bon' && !pel ? ' disabled style="opacity:.45"' : '') + '>' +
        Util.icon(m.ic) + '<span>' + m.id + '</span></button>').join('') +
      '</div></div>' +

      '<div id="pay-rows" class="col mt-4" style="gap:8px"></div>' +
      '<div class="row mt-3"><button class="btn btn-sm" data-act="tambah-baris">' + Util.icon('plus') + ' Metode lain (split)</button>' +
      '<span class="grow"></span><span class="hint" id="sisa-bayar"></span></div>' +
      '</div>' +

      '<div class="col" style="gap:10px">' +
      '<div class="field"><span class="label">Uang diterima</span>' +
      '<input id="pay-nominal" class="input input-lg input-money" inputmode="numeric" placeholder="0" autocomplete="off"></div>' +
      '<div class="quick-cash" id="quick-cash"></div>' +
      '<div class="kembalian" id="kembalian"><span class="lbl">Kembalian</span><span class="val">Rp 0</span></div>' +
      '<div id="qris-box"></div>' +
      '<p class="hint">F2 / Enter untuk menyelesaikan. Esc membatalkan.</p>' +
      '</div></div>';

    const h = Util.modal({
      title: 'Pembayaran',
      sub: 'No. ' + Store.nextNo(),
      wide: true,
      body,
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        { label: 'Selesaikan', class: 'btn-primary', icon: 'check', onClick: (node, close) => selesai(node, close) }
      ],
      onMount: (node) => wire(node)
    });

    function wire(node) {
      const inp = node.querySelector('#pay-nominal');
      Util.moneyInput(inp, () => { P.rows[0].nominal = Util.parseNum(inp.value); sync(); });

      node.querySelectorAll('[data-metode]').forEach(btn => {
        btn.addEventListener('click', () => {
          P.rows[0].metode = btn.dataset.metode;
          node.querySelectorAll('[data-metode]').forEach(b => b.classList.toggle('is-active', b === btn));
          if (P.rows[0].metode !== 'Tunai') P.rows[0].nominal = t.total;
          else P.rows[0].nominal = 0;
          inp.value = P.rows[0].nominal ? Util.num(P.rows[0].nominal) : '';
          sync();
        });
      });

      node.querySelector('[data-act="tambah-baris"]').addEventListener('click', () => {
        P.rows.push({
          metode: 'QRIS',
          nominal: Math.max(0, t.total - Util.sum(P.rows, r => r.nominal)),
          auto: true
        });
        renderRows(node, t, P, sync);
        sync();
      });

      renderRows(node, t, P, sync);
      sync();
      setTimeout(() => inp.focus(), 60);

      node.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); selesai(node, h.close); }
      });
    }

    function sync() {
      const node = h.node;
      // baris yang belum disentuh user otomatis menutup sisa tagihan
      P.rows.forEach((r, i) => {
        if (i > 0 && r.auto) {
          const lain = Util.sum(P.rows.filter((_, k) => k !== i), x => x.nominal);
          r.nominal = Math.max(0, t.total - lain);
          const inp = node.querySelector('[data-row-nominal="' + i + '"]');
          if (inp && document.activeElement !== inp) inp.value = r.nominal ? Util.num(r.nominal) : '';
        }
      });
      const dibayar = Util.sum(P.rows, r => r.nominal);
      const sisa = t.total - dibayar;
      const kem = dibayar - t.total;
      const kb = node.querySelector('#kembalian');
      kb.className = 'kembalian ' + (kem >= 0 ? 'ok' : 'kurang');
      kb.innerHTML = '<span class="lbl">' + (kem >= 0 ? 'Kembalian' : 'Kurang') + '</span>' +
        '<span class="val">' + Util.rp(Math.abs(kem)) + '</span>';
      node.querySelector('#sisa-bayar').textContent = sisa > 0 ? 'Sisa ' + Util.rp(sisa) : 'Lunas';
      const qc = node.querySelector('#quick-cash');
      const nominal = P.rows[0].metode === 'Tunai' ? t.total : t.total;
      const opsi = [nominal, Math.ceil(nominal / 5000) * 5000, Math.ceil(nominal / 10000) * 10000, Math.ceil(nominal / 50000) * 50000, 100000]
        .filter((v, i, a) => a.indexOf(v) === i && v >= nominal).slice(0, 4);
      qc.innerHTML = opsi.map(v => '<button class="qcash" data-cash="' + v + '">' + (v === nominal ? 'Uang pas' : Util.num(v)) + '</button>').join('');
      qc.querySelectorAll('[data-cash]').forEach(b => {
        b.addEventListener('click', () => {
          P.rows[0].nominal = Number(b.dataset.cash);
          const inp = node.querySelector('#pay-nominal');
          inp.value = Util.num(P.rows[0].nominal);
          sync();
        });
      });
      const qb = node.querySelector('#qris-box');
      if (P.rows[0].metode === 'QRIS' && Store.s.toko.qris) {
        qb.innerHTML = '<div class="qr-preview" style="width:100%;height:auto;padding:8px;border-style:solid">' +
          '<img src="' + Store.s.toko.qris + '" alt="QRIS" style="width:100%;height:auto"></div>' +
          '<p class="hint mt-2">Tunjukkan ke pelanggan, lalu tekan Selesaikan setelah dibayar.</p>';
      } else qb.innerHTML = '';
      const footer = node.querySelector('.modal-foot .btn-primary');
      if (footer) footer.disabled = dibayar < t.total;
    }

    function selesai(node, close) {
      const dibayar = Util.sum(P.rows, r => r.nominal);
      if (dibayar < t.total) { Util.toast('Pembayaran kurang ' + Util.rp(t.total - dibayar), 'err'); return; }
      if (P.rows.some(r => r.metode === 'Bon') && !K.pelangganId) { Util.toast('Pilih pelanggan dulu untuk bon', 'err'); return; }
      const kurang = K.cart.filter(it => { const p = Store.p(it.pid); return p && it.qty > Number(p.stok); });
      const kirim = (izinkanMinus) => {
        const res = Store.jual({
          items: K.cart, pelangganId: K.pelangganId, catatan: K.catatan,
          diskonTipe: K.diskonTipe, diskonNilai: K.diskonNilai, diskonKet: K.diskonKet,
          bayar: P.rows, izinkanMinus
        });
        if (!res.ok) {
          if (res.kurangStok && !izinkanMinus) {
            Util.confirm({
              title: 'Stok tidak cukup',
              body: res.error + '. Tetap jual? Stok akan tercatat minus dan bisa diperbaiki lewat Stok Opname.',
              ok: 'Tetap jual', danger: true
            }).then(yes => { if (yes) kirim(true); });
            return;
          }
          Util.toast(res.error, 'err', 4000);
          return;
        }
        close();
        K.cart = []; K.diskonNilai = 0; K.diskonTipe = 'nominal'; K.diskonKet = '';
        K.pelangganId = null; K.catatan = '';
        const note = R.querySelector('#k-catatan'); if (note) note.value = '';
        Store.hapusKeranjang();
        renderCart(); renderPelanggan();
        tutupSheet();
        sukses(res.sale);
      };
      if (kurang.length) { /* stok kurang: Store.jual akan mengembalikan kurangStok */ }
      kirim(false);
    }
  }

  function renderRows(node, t, P, sync) {
    const wrap = node.querySelector('#pay-rows');
    wrap.innerHTML = P.rows.map((r, i) =>
      '<div class="row row-tight" data-row="' + i + '">' +
      '<select class="select" style="width:132px" data-row-metode="' + i + '">' +
      ['Tunai', 'QRIS', 'Debit', 'E-Wallet', 'Transfer', 'Bon'].map(m =>
        '<option' + (m === r.metode ? ' selected' : '') + '>' + m + '</option>').join('') +
      '</select>' +
      '<input class="input input-money" data-row-nominal="' + i + '" value="' + (r.nominal ? Util.num(r.nominal) : '') + '" placeholder="0" inputmode="numeric">' +
      (P.rows.length > 1 ? '<button class="btn-icon" data-row-del="' + i + '" aria-label="Hapus">' + Util.icon('x') + '</button>' : '') +
      '</div>').join('');

    wrap.querySelectorAll('[data-row-metode]').forEach(sel => {
      sel.addEventListener('change', () => {
        const i = Number(sel.dataset.rowMetode);
        P.rows[i].metode = sel.value;
        if (sel.value !== 'Tunai') {
          P.rows[i].nominal = Math.max(0, t.total - Util.sum(P.rows.filter((_, k) => k !== i), r => r.nominal));
          P.rows[i].auto = true;
          const inp = wrap.querySelector('[data-row-nominal="' + i + '"]');
          inp.value = Util.num(P.rows[i].nominal);
        }
        sync();
      });
    });
    wrap.querySelectorAll('[data-row-nominal]').forEach(inp => {
      const i = Number(inp.dataset.rowNominal);
      Util.moneyInput(inp, () => { P.rows[i].nominal = Util.parseNum(inp.value); P.rows[i].auto = false; sync(); });
    });
    wrap.querySelectorAll('[data-row-del]').forEach(btn => {
      btn.addEventListener('click', () => {
        P.rows.splice(Number(btn.dataset.rowDel), 1);
        renderRows(node, t, P, sync); sync();
      });
    });
  }

  function sukses(sale) {
    const t = Store.s.toko;
    const h = Util.modal({
      title: 'Transaksi selesai',
      sub: sale.no + ' · ' + Util.fmtTime(sale.at),
      body:
        '<div class="row" style="gap:14px;align-items:flex-start">' +
        '<div class="grow">' +
        '<div class="kpi kpi-accent"><div class="kpi-label">Total dibayar</div>' +
        '<div class="kpi-value">' + Util.rp(sale.total) + '</div>' +
        '<div class="kpi-sub">' + (sale.kembali ? 'Kembalian ' + Util.rp(sale.kembali) : 'Uang pas') + '</div></div>' +
        '<div class="col mt-3" style="gap:8px">' +
        '<button class="btn btn-block" data-act="cetak">' + Util.icon('printer') + ' Cetak struk</button>' +
        '<button class="btn btn-block" data-act="wa">' + Util.icon('share') + ' Kirim ke WhatsApp</button>' +
        '<button class="btn btn-block" data-act="thermal">' + Util.icon('bolt') + ' Printer thermal (USB)</button>' +
        '<button class="btn btn-block btn-ghost" data-act="salin">' + Util.icon('copy') + ' Salin struk</button>' +
        '</div></div>' +
        '<div style="width:250px;flex:0 0 auto"><div class="struk">' + Print.receiptDoc(sale, { qris: true }) + '</div></div>' +
        '</div>',
      wide: true,
      actions: [
        { label: 'Transaksi baru', class: 'btn-primary', icon: 'plus' }
      ],
      onMount: (node) => {
        node.querySelector('[data-act="cetak"]').addEventListener('click', () => Print.struk(sale));
        node.querySelector('[data-act="wa"]').addEventListener('click', () => Util.shareText(Print.text(sale), 'Struk ' + sale.no));
        node.querySelector('[data-act="thermal"]').addEventListener('click', () => Print.printESC(sale));
        node.querySelector('[data-act="salin"]').addEventListener('click', () =>
          Util.copy(Print.text(sale)).then(() => Util.toast('Struk disalin')));
      }
    });
    return h;
  }

  /* ---------------- diskon ---------------- */
  function bukaDiskon() {
    const t = total();
    const body =
      '<div class="seg" id="d-tipe"><button class="seg-btn ' + (K.diskonTipe === 'nominal' ? 'is-active' : '') + '" data-tipe="nominal">Rupiah</button>' +
      '<button class="seg-btn ' + (K.diskonTipe === 'persen' ? 'is-active' : '') + '" data-tipe="persen">Persen</button></div>' +
      '<div class="field mt-4"><label class="label" for="d-nilai">Nilai diskon</label>' +
      '<input id="d-nilai" class="input input-lg ' + (K.diskonTipe === 'nominal' ? 'input-money' : '') + '" value="' + (K.diskonNilai || '') + '" inputmode="numeric"></div>' +
      '<div class="field mt-3"><label class="label" for="d-ket">Keterangan (opsional)</label>' +
      '<input id="d-ket" class="input" value="' + Util.esc(K.diskonKet || '') + '" placeholder="mis. promo pelajar"></div>' +
      '<div class="alert-strip info mt-4">' + Util.icon('tag') + '<span class="grow">Subtotal ' + Util.rp(t.subtotal) +
      ' · setelah diskon ' + Util.rp(Math.max(0, t.subtotal - (K.diskonTipe === 'persen' ? Math.round(t.subtotal * K.diskonNilai / 100) : K.diskonNilai))) + '</span></div>';
    Util.modal({
      title: 'Diskon pesanan', narrow: true, body,
      actions: [
        { label: 'Hapus diskon', class: 'btn-ghost', onClick: (n, close) => { K.diskonNilai = 0; K.diskonKet = ''; renderCart(); close(); } },
        {
          label: 'Simpan', class: 'btn-primary', onClick: (node, close) => {
            K.diskonNilai = Util.parseNum(node.querySelector('#d-nilai').value);
            K.diskonKet = node.querySelector('#d-ket').value.trim();
            if (K.diskonTipe === 'persen') K.diskonNilai = Util.clamp(K.diskonNilai, 0, 100);
            renderCart(); close();
          }
        }
      ],
      onMount: (node) => {
        node.querySelectorAll('[data-tipe]').forEach(b => b.addEventListener('click', () => {
          K.diskonTipe = b.dataset.tipe;
          node.querySelectorAll('[data-tipe]').forEach(x => x.classList.toggle('is-active', x === b));
          const inp = node.querySelector('#d-nilai');
          inp.classList.toggle('input-money', K.diskonTipe === 'nominal');
        }));
        const inp = node.querySelector('#d-nilai');
        if (K.diskonTipe === 'nominal') Util.moneyInput(inp);
        setTimeout(() => { inp.focus(); inp.select(); }, 60);
      }
    });
  }

  /* ---------------- tahan pesanan ---------------- */
  function bukaTahan() {
    const list = Store.s.tahan;
    const body = list.length ? '<div class="col" style="gap:8px">' + list.map(b => {
      const t = Store.hitung(b.cart || [], {});
      return '<div class="row" style="padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--panel-2)">' +
        '<div class="grow"><div class="strong small">' + Util.esc(b.label || 'Pesanan') + '</div>' +
        '<div class="tiny muted">' + (b.cart || []).length + ' item · ' + Util.rp(t.total) + ' · ' + Util.rel(b.at) + '</div></div>' +
        '<button class="btn btn-sm btn-primary" data-buka="' + b.id + '">Buka</button>' +
        '<button class="btn-icon" data-hapus="' + b.id + '">' + Util.icon('trash') + '</button></div>';
    }).join('') + '</div>' : '<div class="empty">' + Util.icon('pause') + '<strong>Tidak ada pesanan ditahan</strong><p>Tekan F4 saat ada pesanan yang belum dibayar untuk menahannya.</p></div>';

    Util.modal({
      title: 'Pesanan ditahan', sub: 'Lanjutkan atau hapus pesanan yang belum dibayar.', body,
      onMount: (node, close) => {
        node.querySelectorAll('[data-buka]').forEach(btn => btn.addEventListener('click', () => {
          const b = Store.ambilBill(btn.dataset.buka);
          if (!b) return;
          K.cart = b.cart || [];
          K.pelangganId = b.pelangganId || null;
          K.catatan = b.catatan || '';
          K.diskonTipe = b.diskonTipe || 'nominal';
          K.diskonNilai = b.diskonNilai || 0;
          const note = R.querySelector('#k-catatan'); if (note) note.value = K.catatan;
          renderPelanggan(); renderCart(); close();
          Util.toast('Pesanan dilanjutkan', 'ok');
        }));
        node.querySelectorAll('[data-hapus]').forEach(btn => btn.addEventListener('click', async () => {
          const yes = await Util.confirm({ title: 'Hapus pesanan?', body: 'Pesanan yang ditahan akan hilang.', ok: 'Hapus', danger: true });
          if (yes) { Store.hapusBill(btn.dataset.hapus); close(); bukaTahan(); }
        }));
      }
    });
  }

  function tahan() {
    if (!K.cart.length) { Util.toast('Keranjang kosong', 'warn'); return; }
    const pel = K.pelangganId ? Store.pel(K.pelangganId) : null;
    const label = (pel ? pel.nama : 'Pesanan') + ' · ' + Util.fmtTime(Date.now());
    Store.tahanBill({
      label, cart: K.cart, pelangganId: K.pelangganId, catatan: K.catatan,
      diskonTipe: K.diskonTipe, diskonNilai: K.diskonNilai, diskonKet: K.diskonKet, at: Date.now()
    });
    K.cart = []; K.pelangganId = null; K.catatan = ''; K.diskonNilai = 0; K.diskonTipe = 'nominal';
    const note = R.querySelector('#k-catatan'); if (note) note.value = '';
    Store.hapusKeranjang();
    renderPelanggan(); renderCart();
    Util.toast('Pesanan ditahan (' + Store.s.tahan.length + ')', 'ok');
  }

  function pelangganBaru() {
    Util.modal({
      title: 'Pelanggan baru', narrow: true,
      body: '<div class="field"><label class="label">Nama</label><input id="c-nama" class="input" placeholder="Nama pelanggan" autofocus></div>' +
        '<div class="field mt-3"><label class="label">No. HP (opsional)</label><input id="c-telp" class="input" placeholder="08xx" inputmode="tel"></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Simpan', class: 'btn-primary', onClick: (node, close) => {
            const nama = node.querySelector('#c-nama').value.trim();
            if (!nama) { Util.toast('Nama wajib diisi', 'err'); return; }
            const c = {
              id: Util.uid('c'), nama, telp: node.querySelector('#c-telp').value.trim(),
              poin: 0, piutang: 0, catatan: '', dibuat: Date.now()
            };
            Store.s.pelanggan.push(c);
            Store.save('pelanggan');
            K.pelangganId = c.id;
            renderPelanggan();
            close();
            Util.toast('Pelanggan ditambahkan', 'ok');
          }
        }
      ]
    });
  }

  function bukaSheet() { const k = R.querySelector('#keranjang'); if (k) k.dataset.open = 'true'; }
  function tutupSheet() { const k = R.querySelector('#keranjang'); if (k) k.dataset.open = 'false'; }

  /* ---------------- mount ---------------- */
  function kasir(root) {
    root.innerHTML = '<div class="view-anim" id="v-kasir"></div>';
    R = root.firstElementChild;
    const saved = Store.bacaKeranjang();
    if (saved && Array.isArray(saved.cart)) {
      K.cart = saved.cart.filter(x => Store.p(x.pid));
      K.pelangganId = saved.pelangganId || null;
      K.catatan = saved.catatan || '';
      K.diskonTipe = saved.diskonTipe || 'nominal';
      K.diskonNilai = saved.diskonNilai || 0;
      K.diskonKet = saved.diskonKet || '';
    }

    R.innerHTML =
      '<div class="kasir">' +
      '<div class="katalog">' +
      '<div class="alert-strip" id="k-shift-warn" hidden>' + Util.icon('lock') +
      '<span class="grow">Kasir belum dibuka — transaksi belum bisa disimpan.</span>' +
      '<button class="btn btn-sm" data-act="buka-shift">Buka kasir</button></div>' +
      '<div class="searchbar">' +
      '<div class="search">' + Util.icon('search') +
      '<input id="k-cari" placeholder="Cari produk atau scan barcode…" autocomplete="off" enterkeyhint="search" aria-label="Cari produk">' +
      '<span class="sk-kbd"><kbd>F3</kbd></span></div>' +
      '<button class="btn btn-soft" data-act="scan">' + Util.icon('cam') + ' Scan</button>' +
      '<button class="btn" data-act="tahan-list" title="Pesanan ditahan">' + Util.icon('pause') +
      '<span id="k-hold-badge" hidden>0</span></button>' +
      '</div>' +
      '<div class="kategori-scroll"><div class="chips" id="k-kategori"></div></div>' +
      '<div class="grid-produk" id="k-produk"></div>' +
      '</div>' +

      '<aside class="keranjang" id="keranjang" data-open="false">' +
      '<div class="sheet-grab"></div>' +
      '<div class="cart-head"><h2>' + Util.icon('cart') + ' Pesanan <span class="badge" id="k-jumlah">0 item</span></h2>' +
      '<div class="row row-tight">' +
      '<button class="btn-icon only-mobile" data-act="tutup-sheet" aria-label="Tutup">' + Util.icon('x') + '</button>' +
      '<button class="btn-icon" data-act="kosongkan" title="Kosongkan keranjang">' + Util.icon('trash') + '</button>' +
      '</div></div>' +
      '<div class="cart-meta">' +
      '<div class="cart-meta-row"><select id="k-pelanggan" class="select grow" aria-label="Pelanggan"></select>' +
      '<button class="btn-icon" data-act="pelanggan-baru" title="Pelanggan baru">' + Util.icon('plus') + '</button></div>' +
      '<div class="cart-meta-row"><input id="k-catatan" class="input grow" placeholder="Catatan (mis. tanpa sambal)" maxlength="120"></div>' +
      '</div>' +
      '<div class="cart-items" id="k-items"></div>' +
      '<div class="cart-sum" id="k-sum"></div>' +
      '<div class="cart-actions">' +
      '<button class="btn" data-act="diskon" title="Diskon pesanan">' + Util.icon('tag') + '</button>' +
      '<button class="btn btn-primary bayar-btn" data-act="bayar"><span class="lbl">Bayar · F2</span>' +
      '<span class="amt" id="k-total">Rp 0</span></button>' +
      '</div></aside></div>' +

      '<div class="mobile-cart-bar" id="mbar">' +
      '<div class="mb-l"><span>Keranjang</span><b id="mbar-total">Rp 0</b></div>' +
      '<div class="mb-r" data-act="buka-sheet"><span id="mbar-qty">0</span> item ' + Util.icon('chev') + '</div></div>';

    const cari = R.querySelector('#k-cari');
    cari.addEventListener('input', () => { K.q = cari.value; renderProduk(); });
    cari.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const list = produkList();
        if (!list.length) { Util.toast('Produk tidak ditemukan', 'warn'); return; }
        add(list[0].id, 1);
        cari.value = ''; K.q = ''; renderProduk(); cari.focus();
      }
      if (e.key === 'Escape') { cari.value = ''; K.q = ''; renderProduk(); }
    });
    Scan.wedge(cari, code => {
      const p = Store.s.produk.find(x => String(x.barcode || '') === String(code));
      if (p) { add(p.id, 1); Util.toast(p.nama + ' ditambahkan', 'ok', 1200); cari.value = ''; }
      else { Util.toast('Barcode ' + code + ' tidak terdaftar', 'warn'); }
    });

    R.querySelector('#k-pelanggan').addEventListener('change', e => { K.pelangganId = e.target.value || null; });
    R.querySelector('#k-catatan').addEventListener('input', e => { K.catatan = e.target.value; simpan(); });

    R.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t || !root.contains(t)) return;
      const act = t.dataset.act;
      const idx = t.dataset.idx != null ? Number(t.dataset.idx) : -1;
      if (act === 'add') add(t.dataset.pid, 1);
      else if (act === 'cat') { K.cat = t.dataset.cat; renderKategori(); renderProduk(); }
      else if (act === 'qty+') { if (K.cart[idx]) { K.cart[idx].qty++; renderCart(); } }
      else if (act === 'qty-') {
        if (!K.cart[idx]) return;
        K.cart[idx].qty--;
        if (K.cart[idx].qty <= 0) K.cart.splice(idx, 1);
        renderCart();
      }
      else if (act === 'item-del') { K.cart.splice(idx, 1); renderCart(); }
      else if (act === 'item-disc') diskonItem(idx);
      else if (act === 'kosongkan') {
        if (!K.cart.length) return;
        Util.confirm({ title: 'Kosongkan keranjang?', body: 'Semua item akan dihapus.', ok: 'Kosongkan', danger: true })
          .then(yes => { if (yes) { K.cart = []; K.diskonNilai = 0; renderCart(); } });
      }
      else if (act === 'bayar') bukaBayar();
      else if (act === 'diskon') bukaDiskon();
      else if (act === 'scan') Scan.open(code => {
        const p = Store.s.produk.find(x => String(x.barcode || '') === String(code));
        if (p) { add(p.id, 1); Util.toast(p.nama + ' ditambahkan', 'ok', 1400); }
        else Util.toast('Barcode ' + code + ' tidak terdaftar', 'warn');
      });
      else if (act === 'tahan-list') bukaTahan();
      else if (act === 'pelanggan-baru') pelangganBaru();
      else if (act === 'buka-sheet') bukaSheet();
      else if (act === 'tutup-sheet') tutupSheet();
      else if (act === 'buka-shift') App.go('shift');
    });

    R.addEventListener('dblclick', e => {
      const card = e.target.closest('.pcard');
      if (card) add(card.dataset.pid, 1);
    });

    renderKategori();
    renderProduk();
    renderPelanggan();
    renderCart();

    return {
      refresh() { renderKategori(); renderProduk(); renderCart(); },
      focusCari() { cari.focus(); cari.select(); },
      bayar: bukaBayar,
      tahan,
      diskon: bukaDiskon,
      tahanList: bukaTahan
    };
  }

  function diskonItem(idx) {
    const it = K.cart[idx];
    if (!it) return;
    const p = Store.p(it.pid);
    Util.modal({
      title: 'Diskon item', narrow: true,
      sub: (p ? p.nama : it.nama),
      body: '<div class="field"><label class="label">Potongan per baris (Rp)</label>' +
        '<input id="i-disc" class="input input-money" inputmode="numeric" value="' + (it.diskon ? Util.num(it.diskon) : '') + '" placeholder="0"></div>' +
        '<p class="hint mt-2">Total baris: ' + Util.rp(harga(it) * it.qty) + '. Diskon tidak bisa melebihi total baris.</p>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Simpan', class: 'btn-primary', onClick: (node, close) => {
            const v = Util.parseNum(node.querySelector('#i-disc').value);
            it.diskon = Util.clamp(v, 0, harga(it) * it.qty);
            renderCart(); close();
          }
        }
      ],
      onMount: (node) => {
        const inp = node.querySelector('#i-disc');
        Util.moneyInput(inp);
        setTimeout(() => { inp.focus(); inp.select(); }, 60);
      }
    });
  }

  global.Views = global.Views || {};
  global.Views.kasir = kasir;
})(window);
