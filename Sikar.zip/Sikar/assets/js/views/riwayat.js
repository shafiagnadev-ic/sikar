/* ============================================================
   views/riwayat.js — transaksi, refund/void, pelanggan & piutang
   ============================================================ */
(function (global) {
  'use strict';

  let W = null;
  let tab = 'transaksi';
  let range = '7';
  let q = '';

  function mount(root) {
    root.innerHTML =
      '<div class="view-anim" id="v-riwayat">' +
      '<div class="view-head"><div class="vh-text"><h1>Transaksi</h1>' +
      '<p>Cari struk, cetak ulang, refund, atau batalkan transaksi — semuanya tercatat dengan alasannya.</p></div>' +
      '<div class="view-actions" id="r-actions"></div></div>' +
      '<div class="tabs">' +
      '<button class="tab ' + (tab === 'transaksi' ? 'is-active' : '') + '" data-tab="transaksi">Riwayat transaksi</button>' +
      '<button class="tab ' + (tab === 'pelanggan' ? 'is-active' : '') + '" data-tab="pelanggan">Pelanggan & bon</button>' +
      '</div><div id="r-body"></div></div>';
    W = root.querySelector('#v-riwayat');

    W.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      const act = t.dataset.act;
      if (act === 'tab') { tab = t.dataset.tab; render(); }
      else if (act === 'detail') detail(t.dataset.id);
      else if (act === 'pel-baru') formPelanggan(null);
      else if (act === 'pel-edit') formPelanggan(Store.pel(t.dataset.id));
      else if (act === 'pel-hapus') hapusPelanggan(t.dataset.id);
      else if (act === 'pel-bon') bayarBon(t.dataset.id);
      else if (act === 'pel-catat') riwayatPelanggan(t.dataset.id);
    });
    W.addEventListener('change', e => {
      if (e.target.id === 'r-range') { range = e.target.value; render(); }
    });
    W.addEventListener('input', e => {
      if (e.target.id === 'r-cari') { q = e.target.value; renderTabel(); }
    });

    render();
    return { refresh() { render(); } };
  }

  function rentang() {
    const now = Date.now();
    if (range === 'hari') return [Util.startOfDay(now), Util.endOfDay(now)];
    if (range === 'bulan') {
      const d = new Date();
      return [new Date(d.getFullYear(), d.getMonth(), 1).getTime(), Util.endOfDay(now)];
    }
    if (range === 'semua') return [0, now + 1];
    const n = Number(range) || 7;
    return [Util.startOfDay(Util.addDays(now, -(n - 1))), Util.endOfDay(now)];
  }

  function render() {
    W.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('is-active', b.dataset.tab === tab));
    if (tab === 'transaksi') renderTransaksi();
    else renderPelanggan();
  }

  function renderTransaksi() {
    const [from, to] = rentang();
    const list = Util.sortBy(Store.penjualanRentang(from, to), x => x.at, true);
    const omzet = Util.sum(list, x => x.total);
    W.querySelector('#r-actions').innerHTML =
      '<select id="r-range" class="select" style="width:150px">' +
      [['hari', 'Hari ini'], ['7', '7 hari'], ['30', '30 hari'], ['bulan', 'Bulan ini'], ['semua', 'Semua']]
        .map(([v, l]) => '<option value="' + v + '"' + (range === v ? ' selected' : '') + '>' + l + '</option>').join('') +
      '</select>' +
      '<div class="search" style="width:240px">' + Util.icon('search') +
      '<input id="r-cari" class="input" style="padding-left:38px" value="' + Util.esc(q) + '" placeholder="Cari no. nota / kasir…"></div>';

    W.querySelector('#r-body').innerHTML =
      '<div class="grid grid-3" style="margin-bottom:14px">' +
      '<div class="kpi"><div class="kpi-label">Transaksi</div><div class="kpi-value">' + list.filter(x => x.status !== 'refund').length + '</div>' +
      '<div class="kpi-sub">' + list.length + ' baris termasuk refund</div></div>' +
      '<div class="kpi"><div class="kpi-label">Nilai</div><div class="kpi-value sm">' + Util.rp(omzet) + '</div>' +
      '<div class="kpi-sub">setelah refund</div></div>' +
      '<div class="kpi"><div class="kpi-label">Rata-rata / transaksi</div><div class="kpi-value sm">' +
      Util.rp(list.length ? omzet / Math.max(1, list.filter(x => x.status !== 'refund').length) : 0) + '</div>' +
      '<div class="kpi-sub">basket size</div></div></div>' +
      '<div class="card card-flush"><div class="table-wrap" style="max-height:calc(100dvh - 380px)">' +
      '<table class="tbl"><thead><tr><th>No. nota</th><th>Waktu</th><th>Kasir</th>' +
      '<th class="right">Item</th><th class="right">Total</th><th>Bayar</th><th>Status</th><th></th></tr></thead>' +
      '<tbody id="r-list"></tbody></table></div></div>';
    renderTabel();
  }

  function renderTabel() {
    const body = W.querySelector('#r-list');
    if (!body) return;
    const [from, to] = rentang();
    let list = Util.sortBy(Store.penjualanRentang(from, to), x => x.at, true);
    const qq = q.toLowerCase().trim();
    if (qq) list = list.filter(x => (x.no + ' ' + x.kasir + ' ' + (x.pelangganId ? (Store.pel(x.pelangganId) || {}).nama || '' : '')).toLowerCase().includes(qq));
    list = list.slice(0, 300);

    if (!list.length) {
      body.innerHTML = '<tr><td colspan="8"><div class="empty">' + Util.icon('receipt') +
        '<strong>Belum ada transaksi</strong><p>Transaksi dari kasir akan muncul di sini.</p></div></td></tr>';
      return;
    }
    body.innerHTML = list.map(x => {
      const metode = (x.bayar || []).map(b => b.metode).join(' + ');
      const badge = x.status === 'void' ? 'badge-danger' : x.status === 'refund' ? 'badge-warn' : x.status === 'sebagian' ? 'badge-info' : 'badge-ok';
      const label = { void: 'Void', refund: 'Refund', sebagian: 'Refund sebagian', lunas: 'Lunas' }[x.status] || x.status;
      return '<tr class="is-click ' + (x.status === 'void' ? 'is-void' : '') + '" data-act="detail" data-id="' + x.id + '">' +
        '<td class="mono tiny">' + Util.esc(x.no) + '</td>' +
        '<td class="tiny nowrap">' + Util.fmtDate(x.at) + ' · ' + Util.fmtTime(x.at) + '</td>' +
        '<td class="tiny">' + Util.esc(x.kasir || '') + '</td>' +
        '<td class="num">' + Util.sum(x.items, it => Math.abs(it.qty)) + '</td>' +
        '<td class="num strong">' + Util.rp(x.total) + '</td>' +
        '<td class="tiny muted">' + Util.esc(metode) + '</td>' +
        '<td><span class="badge ' + badge + '">' + label + '</span></td>' +
        '<td class="right">' + Util.icon('right', 'ic-sm muted') + '</td></tr>';
    }).join('');
  }

  function detail(id) {
    const sale = Store.s.penjualan.find(x => x.id === id);
    if (!sale) return;
    const pel = sale.pelangganId ? Store.pel(sale.pelangganId) : null;
    const sisa = Store.sisaRefund(sale);
    const bisaRefund = sale.status !== 'void' && sisa.some(v => v > 0);
    const items = sale.items.map(it =>
      '<tr><td>' + Util.esc(it.nama) + '</td><td class="num">' + it.qty + '</td>' +
      '<td class="num">' + Util.rp(it.harga) + '</td><td class="num">' + Util.rp(it.harga * it.qty - (it.diskon || 0)) + '</td></tr>').join('');

    const body =
      '<div class="row" style="gap:18px;align-items:flex-start;flex-wrap:wrap">' +
      '<div class="grow" style="min-width:260px">' +
      '<div class="row row-between" style="margin-bottom:10px"><div>' +
      '<div class="mono strong">' + Util.esc(sale.no) + '</div>' +
      '<div class="tiny muted">' + Util.fmtDateTime(sale.at) + ' · ' + Util.esc(sale.kasir || '') + '</div></div>' +
      '<span class="badge ' + (sale.status === 'void' ? 'badge-danger' : sale.status === 'refund' ? 'badge-warn' : 'badge-ok') + '">' +
      ({ lunas: 'Lunas', void: 'Dibatalkan', refund: 'Refund penuh', sebagian: 'Refund sebagian' }[sale.status] || sale.status) + '</span></div>' +
      (pel ? '<div class="tiny muted" style="margin-bottom:8px">Pelanggan: <strong>' + Util.esc(pel.nama) + '</strong></div>' : '') +
      '<div class="table-wrap" style="border:1px solid var(--line);border-radius:10px">' +
      '<table class="tbl"><thead><tr><th>Item</th><th class="right">Qty</th><th class="right">Harga</th><th class="right">Jumlah</th></tr></thead>' +
      '<tbody>' + items + '</tbody></table></div>' +
      '<div class="col mt-3" style="gap:4px">' +
      '<div class="sum-row"><span>Subtotal</span><span class="v">' + Util.rp(sale.subtotal) + '</span></div>' +
      (sale.diskon ? '<div class="sum-row"><span>Diskon</span><span class="v">−' + Util.rp(sale.diskon) + '</span></div>' : '') +
      (sale.pajak ? '<div class="sum-row"><span>Pajak</span><span class="v">' + Util.rp(sale.pajak) + '</span></div>' : '') +
      (sale.service ? '<div class="sum-row"><span>Service</span><span class="v">' + Util.rp(sale.service) + '</span></div>' : '') +
      (sale.pembulatan ? '<div class="sum-row"><span>Pembulatan</span><span class="v">' + Util.rp(sale.pembulatan) + '</span></div>' : '') +
      '<div class="sum-row total"><span>Total</span><span class="v">' + Util.rp(sale.total) + '</span></div>' +
      (sale.bayar || []).map(b => '<div class="sum-row"><span>' + Util.esc(b.metode) + '</span><span class="v">' + Util.rp(b.nominal) + '</span></div>').join('') +
      (sale.kembali ? '<div class="sum-row"><span>Kembalian</span><span class="v">' + Util.rp(sale.kembali) + '</span></div>' : '') +
      '</div>' +
      (sale.catatan ? '<p class="tiny muted mt-2">Catatan: ' + Util.esc(sale.catatan) + '</p>' : '') +
      (sale.status === 'void' ? '<div class="alert-strip danger mt-3">' + Util.icon('alert') + '<span class="grow">Dibatalkan: ' + Util.esc(sale.voidAlasan || '-') + '</span></div>' : '') +
      '</div>' +
      '<div style="width:230px;flex:0 0 auto" class="col" style="gap:8px">' +
      '<div class="struk">' + Print.receiptDoc(sale) + '</div>' +
      '<button class="btn btn-block mt-2" data-x="cetak">' + Util.icon('printer') + ' Cetak struk</button>' +
      '<button class="btn btn-block" data-x="wa">' + Util.icon('share') + ' WhatsApp</button>' +
      '<button class="btn btn-block" data-x="salin">' + Util.icon('copy') + ' Salin teks</button>' +
      (bisaRefund ? '<button class="btn btn-block btn-soft" data-x="refund">' + Util.icon('refresh') + ' Refund item</button>' : '') +
      (sale.status !== 'void' ? '<button class="btn btn-block btn-danger" data-x="void">' + Util.icon('x') + ' Batalkan (void)</button>' : '') +
      '</div></div>';

    Util.modal({
      title: 'Detail transaksi', wide: true, body,
      actions: [{ label: 'Tutup', class: 'btn-ghost' }],
      onMount: (node, close) => {
        const btn = s => node.querySelector('[data-x="' + s + '"]');
        if (btn('cetak')) btn('cetak').addEventListener('click', () => Print.struk(sale));
        if (btn('wa')) btn('wa').addEventListener('click', () => Util.shareText(Print.text(sale), 'Struk ' + sale.no));
        if (btn('salin')) btn('salin').addEventListener('click', () => Util.copy(Print.text(sale)).then(() => Util.toast('Teks disalin')));
        if (btn('refund')) btn('refund').addEventListener('click', () => { close(); formRefund(sale); });
        if (btn('void')) btn('void').addEventListener('click', () => { close(); voidSale(sale); });
      }
    });
  }

  function formRefund(sale) {
    const sisa = Store.sisaRefund(sale);
    const rows = sale.items.map((it, i) =>
      '<tr><td>' + Util.esc(it.nama) + '</td><td class="num">' + it.qty + '</td>' +
      '<td class="num">' + sisa[i] + '</td>' +
      '<td class="right" style="width:90px"><input class="input num" style="height:32px" data-q="' + i + '" inputmode="numeric" value="0" max="' + sisa[i] + '"></td></tr>').join('');
    Util.modal({
      title: 'Refund item',
      sub: 'Hanya item yang diretur. Stok otomatis kembali.',
      wide: true,
      body:
        '<div class="table-wrap" style="border:1px solid var(--line);border-radius:10px"><table class="tbl"><thead><tr>' +
        '<th>Item</th><th class="right">Terjual</th><th class="right">Sisa bisa refund</th><th class="right">Refund</th></tr></thead>' +
        '<tbody>' + rows + '</tbody></table></div>' +
        '<div class="field mt-4"><label class="label">Alasan refund</label>' +
        '<input id="rf-alasan" class="input" placeholder="mis. pesanan salah, barang rusak"></div>' +
        '<div class="alert-strip info mt-3">' + Util.icon('refresh') + '<span class="grow">Nilai refund dihitung proporsional dari total transaksi.</span></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Proses refund', class: 'btn-primary', icon: 'refresh', onClick: (node, close) => {
            const map = {};
            node.querySelectorAll('[data-q]').forEach(inp => { map[inp.dataset.q] = Util.parseNum(inp.value); });
            if (!Object.values(map).some(v => v > 0)) { Util.toast('Isi jumlah yang diretur', 'err'); return; }
            const res = Store.refund(sale.id, map, node.querySelector('#rf-alasan').value.trim());
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Refund diproses: ' + Util.rp(res.rec.total), 'ok');
          }
        }
      ]
    });
  }

  async function voidSale(sale) {
    const ok = await Util.pin({ title: 'Batalkan transaksi', sub: 'Void ' + sale.no + ' butuh PIN pemilik.' });
    if (!ok) return;
    Util.modal({
      title: 'Alasan pembatalan', narrow: true,
      body: '<div class="field"><label class="label">Kenapa dibatalkan?</label>' +
        '<input id="v-alasan" class="input" placeholder="mis. salah input, pelanggan batal" autofocus></div>' +
        '<p class="hint mt-2">Stok akan dikembalikan dan transaksi ditandai void (tidak dihitung di omzet).</p>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Batalkan transaksi', class: 'btn-danger', onClick: (node, close) => {
            const res = Store.voidJual(sale.id, node.querySelector('#v-alasan').value.trim(), 'Pemilik');
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Transaksi dibatalkan', 'ok');
          }
        }
      ]
    });
  }

  /* ---------------- pelanggan ---------------- */
  function renderPelanggan() {
    const list = Store.s.pelanggan;
    const piutang = Util.sum(list, c => Number(c.piutang) || 0);
    const poin = Util.sum(list, c => Number(c.poin) || 0);
    W.querySelector('#r-actions').innerHTML =
      '<button class="btn btn-primary" data-act="pel-baru">' + Util.icon('plus') + ' Pelanggan baru</button>';
    W.querySelector('#r-body').innerHTML =
      '<div class="grid grid-3" style="margin-bottom:14px">' +
      '<div class="kpi"><div class="kpi-label">Pelanggan</div><div class="kpi-value">' + list.length + '</div>' +
      '<div class="kpi-sub">member terdaftar</div></div>' +
      '<div class="kpi ' + (piutang > 0 ? 'kpi-accent' : '') + '"><div class="kpi-label">Total bon (piutang)</div>' +
      '<div class="kpi-value sm">' + Util.rp(piutang) + '</div><div class="kpi-sub">uang yang belum masuk</div></div>' +
      '<div class="kpi"><div class="kpi-label">Total poin</div><div class="kpi-value">' + Util.num(poin) + '</div>' +
      '<div class="kpi-sub">1 poin / Rp 10.000</div></div></div>' +
      '<div class="card card-flush"><div class="table-wrap" style="max-height:calc(100dvh - 380px)">' +
      '<table class="tbl"><thead><tr><th>Pelanggan</th><th>No. HP</th><th class="right">Poin</th>' +
      '<th class="right">Bon</th><th>Catatan</th><th></th></tr></thead><tbody>' +
      (list.length ? list.map(c =>
        '<tr><td><div class="prod-cell"><span class="prod-ico">' + Util.esc((c.nama || '?').slice(0, 2)) + '</span>' +
        '<div><div class="strong">' + Util.esc(c.nama) + '</div><div class="tiny muted">' + Util.rel(c.dibuat || Date.now()) + '</div></div></div></td>' +
        '<td class="tiny">' + Util.esc(c.telp || '—') + '</td>' +
        '<td class="num">' + (c.poin || 0) + '</td>' +
        '<td class="num ' + (c.piutang ? 'strong' : 'muted') + '">' + (c.piutang ? Util.rp(c.piutang) : '—') + '</td>' +
        '<td class="tiny muted truncate" style="max-width:220px">' + Util.esc(c.catatan || '') + '</td>' +
        '<td class="right nowrap">' +
        (c.piutang ? '<button class="btn btn-sm btn-soft" data-act="pel-bon" data-id="' + c.id + '">Bayar bon</button> ' : '') +
        '<button class="btn-icon" data-act="pel-catat" data-id="' + c.id + '" title="Riwayat">' + Util.icon('receipt') + '</button>' +
        '<button class="btn-icon" data-act="pel-edit" data-id="' + c.id + '" title="Ubah">' + Util.icon('edit') + '</button>' +
        '<button class="btn-icon" data-act="pel-hapus" data-id="' + c.id + '" title="Hapus">' + Util.icon('trash') + '</button>' +
        '</td></tr>').join('')
        : '<tr><td colspan="6"><div class="empty">' + Util.icon('user') + '<strong>Belum ada pelanggan</strong>' +
        '<p>Tambahkan pelanggan supaya poin dan bon tercatat.</p></div></td></tr>') +
      '</tbody></table></div></div>';
  }

  function formPelanggan(c) {
    const isNew = !c;
    c = c || { nama: '', telp: '', catatan: '', poin: 0, piutang: 0 };
    Util.modal({
      title: isNew ? 'Pelanggan baru' : 'Ubah pelanggan', narrow: true,
      body: '<div class="field"><label class="label">Nama <span class="req">*</span></label>' +
        '<input id="pc-nama" class="input" value="' + Util.esc(c.nama) + '" autofocus></div>' +
        '<div class="field mt-3"><label class="label">No. HP</label><input id="pc-telp" class="input" value="' + Util.esc(c.telp || '') + '" inputmode="tel"></div>' +
        '<div class="field mt-3"><label class="label">Catatan</label><input id="pc-cat" class="input" value="' + Util.esc(c.catatan || '') + '"></div>' +
        (isNew ? '' : '<div class="row mt-3" style="gap:12px"><div class="field grow"><label class="label">Poin</label>' +
          '<input id="pc-poin" class="input num" inputmode="numeric" value="' + (c.poin || 0) + '"></div>' +
          '<div class="field grow"><label class="label">Bon</label><input id="pc-bon" class="input num" readonly value="' + (c.piutang || 0) + '"></div></div>'),
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Simpan', class: 'btn-primary', onClick: (node, close) => {
            const nama = node.querySelector('#pc-nama').value.trim();
            if (!nama) { Util.toast('Nama wajib diisi', 'err'); return; }
            if (isNew) {
              Store.s.pelanggan.push({
                id: Util.uid('c'), nama, telp: node.querySelector('#pc-telp').value.trim(),
                catatan: node.querySelector('#pc-cat').value.trim(), poin: 0, piutang: 0, dibuat: Date.now()
              });
            } else {
              c.nama = nama;
              c.telp = node.querySelector('#pc-telp').value.trim();
              c.catatan = node.querySelector('#pc-cat').value.trim();
              const poinEl = node.querySelector('#pc-poin');
              if (poinEl) c.poin = Util.parseNum(poinEl.value);
            }
            Store.save('pelanggan');
            close();
            Util.toast('Pelanggan disimpan', 'ok');
          }
        }
      ]
    });
  }

  async function hapusPelanggan(id) {
    const c = Store.pel(id);
    if (!c) return;
    const yes = await Util.confirm({ title: 'Hapus ' + c.nama + '?', body: 'Riwayat transaksi tetap tersimpan tanpa nama pelanggan.', ok: 'Hapus', danger: true });
    if (!yes) return;
    Store.s.pelanggan = Store.s.pelanggan.filter(x => x.id !== id);
    Store.save('pelanggan');
    Util.toast('Pelanggan dihapus', 'ok');
  }

  function bayarBon(id) {
    const c = Store.pel(id);
    if (!c) return;
    Util.modal({
      title: 'Bayar bon — ' + c.nama, narrow: true,
      sub: 'Sisa piutang ' + Util.rp(c.piutang),
      body: '<div class="field"><label class="label">Nominal dibayar</label>' +
        '<input id="b-nom" class="input input-lg input-money" inputmode="numeric" value="' + Util.num(c.piutang) + '"></div>' +
        '<div class="quick-cash mt-3" id="b-quick"></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Terima pembayaran', class: 'btn-primary', icon: 'check', onClick: (node, close) => {
            const res = Store.bayarPiutang(id, Util.parseNum(node.querySelector('#b-nom').value), 'Bayar bon');
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Pembayaran bon dicatat', 'ok');
          }
        }
      ],
      onMount: (node) => {
        const inp = node.querySelector('#b-nom');
        Util.moneyInput(inp);
        const q = node.querySelector('#b-quick');
        q.innerHTML = [c.piutang, 50000, 100000].filter((v, i, a) => v > 0 && a.indexOf(v) === i && v <= c.piutang)
          .map(v => '<button class="qcash" data-v="' + v + '">' + Util.rp(v) + '</button>').join('');
        q.querySelectorAll('[data-v]').forEach(b => b.addEventListener('click', () => {
          inp.value = Util.num(b.dataset.v);
        }));
      }
    });
  }

  function riwayatPelanggan(id) {
    const c = Store.pel(id);
    if (!c) return;
    const list = Store.s.penjualan.filter(x => x.pelangganId === id).sort((a, b) => b.at - a.at).slice(0, 40);
    const log = Store.s.riwayatPiutang.filter(x => x.pelangganId === id).sort((a, b) => b.at - a.at);
    Util.modal({
      title: c.nama, sub: 'Poin ' + (c.poin || 0) + ' · Bon ' + Util.rp(c.piutang || 0),
      body:
        '<div class="grid grid-2" style="gap:14px">' +
        '<div><div class="card-title" style="margin-bottom:8px">Transaksi terakhir</div>' +
        (list.length ? list.map(x => '<div class="row row-between" style="padding:6px 0;border-bottom:1px dashed var(--line)">' +
          '<div><div class="tiny mono">' + Util.esc(x.no) + '</div><div class="tiny muted">' + Util.fmtDate(x.at) + '</div></div>' +
          '<span class="strong small">' + Util.rp(x.total) + '</span></div>').join('')
          : '<p class="tiny muted">Belum ada transaksi.</p>') + '</div>' +
        '<div><div class="card-title" style="margin-bottom:8px">Riwayat bon</div>' +
        (log.length ? log.map(x => '<div class="row row-between" style="padding:6px 0;border-bottom:1px dashed var(--line)">' +
          '<div><div class="tiny">' + (x.tipe === 'bon' ? 'Bon baru' : 'Pembayaran') + '</div>' +
          '<div class="tiny muted">' + Util.fmtDate(x.at) + ' · ' + Util.esc(x.ref || '') + '</div></div>' +
          '<span class="small ' + (x.tipe === 'bon' ? 'ledger-out' : 'ledger-in') + '">' + (x.tipe === 'bon' ? '+' : '−') + Util.rp(x.nominal) + '</span></div>').join('')
          : '<p class="tiny muted">Belum ada catatan bon.</p>') + '</div>' +
        '</div>',
      wide: true,
      actions: [{ label: 'Tutup', class: 'btn-ghost' }]
    });
  }

  global.Views = global.Views || {};
  global.Views.transaksi = mount;
})(window);
