/* ============================================================
   views/stok.js — stok masuk, opname, kartu stok, kedaluwarsa
   ============================================================ */
(function (global) {
  'use strict';

  let W = null;
  let tab = 'ringkasan';
  let q = '';

  function mount(root) {
    root.innerHTML =
      '<div class="view-anim" id="v-stok">' +
      '<div class="view-head"><div class="vh-text"><h1>Stok</h1>' +
      '<p>FIFO/FEFO otomatis: batch yang paling cepat kedaluwarsa dijual lebih dulu. Semua perubahan punya jejak.</p></div>' +
      '<div class="view-actions">' +
      '<button class="btn" data-act="opname">' + Util.icon('list') + ' Opname</button>' +
      '<button class="btn btn-primary" data-act="masuk">' + Util.icon('plus') + ' Stok masuk</button>' +
      '</div></div>' +
      '<div id="s-alert"></div>' +
      '<div class="tabs" id="s-tabs">' +
      '<button class="tab" data-tab="ringkasan">Ringkasan</button>' +
      '<button class="tab" data-tab="kartu">Kartu stok</button>' +
      '<button class="tab" data-tab="masuk">Riwayat masuk</button>' +
      '</div>' +
      '<div id="s-body"></div>' +
      '</div>';
    W = root.querySelector('#v-stok');

    W.querySelector('#s-tabs').addEventListener('click', e => {
      const b = e.target.closest('[data-tab]');
      if (!b) return;
      tab = b.dataset.tab;
      render();
    });
    W.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      const act = t.dataset.act;
      if (act === 'masuk') formMasuk(t.dataset.pid);
      else if (act === 'opname') formOpname(t.dataset.pid);
      else if (act === 'kartu') { tab = 'kartu'; render(); setTimeout(() => { const i = W.querySelector('#k-produk'); if (i) { i.value = t.dataset.pid; renderKartu(t.dataset.pid); } }, 0); }
      else if (act === 'semua-kritis') { q = ''; tab = 'ringkasan'; render(); }
    });

    render();
    return { refresh() { render(); } };
  }

  function render() {
    W.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('is-active', b.dataset.tab === tab));
    renderAlert();
    if (tab === 'ringkasan') renderRingkasan();
    else if (tab === 'kartu') renderKartu();
    else renderMasuk();
  }

  function renderAlert() {
    const kritis = Store.stokKritis();
    const exp = Store.hampirExp(30);
    const el = W.querySelector('#s-alert');
    if (!kritis.length && !exp.length) { el.innerHTML = ''; return; }
    let h = '<div class="col" style="gap:8px;margin-bottom:14px">';
    if (kritis.length) {
      h += '<div class="alert-strip">' + Util.icon('alert') +
        '<span class="grow"><strong>' + kritis.length + ' produk</strong> di bawah stok minimum: ' +
        kritis.slice(0, 3).map(p => Util.esc(p.nama)).join(', ') + (kritis.length > 3 ? ', dll.' : '') + '</span>' +
        '<button class="btn btn-sm" data-act="semua-kritis">Lihat</button></div>';
    }
    if (exp.length) {
      h += '<div class="alert-strip danger">' + Util.icon('clock') +
        '<span class="grow"><strong>' + exp.length + ' batch</strong> kedaluwarsa dalam 30 hari — jual lebih dulu atau tarik dari rak.</span>' +
        '<button class="btn btn-sm" data-act="opname">Opname</button></div>';
    }
    el.innerHTML = h + '</div>';
  }

  function renderRingkasan() {
    const list = Util.sortBy(Store.s.produk.filter(p => p.aktif !== false), p => Number(p.stok) || 0);
    const nilai = Util.sum(list, p => (Number(p.stok) || 0) * (Number(p.hpp) || 0));
    const rows = list.map(p => {
      const batch = (p.batch || []).slice().sort((a, b) => (a.exp || Infinity) - (b.exp || Infinity));
      const next = batch.find(b => b.exp);
      const hari = next ? Math.ceil((next.exp - Date.now()) / 86400000) : null;
      const stok = Number(p.stok) || 0;
      const cls = stok <= 0 ? 'badge-danger' : stok <= Number(p.minStok || 0) ? 'badge-warn' : 'badge-ok';
      return '<tr>' +
        '<td><div class="prod-cell"><span class="prod-ico">' + Util.esc((p.nama || '?').slice(0, 2)) + '</span>' +
        '<div style="min-width:0"><div class="truncate strong">' + Util.esc(p.nama) + '</div>' +
        '<div class="tiny muted">' + Util.esc(p.kategori) + '</div></div></div></td>' +
        '<td class="num"><span class="badge ' + cls + '">' + stok + '</span></td>' +
        '<td class="num muted">' + (Number(p.minStok) || 0) + '</td>' +
        '<td class="num">' + Util.rp((Number(p.stok) || 0) * (Number(p.hpp) || 0)) + '</td>' +
        '<td>' + (hari === null ? '<span class="tiny muted">—</span>' :
          '<span class="badge ' + (hari < 0 ? 'badge-danger' : hari < 14 ? 'badge-warn' : 'badge-muted') + '">' +
          (hari < 0 ? 'lewat ' + Math.abs(hari) + 'h' : hari + ' hari') + '</span>') + '</td>' +
        '<td class="right nowrap">' +
        '<button class="btn btn-sm" data-act="masuk" data-pid="' + p.id + '">+ Stok</button> ' +
        '<button class="btn-icon" data-act="kartu" data-pid="' + p.id + '" title="Kartu stok">' + Util.icon('list') + '</button>' +
        '</td></tr>';
    }).join('');

    W.querySelector('#s-body').innerHTML =
      '<div class="grid grid-3" style="margin-bottom:14px">' +
      '<div class="kpi"><div class="kpi-label">Nilai stok</div><div class="kpi-value sm">' + Util.rp(nilai) + '</div>' +
      '<div class="kpi-sub">' + list.length + ' produk aktif</div></div>' +
      '<div class="kpi"><div class="kpi-label">Stok kritis</div><div class="kpi-value">' + Store.stokKritis().length + '</div>' +
      '<div class="kpi-sub">perlu dibeli lagi</div></div>' +
      '<div class="kpi"><div class="kpi-label">Batch hampir kedaluwarsa</div><div class="kpi-value">' + Store.hampirExp(30).length + '</div>' +
      '<div class="kpi-sub">dalam 30 hari</div></div></div>' +
      '<div class="card card-flush"><div class="table-wrap" style="max-height:calc(100dvh - 380px)">' +
      '<table class="tbl"><thead><tr><th>Produk</th><th class="right">Stok</th><th class="right">Min</th>' +
      '<th class="right">Nilai (HPP)</th><th>Kedaluwarsa terdekat</th><th></th></tr></thead>' +
      '<tbody>' + (rows || '<tr><td colspan="6"><div class="empty">' + Util.icon('box') + '<strong>Belum ada produk</strong></div></td></tr>') + '</tbody></table></div></div>';
  }

  function renderKartu(pid) {
    const produk = Store.s.produk.filter(p => p.aktif !== false);
    const cur = pid || (W.querySelector('#k-produk') && W.querySelector('#k-produk').value) || (produk[0] && produk[0].id) || '';
    W.querySelector('#s-body').innerHTML =
      '<div class="card">' +
      '<div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:14px">' +
      '<div class="field grow" style="max-width:340px"><label class="label">Produk</label>' +
      '<select id="k-produk" class="select">' + produk.map(p =>
        '<option value="' + p.id + '"' + (p.id === cur ? ' selected' : '') + '>' + Util.esc(p.nama) + ' · stok ' + p.stok + '</option>').join('') +
      '</select></div>' +
      '<div class="field" style="max-width:160px"><label class="label">Jenis</label>' +
      '<select id="k-tipe" class="select"><option value="">Semua</option><option value="jual">Penjualan</option>' +
      '<option value="masuk">Stok masuk</option><option value="opname">Opname</option>' +
      '<option value="void">Void</option><option value="refund">Refund</option></select></div>' +
      '</div><div id="k-ledger"></div></div>';

    const sel = W.querySelector('#k-produk');
    const tipe = W.querySelector('#k-tipe');
    sel.addEventListener('change', () => renderLedger(sel.value, tipe.value));
    tipe.addEventListener('change', () => renderLedger(sel.value, tipe.value));
    renderLedger(cur, '');
  }

  function renderLedger(pid, tipe) {
    const p = Store.p(pid);
    const box = W.querySelector('#k-ledger');
    if (!p) { box.innerHTML = '<div class="empty">' + Util.icon('box') + '<strong>Pilih produk</strong></div>'; return; }
    let moves = Store.s.gerakanStok.filter(g => g.pid === pid);
    if (tipe) moves = moves.filter(g => g.tipe === tipe);
    moves = Util.sortBy(moves, g => g.at, true).slice(0, 200);
    const total = moves.reduce((s, g) => s + g.qty, 0);
    const awal = Number(p.stok) - Util.sum(Store.s.gerakanStok.filter(g => g.pid === pid), g => g.qty);
    let saldo = awal;
    const rows = moves.slice().reverse().map(g => {
      saldo += g.qty;
      return '<tr><td class="tiny nowrap">' + Util.fmtDateTime(g.at) + '</td>' +
        '<td><span class="badge badge-muted">' + labelTipe(g.tipe) + '</span></td>' +
        '<td class="num ' + (g.qty > 0 ? 'ledger-in' : 'ledger-out') + '">' + (g.qty > 0 ? '+' : '') + g.qty + '</td>' +
        '<td class="num">' + saldo + '</td>' +
        '<td class="tiny muted truncate" style="max-width:220px">' + Util.esc(g.catatan || g.ref || '') + '</td></tr>';
    }).reverse().join('');

    box.innerHTML =
      '<div class="row" style="gap:18px;margin-bottom:12px;flex-wrap:wrap">' +
      '<div><div class="kpi-label">Stok sekarang</div><div class="big strong">' + p.stok + ' ' + Util.esc(p.satuan || '') + '</div></div>' +
      '<div><div class="kpi-label">Nilai</div><div class="big strong">' + Util.rp((Number(p.stok) || 0) * (Number(p.hpp) || 0)) + '</div></div>' +
      '<div><div class="kpi-label">HPP rata-rata</div><div class="big strong">' + Util.rp(p.hpp) + '</div></div>' +
      '<div class="grow"></div><span class="badge badge-muted">' + moves.length + ' mutasi terakhir</span></div>' +
      (moves.length ? '<div class="table-wrap" style="max-height:420px"><table class="tbl"><thead><tr>' +
        '<th>Waktu</th><th>Jenis</th><th class="right">Qty</th><th class="right">Saldo</th><th>Keterangan</th></tr></thead>' +
        '<tbody>' + rows + '</tbody></table></div>'
        : '<div class="empty">' + Util.icon('list') + '<strong>Belum ada mutasi</strong><p>Setiap penjualan, stok masuk, dan opname akan tercatat di sini.</p></div>');
  }

  function labelTipe(t) {
    return { jual: 'Penjualan', masuk: 'Stok masuk', opname: 'Opname', void: 'Void', refund: 'Refund' }[t] || t;
  }

  function renderMasuk() {
    const list = Util.sortBy(Store.s.gerakanStok.filter(g => g.tipe === 'masuk' || g.tipe === 'opname'), g => g.at, true).slice(0, 120);
    W.querySelector('#s-body').innerHTML =
      '<div class="card card-flush"><div class="card-head"><div><div class="card-title">Riwayat stok masuk & opname</div>' +
      '<div class="card-sub">HPP rata-rata dihitung ulang otomatis setiap barang masuk.</div></div>' +
      '<button class="btn btn-sm btn-primary" data-act="masuk">' + Util.icon('plus') + ' Stok masuk</button></div>' +
      '<div class="table-wrap" style="max-height:calc(100dvh - 360px)"><table class="tbl"><thead><tr>' +
      '<th>Waktu</th><th>Produk</th><th>Jenis</th><th class="right">Qty</th><th class="right">HPP</th><th>Keterangan</th></tr></thead><tbody>' +
      (list.length ? list.map(g => {
        const p = Store.p(g.pid);
        return '<tr><td class="tiny nowrap">' + Util.fmtDateTime(g.at) + '</td>' +
          '<td class="truncate" style="max-width:240px">' + Util.esc(p ? p.nama : '(dihapus)') + '</td>' +
          '<td><span class="badge ' + (g.tipe === 'opname' ? 'badge-warn' : 'badge-ok') + '">' + labelTipe(g.tipe) + '</span></td>' +
          '<td class="num ledger-in">+' + g.qty + '</td>' +
          '<td class="num">' + Util.rp(g.hpp || 0) + '</td>' +
          '<td class="tiny muted truncate" style="max-width:260px">' + Util.esc(g.catatan || '') + '</td></tr>';
      }).join('') : '<tr><td colspan="6"><div class="empty">' + Util.icon('up') + '<strong>Belum ada barang masuk</strong><p>Catat pembelian dari supplier supaya HPP dan stok selalu benar.</p></div></td></tr>') +
      '</tbody></table></div></div>';
  }

  function formMasuk(pid) {
    const produk = Store.s.produk.filter(p => p.aktif !== false);
    if (!produk.length) { Util.toast('Tambahkan produk dulu', 'warn'); return; }
    const cur = pid || produk[0].id;
    const p = Store.p(cur);
    Util.modal({
      title: 'Stok masuk',
      sub: 'Catat barang datang dari supplier / pasar.',
      body:
        '<div class="form-grid">' +
        '<div class="field full"><label class="label">Produk</label><select id="m-pid" class="select">' +
        produk.map(x => '<option value="' + x.id + '"' + (x.id === cur ? ' selected' : '') + '>' + Util.esc(x.nama) + ' · stok ' + x.stok + '</option>').join('') +
        '</select></div>' +
        '<div class="field"><label class="label">Jumlah masuk <span class="req">*</span></label>' +
        '<input id="m-qty" class="input num" inputmode="numeric" value="" placeholder="0" autofocus></div>' +
        '<div class="field"><label class="label">HPP per unit</label>' +
        '<input id="m-hpp" class="input input-money" inputmode="numeric" value="' + (p ? Util.num(p.hpp) : '') + '"></div>' +
        '<div class="field"><label class="label">Kedaluwarsa (opsional)</label>' +
        '<input id="m-exp" class="input" type="date"></div>' +
        '<div class="field"><label class="label">Supplier</label>' +
        '<input id="m-sup" class="input" placeholder="mis. Pasar Induk"></div>' +
        '<div class="field full"><label class="label">Catatan</label>' +
        '<input id="m-cat" class="input" placeholder="No. nota / keterangan"></div>' +
        '</div>' +
        '<div class="alert-strip info mt-4">' + Util.icon('alert') +
        '<span class="grow">HPP baru akan menjadi rata-rata tertimbang. Batch dengan tanggal kedaluwarsa akan dijual lebih dulu (FEFO).</span></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Simpan stok', class: 'btn-primary', icon: 'check', onClick: (node, close) => {
            const qty = Util.parseNum(node.querySelector('#m-qty').value);
            if (qty <= 0) { Util.toast('Jumlah harus lebih dari 0', 'err'); return; }
            const expVal = node.querySelector('#m-exp').value;
            const res = Store.stokMasuk({
              pid: node.querySelector('#m-pid').value,
              qty,
              hpp: Util.parseNum(node.querySelector('#m-hpp').value),
              exp: expVal ? new Date(expVal + 'T23:59:59').getTime() : null,
              supplier: node.querySelector('#m-sup').value.trim(),
              catatan: node.querySelector('#m-cat').value.trim()
            });
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Stok ' + res.produk.nama + ' ditambah ' + qty, 'ok');
          }
        }
      ],
      onMount: (node) => {
        Util.moneyInput(node.querySelector('#m-hpp'));
        node.querySelector('#m-pid').addEventListener('change', e => {
          const pp = Store.p(e.target.value);
          node.querySelector('#m-hpp').value = pp ? Util.num(pp.hpp) : '';
        });
      }
    });
  }

  function formOpname(pid) {
    const produk = Store.s.produk.filter(p => p.aktif !== false);
    if (!produk.length) { Util.toast('Belum ada produk', 'warn'); return; }
    const cur = pid || produk[0].id;
    Util.modal({
      title: 'Stok opname',
      sub: 'Hitung fisik barang di rak, lalu sesuaikan sistem.',
      body:
        '<div class="form-grid">' +
        '<div class="field full"><label class="label">Produk</label><select id="o-pid" class="select">' +
        produk.map(x => '<option value="' + x.id + '"' + (x.id === cur ? ' selected' : '') + '>' + Util.esc(x.nama) + '</option>').join('') +
        '</select></div>' +
        '<div class="field"><label class="label">Stok sistem</label>' +
        '<input id="o-sys" class="input num" readonly value="' + (Store.p(cur).stok) + '"></div>' +
        '<div class="field"><label class="label">Stok fisik <span class="req">*</span></label>' +
        '<input id="o-fis" class="input num" inputmode="numeric" value="' + (Store.p(cur).stok) + '" autofocus></div>' +
        '<div class="field full"><label class="label">Alasan selisih</label>' +
        '<input id="o-alasan" class="input" placeholder="mis. rusak, tumpah, salah hitung"></div>' +
        '</div>' +
        '<div class="alert-strip info mt-4" id="o-preview">' + Util.icon('list') + '<span class="grow">Selisih muncul di sini</span></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Sesuaikan stok', class: 'btn-primary', icon: 'check', onClick: (node, close) => {
            const res = Store.opname(node.querySelector('#o-pid').value, Util.parseNum(node.querySelector('#o-fis').value), node.querySelector('#o-alasan').value.trim());
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Stok disesuaikan (' + (res.diff > 0 ? '+' : '') + res.diff + ')', 'ok');
          }
        }
      ],
      onMount: (node) => {
        const pilih = node.querySelector('#o-pid');
        const sys = node.querySelector('#o-sys');
        const fis = node.querySelector('#o-fis');
        function sync() {
          const p = Store.p(pilih.value);
          sys.value = p ? p.stok : 0;
          const diff = Util.parseNum(fis.value) - (p ? Number(p.stok) : 0);
          const el = node.querySelector('#o-preview');
          el.className = 'alert-strip mt-4 ' + (diff === 0 ? 'info' : diff < 0 ? 'danger' : '');
          el.querySelector('span').innerHTML = diff === 0 ? 'Stok sudah sesuai.' :
            'Selisih <strong>' + (diff > 0 ? '+' : '') + diff + '</strong> unit' + (diff < 0 ? ' — akan mengurangi stok.' : ' — akan menambah stok.');
        }
        pilih.addEventListener('change', () => { fis.value = Store.p(pilih.value).stok; sync(); });
        fis.addEventListener('input', sync);
        sync();
      }
    });
  }

  global.Views = global.Views || {};
  global.Views.stok = mount;
})(window);
