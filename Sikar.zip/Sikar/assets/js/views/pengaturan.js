/* ============================================================
   views/pengaturan.js — toko, pajak, struk, PIN, backup
   ============================================================ */
(function (global) {
  'use strict';

  let W = null;

  function mount(root) {
    root.innerHTML = '<div class="view-anim" id="v-set">' +
      '<div class="view-head"><div class="vh-text"><h1>Pengaturan</h1>' +
      '<p>Data toko, pajak, struk, dan cadangan. Semua data tersimpan di perangkat ini — tidak dikirim ke mana pun.</p></div>' +
      '<div class="view-actions"><button class="btn" data-act="panduan">' + Util.icon('help') + ' Panduan</button>' +
      '<button class="btn btn-primary" data-act="simpan">' + Util.icon('check') + ' Simpan</button></div></div>' +
      '<div class="set-grid">' +
      // identitas
      '<div class="card"><div class="card-head"><div><div class="card-title">Identitas toko</div>' +
      '<div class="card-sub">muncul di struk dan laporan</div></div></div>' +
      '<div class="col" style="gap:12px">' +
      '<div class="field"><label class="label">Nama toko</label><input id="s-nama" class="input" value="' + Util.esc(Store.s.toko.nama) + '"></div>' +
      '<div class="field"><label class="label">Alamat</label><input id="s-alamat" class="input" value="' + Util.esc(Store.s.toko.alamat) + '"></div>' +
      '<div class="field"><label class="label">Telepon / WhatsApp</label><input id="s-telp" class="input" value="' + Util.esc(Store.s.toko.telp) + '"></div>' +
      '<div class="field"><label class="label">Nama kasir aktif</label><input id="s-kasir" class="input" value="' + Util.esc(Store.s.toko.kasir) + '"></div>' +
      '<div class="field"><label class="label">Ucapan di struk</label><input id="s-footer" class="input" value="' + Util.esc(Store.s.toko.footer) + '"></div>' +
      '</div></div>' +

      // pajak
      '<div class="card"><div class="card-head"><div><div class="card-title">Pajak &amp; biaya</div>' +
      '<div class="card-sub">dihitung setelah diskon</div></div></div>' +
      '<div class="set-row"><div class="txt"><strong>PPN / pajak</strong><span>tambahkan pajak ke total</span></div>' +
      '<div class="row row-tight"><input id="s-pajak" class="input num" style="width:70px;text-align:right" value="' + Store.s.toko.pajak + '">' +
      '<span class="tiny muted">%</span>' +
      '<label class="switch"><input type="checkbox" id="s-pajak-on"' + (Store.s.toko.pajakOn ? ' checked' : '') + '><span class="switch-track"></span></label></div></div>' +
      '<div class="set-row"><div class="txt"><strong>Service charge</strong><span>biaya layanan (opsional)</span></div>' +
      '<div class="row row-tight"><input id="s-service" class="input num" style="width:70px;text-align:right" value="' + Store.s.toko.service + '">' +
      '<span class="tiny muted">%</span>' +
      '<label class="switch"><input type="checkbox" id="s-service-on"' + (Store.s.toko.serviceOn ? ' checked' : '') + '><span class="switch-track"></span></label></div></div>' +
      '<div class="set-row"><div class="txt"><strong>Pembulatan ke Rp 100</strong><span>membantu hindari uang receh</span></div>' +
      '<label class="switch"><input type="checkbox" id="s-bulat"' + (Store.s.toko.bulatkan ? ' checked' : '') + '><span class="switch-track"></span></label></div>' +
      '<div class="set-row"><div class="txt"><strong>Lebar kertas struk</strong><span>printer thermal 58mm / 80mm</span></div>' +
      '<select id="s-cetak" class="select" style="width:110px"><option value="58"' + (Store.s.toko.cetak === 58 ? ' selected' : '') + '>58 mm</option>' +
      '<option value="80"' + (Store.s.toko.cetak !== 58 ? ' selected' : '') + '>80 mm</option></select></div>' +
      '</div>' +

      // qris
      '<div class="card"><div class="card-head"><div><div class="card-title">QRIS toko</div>' +
      '<div class="card-sub">tampil di layar pembayaran &amp; struk</div></div></div>' +
      '<div class="row" style="gap:14px;align-items:flex-start">' +
      '<div class="qr-preview" id="s-qr">' + (Store.s.toko.qris ? '<img src="' + Store.s.toko.qris + '" alt="QRIS">' : Util.icon('barcode', 'ic-lg')) + '</div>' +
      '<div class="col grow" style="gap:8px">' +
      '<input type="file" id="s-qr-file" accept="image/*" class="input" style="padding-top:7px">' +
      '<button class="btn btn-sm" data-act="qr-hapus">Hapus QRIS</button>' +
      '<p class="hint">Unggah gambar QRIS dari bank/e-wallet kamu. Gambar disimpan lokal di perangkat.</p>' +
      '</div></div></div>' +

      // keamanan
      '<div class="card"><div class="card-head"><div><div class="card-title">Keamanan</div>' +
      '<div class="card-sub">PIN untuk void, refund, dan reset data</div></div></div>' +
      '<div class="set-row"><div class="txt"><strong>PIN pemilik</strong><span>4 digit · bawaan 1234</span></div>' +
      '<button class="btn btn-sm" data-act="pin">Ganti PIN</button></div>' +
      '<div class="alert-strip info mt-3">' + Util.icon('lock') +
      '<span class="grow">Mode kasir tetap bisa transaksi; hanya tindakan sensitif yang meminta PIN.</span></div></div>' +

      // data
      '<div class="card"><div class="card-head"><div><div class="card-title">Data &amp; cadangan</div>' +
      '<div class="card-sub" id="s-size">menghitung…</div></div></div>' +
      '<div class="set-row"><div class="txt"><strong>Unduh backup (.json)</strong><span>semua produk, transaksi, stok</span></div>' +
      '<button class="btn btn-sm" data-act="backup">' + Util.icon('dl') + ' Unduh</button></div>' +
      '<div class="set-row"><div class="txt"><strong>Pulihkan dari backup</strong><span>menimpa data saat ini</span></div>' +
      '<label class="btn btn-sm" style="cursor:pointer">' + Util.icon('up') + ' Pilih berkas' +
      '<input type="file" id="s-restore" accept=".json,application/json" hidden></label></div>' +
      '<div class="set-row"><div class="txt"><strong>Muat ulang data demo</strong><span>produk &amp; transaksi contoh</span></div>' +
      '<button class="btn btn-sm" data-act="demo">' + Util.icon('flask') + ' Muat demo</button></div>' +
      '<div class="set-row"><div class="txt"><strong>Mulai dari kosong</strong><span>hapus semua data, siap dipakai toko asli</span></div>' +
      '<button class="btn btn-sm btn-danger" data-act="kosong">Kosongkan</button></div>' +
      '<div class="alert-strip mt-3">' + Util.icon('alert') +
      '<span class="grow">Data tersimpan di browser ini. Biasakan unduh backup tiap minggu, dan jangan pakai mode Incognito.</span></div></div>' +

      // tentang
      '<div class="card"><div class="card-head"><div><div class="card-title">Tentang Sikar</div>' +
      '<div class="card-sub">versi 1.0 · offline-first</div></div></div>' +
      '<div class="col" style="gap:8px">' +
      '<div class="kbd-row"><span>Jalan tanpa internet</span><span class="badge badge-ok">ya</span></div>' +
      '<div class="kbd-row"><span>Butuh server / langganan</span><span class="badge badge-ok">tidak</span></div>' +
      '<div class="kbd-row"><span>Data dikirim ke cloud</span><span class="badge badge-ok">tidak</span></div>' +
      '<div class="kbd-row"><span>Ekspor Excel asli (.xlsx)</span><span class="badge badge-ok">ya</span></div>' +
      '<div class="kbd-row"><span>Cetak thermal 58/80mm</span><span class="badge badge-ok">ya</span></div>' +
      '<p class="hint mt-2">Sikar dibuat untuk toko kecil yang butuh angka akurat tanpa biaya bulanan.</p>' +
      '</div></div>' +
      '</div></div>';

    W = root.querySelector('#v-set');

    W.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      const act = t.dataset.act;
      if (act === 'simpan') simpan();
      else if (act === 'pin') gantiPin();
      else if (act === 'backup') backup();
      else if (act === 'demo') muatDemo();
      else if (act === 'kosong') kosongkan();
      else if (act === 'qr-hapus') { Store.s.toko.qris = ''; Store.save('toko'); render(); }
      else if (act === 'panduan' && global.App) App.panduan();
    });

    W.querySelector('#s-qr-file').addEventListener('change', e => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      if (f.size > 900000) { Util.toast('Gambar terlalu besar (maks 900 KB)', 'err'); return; }
      const rd = new FileReader();
      rd.onload = () => {
        Store.s.toko.qris = String(rd.result || '');
        Store.save('toko');
        render();
        Util.toast('QRIS tersimpan', 'ok');
      };
      rd.readAsDataURL(f);
    });

    W.querySelector('#s-restore').addEventListener('change', e => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        try {
          const obj = JSON.parse(String(rd.result || '{}'));
          Util.confirm({
            title: 'Pulihkan backup?',
            body: 'Data saat ini akan diganti oleh isi berkas backup.',
            ok: 'Pulihkan', danger: true
          }).then(yes => {
            if (!yes) return;
            const res = Store.restore(obj);
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            Util.toast('Backup dipulihkan', 'ok');
          });
        } catch (err) { Util.toast('Berkas bukan JSON yang valid', 'err'); }
      };
      rd.readAsText(f);
      e.target.value = '';
    });

    ukuran();
    return { refresh() { /* biarkan form apa adanya saat store berubah */ } };
  }

  function render() {
    if (W && W.parentNode) {
      const root = W.parentNode;
      mount(root);
    }
  }

  function ukuran() {
    const el = W.querySelector('#s-size');
    if (!el) return;
    let bytes = 0;
    try { bytes = new Blob([JSON.stringify(Store.s)]).size; } catch (e) {}
    el.textContent = Store.s.produk.length + ' produk · ' + Store.s.penjualan.length + ' transaksi · ' +
      Util.bytes(bytes) + (Store.storageOk ? '' : ' · penyimpanan tidak tersedia');
  }

  function simpan() {
    const t = Store.s.toko;
    t.nama = W.querySelector('#s-nama').value.trim() || 'Toko Saya';
    t.alamat = W.querySelector('#s-alamat').value.trim();
    t.telp = W.querySelector('#s-telp').value.trim();
    t.kasir = W.querySelector('#s-kasir').value.trim() || 'Kasir';
    t.footer = W.querySelector('#s-footer').value.trim();
    t.pajak = Util.clamp(Util.parseNum(W.querySelector('#s-pajak').value), 0, 100);
    t.pajakOn = W.querySelector('#s-pajak-on').checked;
    t.service = Util.clamp(Util.parseNum(W.querySelector('#s-service').value), 0, 100);
    t.serviceOn = W.querySelector('#s-service-on').checked;
    t.bulatkan = W.querySelector('#s-bulat').checked;
    t.cetak = Number(W.querySelector('#s-cetak').value) === 58 ? 58 : 80;
    Store.save('toko');
    Util.toast('Pengaturan disimpan', 'ok');
  }

  function gantiPin() {
    Util.pin({ title: 'Verifikasi PIN lama', sub: 'Masukkan PIN yang sekarang dipakai.' }).then(ok => {
      if (!ok) return;
      Util.modal({
        title: 'PIN baru', narrow: true,
        body: '<div class="field"><label class="label">PIN baru (4 digit)</label>' +
          '<input id="np" class="input input-lg mono" inputmode="numeric" maxlength="4" style="letter-spacing:.4em;text-align:center" autofocus></div>' +
          '<div class="field mt-3"><label class="label">Ulangi PIN</label>' +
          '<input id="np2" class="input input-lg mono" inputmode="numeric" maxlength="4" style="letter-spacing:.4em;text-align:center"></div>',
        actions: [
          { label: 'Batal', class: 'btn-ghost' },
          {
            label: 'Simpan PIN', class: 'btn-primary', onClick: (node, close) => {
              const a = node.querySelector('#np').value.trim();
              const b = node.querySelector('#np2').value.trim();
              if (!/^\d{4}$/.test(a)) { Util.toast('PIN harus 4 angka', 'err'); return; }
              if (a !== b) { Util.toast('PIN tidak sama', 'err'); return; }
              Store.s.toko.pin = a;
              Store.save('toko');
              close();
              Util.toast('PIN diperbarui', 'ok');
            }
          }
        ]
      });
    });
  }

  function backup() {
    const data = Store.backup();
    Util.downloadJSON(data, 'sikar-backup-' + Util.dayKey(Date.now()) + '.json');
    Util.toast('Backup diunduh', 'ok');
  }

  async function muatDemo() {
    const yes = await Util.confirm({
      title: 'Muat data demo?',
      body: 'Data saat ini akan diganti dengan data contoh (produk, transaksi 21 hari, shift).',
      ok: 'Muat demo', danger: true
    });
    if (!yes) return;
    Store.resetDemo();
    Util.toast('Data demo dimuat', 'ok');
  }

  async function kosongkan() {
    const ok = await Util.pin({ title: 'Kosongkan data', sub: 'Semua transaksi & produk akan dihapus permanen.' });
    if (!ok) return;
    const yes = await Util.confirm({
      title: 'Yakin mulai dari kosong?',
      body: 'Disarankan unduh backup dulu. Tindakan ini tidak bisa dibatalkan.',
      ok: 'Hapus semua', danger: true
    });
    if (!yes) return;
    Store.resetKosong();
    Util.toast('Data dikosongkan — siap dipakai', 'ok');
  }

  global.Views = global.Views || {};
  global.Views.pengaturan = mount;
})(window);
