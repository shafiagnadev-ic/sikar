/* ============================================================
   views/shift.js — buka/tutup kasir, hitung laci, Z-report
   ============================================================ */
(function (global) {
  'use strict';

  let W = null;
  const PECAHAN = [100000, 50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100];

  function mount(root) {
    root.innerHTML = '<div class="view-anim" id="v-shift">' +
      '<div class="view-head"><div class="vh-text"><h1>Shift kasir</h1>' +
      '<p>Setiap shift punya modal awal, kas seharusnya, dan selisih saat tutup. Cocok untuk serah-terima antar kasir.</p></div>' +
      '<div class="view-actions" id="sh-actions"></div></div>' +
      '<div id="sh-body"></div></div>';
    W = root.querySelector('#v-shift');
    W.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      const act = t.dataset.act;
      if (act === 'buka') formBuka();
      else if (act === 'tutup') formTutup();
      else if (act === 'z') zReport(t.dataset.id);
      else if (act === 'ringkas') { const s = Store.shiftAktif(); if (s) zReport(s.id); }
    });
    render();
    return { refresh() { render(); } };
  }

  function render() {
    const sh = Store.shiftAktif();
    const riwayat = Store.shiftRiwayat().slice(0, 12);
    if (sh) {
      const r = Store.ringkasShift(sh);
      W.querySelector('#sh-actions').innerHTML =
        '<button class="btn" data-act="z">' + Util.icon('printer') + ' Ringkasan</button>' +
        '<button class="btn btn-primary" data-act="tutup">' + Util.icon('lock') + ' Tutup kasir</button>';
      W.querySelector('#sh-body').innerHTML =
        '<div class="grid grid-4" style="margin-bottom:16px">' +
        '<div class="kpi kpi-accent"><div class="kpi-label">Shift aktif</div><div class="kpi-value sm">' + Util.esc(sh.kasir) + '</div>' +
        '<div class="kpi-sub">buka ' + Util.fmtTime(sh.buka) + ' · ' + Util.fmtDur(Date.now() - sh.buka) + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Omzet shift</div><div class="kpi-value sm">' + Util.rp(r.omzet) + '</div>' +
        '<div class="kpi-sub">' + r.trx + ' transaksi</div></div>' +
        '<div class="kpi"><div class="kpi-label">Tunai di laci</div><div class="kpi-value sm">' + Util.rp(r.tunai) + '</div>' +
        '<div class="kpi-sub">non-tunai ' + Util.rp(r.nonTunai) + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Kas seharusnya</div><div class="kpi-value sm">' + Util.rp(r.harapan) + '</div>' +
        '<div class="kpi-sub">modal ' + Util.rp(sh.modalAwal) + ' + tunai</div></div></div>' +
        '<div class="split">' +
        '<div class="card card-flush"><div class="card-head"><div><div class="card-title">Transaksi shift ini</div>' +
        '<div class="card-sub">' + Util.fmtDateTime(sh.buka) + ' — sekarang</div></div></div>' +
        '<div class="table-wrap" style="max-height:360px"><table class="tbl"><thead><tr><th>Jam</th><th>Nota</th>' +
        '<th class="right">Total</th><th>Bayar</th></tr></thead><tbody>' +
        (Store.s.penjualan.filter(x => x.shiftId === sh.id && x.status !== 'void').sort((a, b) => b.at - a.at).slice(0, 40).map(x =>
          '<tr><td class="tiny">' + Util.fmtTime(x.at) + '</td><td class="tiny mono">' + Util.esc(x.no) + '</td>' +
          '<td class="num">' + Util.rp(x.total) + '</td><td class="tiny muted">' +
          Util.esc((x.bayar || []).map(b => b.metode).join(' + ')) + '</td></tr>').join('') ||
          '<tr><td colspan="4"><div class="empty">' + Util.icon('receipt') + '<strong>Belum ada transaksi</strong></div></td></tr>') +
        '</tbody></table></div></div>' +
        '<div class="card"><div class="card-title">Cara tutup kasir</div>' +
        '<ol class="small dim" style="display:flex;flex-direction:column;gap:8px;margin-top:10px;padding-left:18px;list-style:decimal">' +
        '<li>Hitung uang fisik di laci.</li>' +
        '<li>Masukkan jumlah per pecahan (opsional, untuk memudahkan hitung).</li>' +
        '<li>Sistem bandingkan dengan kas seharusnya dan tampilkan selisih.</li>' +
        '<li>Cetak Z-report sebagai bukti serah-terima.</li></ol>' +
        '<div class="alert-strip info mt-4">' + Util.icon('lock') +
        '<span class="grow">Setelah ditutup, transaksi baru tidak bisa masuk sampai kasir dibuka lagi.</span></div>' +
        '</div></div>';
    } else {
      W.querySelector('#sh-actions').innerHTML =
        '<button class="btn btn-primary" data-act="buka">' + Util.icon('wallet') + ' Buka kasir</button>';
      W.querySelector('#sh-body').innerHTML =
        '<div class="card" style="margin-bottom:16px;text-align:center;padding:34px 20px">' +
        '<div style="width:56px;height:56px;border-radius:16px;background:var(--accent-soft);color:var(--accent-ink);display:grid;place-items:center;margin:0 auto 12px">' +
        Util.icon('lock', 'ic-lg') + '</div>' +
        '<h2 style="font-size:20px">Kasir belum dibuka</h2>' +
        '<p class="muted small" style="max-width:44ch;margin:6px auto 16px">Buka shift dengan modal awal uang kembalian. ' +
        'Semua transaksi akan terikat ke shift ini supaya hitungan laci akurat.</p>' +
        '<button class="btn btn-primary btn-lg" data-act="buka">' + Util.icon('wallet') + ' Buka kasir sekarang</button>' +
        '</div>';
    }

    W.querySelector('#sh-body').insertAdjacentHTML('beforeend',
      '<div class="card card-flush mt-4"><div class="card-head"><div><div class="card-title">Riwayat shift</div>' +
      '<div class="card-sub">selisih kas per shift</div></div></div>' +
      '<div class="table-wrap"><table class="tbl"><thead><tr><th>Tanggal</th><th>Kasir</th>' +
      '<th class="right">Omzet</th><th class="right">Kas dihitung</th><th class="right">Selisih</th><th></th></tr></thead><tbody>' +
      (riwayat.length ? riwayat.map(s => {
        const sel = Number(s.selisih) || 0;
        return '<tr><td class="tiny">' + Util.fmtDate(s.buka) + ' · ' + Util.fmtTime(s.buka) + '</td>' +
          '<td class="small">' + Util.esc(s.kasir || '-') + '</td>' +
          '<td class="num">' + Util.rp(s.ringkas ? s.ringkas.omzet : (Store.ringkasShift(s).omzet)) + '</td>' +
          '<td class="num">' + (s.hitung != null ? Util.rp(s.hitung) : '—') + '</td>' +
          '<td class="num"><span class="badge ' + (sel === 0 ? 'badge-ok' : sel < 0 ? 'badge-danger' : 'badge-warn') + '">' +
          (sel === 0 ? 'pas' : (sel > 0 ? '+' : '') + Util.rp(sel)) + '</span></td>' +
          '<td class="right"><button class="btn-icon" data-act="z" data-id="' + s.id + '" title="Z-report">' + Util.icon('printer') + '</button></td></tr>';
      }).join('') : '<tr><td colspan="6"><div class="empty">' + Util.icon('wallet') + '<strong>Belum ada shift ditutup</strong></div></td></tr>') +
      '</tbody></table></div></div>');
  }

  function formBuka() {
    Util.modal({
      title: 'Buka kasir',
      sub: 'Modal awal = uang kembalian yang kamu taruh di laci.',
      narrow: true,
      body: '<div class="field"><label class="label">Modal awal (Rp)</label>' +
        '<input id="b-modal" class="input input-lg input-money" inputmode="numeric" value="200.000"></div>' +
        '<div class="quick-cash mt-3" id="b-quick"></div>' +
        '<div class="field mt-4"><label class="label">Nama kasir</label>' +
        '<input id="b-kasir" class="input" value="' + Util.esc(Store.s.toko.kasir || '') + '"></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Buka kasir', class: 'btn-primary', icon: 'check', onClick: (node, close) => {
            const res = Store.bukaShift(Util.parseNum(node.querySelector('#b-modal').value), node.querySelector('#b-kasir').value.trim());
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Kasir dibuka · modal ' + Util.rp(res.shift.modalAwal), 'ok');
          }
        }
      ],
      onMount: (node) => {
        const inp = node.querySelector('#b-modal');
        Util.moneyInput(inp);
        const q = node.querySelector('#b-quick');
        q.innerHTML = [100000, 200000, 300000, 500000].map(v =>
          '<button class="qcash" data-v="' + v + '">' + Util.num(v) + '</button>').join('');
        q.querySelectorAll('[data-v]').forEach(b => b.addEventListener('click', () => { inp.value = Util.num(b.dataset.v); }));
        setTimeout(() => inp.focus(), 60);
      }
    });
  }

  function formTutup() {
    const sh = Store.shiftAktif();
    if (!sh) return;
    const r = Store.ringkasShift(sh);
    Util.modal({
      title: 'Tutup kasir',
      sub: 'Hitung uang fisik di laci, lalu cocokkan dengan sistem.',
      wide: true,
      body:
        '<div class="split">' +
        '<div>' +
        '<div class="alert-strip info" style="margin-bottom:12px">' + Util.icon('wallet') +
        '<span class="grow">Kas seharusnya <strong>' + Util.rp(r.harapan) + '</strong> (modal ' + Util.rp(sh.modalAwal) +
        ' + tunai ' + Util.rp(r.tunai) + ')</span></div>' +
        '<div class="pecahan-grid" id="t-pecahan"></div>' +
        '</div>' +
        '<div class="col" style="gap:12px">' +
        '<div class="card" style="background:var(--panel-2)">' +
        '<div class="kpi-label">Total uang dihitung</div>' +
        '<div class="shift-big" id="t-total">Rp 0</div>' +
        '<div class="row mt-2"><button class="btn btn-sm" id="t-pas">Isi sesuai sistem</button>' +
        '<button class="btn btn-sm" id="t-reset">Reset</button></div></div>' +
        '<div class="kembalian" id="t-selisih"><span class="lbl">Selisih</span><span class="val">Rp 0</span></div>' +
        '<div class="table-wrap" style="border:1px solid var(--line);border-radius:10px">' +
        '<table class="tbl"><tbody>' +
        '<tr><td class="small muted">Omzet shift</td><td class="num">' + Util.rp(r.omzet) + '</td></tr>' +
        '<tr><td class="small muted">Transaksi</td><td class="num">' + r.trx + '</td></tr>' +
        '<tr><td class="small muted">Tunai</td><td class="num">' + Util.rp(r.tunai) + '</td></tr>' +
        '<tr><td class="small muted">Non-tunai</td><td class="num">' + Util.rp(r.nonTunai) + '</td></tr>' +
        (r.refund ? '<tr><td class="small muted">Refund</td><td class="num">' + Util.rp(r.refund) + '</td></tr>' : '') +
        '</tbody></table></div></div></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Tutup & cetak Z-report', class: 'btn-primary', icon: 'lock', onClick: (node, close) => {
            const counts = {};
            let total = 0;
            node.querySelectorAll('[data-pec]').forEach(inp => {
              const n = Util.parseNum(inp.value);
              if (n > 0) { counts[inp.dataset.pec] = n; total += n * Number(inp.dataset.pec); }
            });
            const res = Store.tutupShift(total, counts);
            if (!res.ok) { Util.toast(res.error, 'err'); return; }
            close();
            Util.toast('Shift ditutup · selisih ' + Util.rp(res.shift.selisih), Math.abs(res.shift.selisih) > 0 ? 'warn' : 'ok', 4000);
            setTimeout(() => zReport(res.shift.id), 250);
          }
        }
      ],
      onMount: (node) => {
        const grid = node.querySelector('#t-pecahan');
        grid.innerHTML = PECAHAN.map(p =>
          '<div class="pecahan"><span class="nom">' + Util.num(p) + '</span>' +
          '<input data-pec="' + p + '" inputmode="numeric" placeholder="0">' +
          '<span class="sub" data-sub="' + p + '">0</span></div>').join('');
        function hitung() {
          let total = 0;
          grid.querySelectorAll('[data-pec]').forEach(inp => {
            const n = Util.parseNum(inp.value);
            const sub = n * Number(inp.dataset.pec);
            total += sub;
            grid.querySelector('[data-sub="' + inp.dataset.pec + '"]').textContent = sub ? Util.num(sub) : '0';
          });
          node.querySelector('#t-total').textContent = Util.rp(total);
          const sel = total - r.harapan;
          const el = node.querySelector('#t-selisih');
          el.className = 'kembalian ' + (sel === 0 ? 'ok' : sel < 0 ? 'kurang' : 'ok');
          el.innerHTML = '<span class="lbl">' + (sel === 0 ? 'Pas' : sel > 0 ? 'Lebih' : 'Kurang') + '</span>' +
            '<span class="val">' + Util.rp(Math.abs(sel)) + '</span>';
          return total;
        }
        grid.addEventListener('input', hitung);
        node.querySelector('#t-reset').addEventListener('click', () => {
          grid.querySelectorAll('[data-pec]').forEach(i => { i.value = ''; });
          hitung();
        });
        node.querySelector('#t-pas').addEventListener('click', () => {
          // isi otomatis: uang kertas besar mendekati nilai harapan
          grid.querySelectorAll('[data-pec]').forEach(i => { i.value = ''; });
          let sisa = r.harapan;
          PECAHAN.forEach(p => {
            if (p > sisa) return;
            const n = Math.floor(sisa / p);
            if (n > 0) { grid.querySelector('[data-pec="' + p + '"]').value = n; sisa -= n * p; }
          });
          hitung();
        });
        hitung();
      }
    });
  }

  function zReport(id) {
    const sh = Store.s.shift.find(x => x.id === id);
    if (!sh) return;
    if (!sh.ringkas) sh.ringkas = Store.ringkasShift(sh);
    Util.modal({
      title: 'Z-report',
      sub: Util.fmtDateTime(sh.buka) + (sh.tutup ? ' — ' + Util.fmtTime(sh.tutup) : ''),
      body: '<div class="row" style="gap:16px;align-items:flex-start">' +
        '<div class="grow"><div class="grid grid-2" style="gap:10px">' +
        '<div class="kpi"><div class="kpi-label">Omzet</div><div class="kpi-value sm">' + Util.rp(sh.ringkas.omzet) + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Transaksi</div><div class="kpi-value">' + sh.ringkas.trx + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Tunai</div><div class="kpi-value sm">' + Util.rp(sh.ringkas.tunai) + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Non-tunai</div><div class="kpi-value sm">' + Util.rp(sh.ringkas.nonTunai) + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Kas seharusnya</div><div class="kpi-value sm">' + Util.rp(sh.ringkas.harapan) + '</div></div>' +
        '<div class="kpi"><div class="kpi-label">Selisih</div><div class="kpi-value sm ' + (Number(sh.selisih) === 0 ? '' : 'ledger-out') + '">' +
        (sh.selisih == null ? '—' : Util.rp(sh.selisih)) + '</div></div></div></div>' +
        '<div style="width:250px;flex:0 0 auto"><div class="struk">' + Print.zReport(sh) + '</div></div></div>',
      wide: true,
      actions: [
        { label: 'Tutup', class: 'btn-ghost' },
        { label: 'Cetak', class: 'btn-primary', icon: 'printer', onClick: () => Print.print(Print.zReport(sh), 80) }
      ]
    });
  }

  global.Views = global.Views || {};
  global.Views.shift = mount;
})(window);
