/* ============================================================
   views/laporan.js — laba, tren, ABC, ekspor Excel
   ============================================================ */
(function (global) {
  'use strict';

  let W = null;
  let periode = '30';

  function mount(root) {
    root.innerHTML =
      '<div class="view-anim" id="v-laporan">' +
      '<div class="view-head"><div class="vh-text"><h1>Laporan</h1>' +
      '<p>Bukan cuma omzet: laba kotor sudah dikurangi HPP, jadi kelihatan produk mana yang benar-benar menghasilkan uang.</p></div>' +
      '<div class="view-actions">' +
      '<select id="l-periode" class="select" style="width:160px">' +
      '<option value="hari">Hari ini</option><option value="7">7 hari</option>' +
      '<option value="30" selected>30 hari</option><option value="90">90 hari</option>' +
      '<option value="bulan">Bulan ini</option><option value="semua">Semua</option></select>' +
      '<button class="btn" data-act="cetak">' + Util.icon('printer') + ' Cetak</button>' +
      '<button class="btn btn-primary" data-act="excel">' + Util.icon('dl') + ' Excel</button>' +
      '</div></div><div id="l-body"></div></div>';
    W = root.querySelector('#v-laporan');
    W.querySelector('#l-periode').addEventListener('change', e => { periode = e.target.value; render(); });
    W.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      if (t.dataset.act === 'excel') eksporExcel();
      if (t.dataset.act === 'cetak') cetakRingkas();
    });
    render();
    return { refresh() { render(); } };
  }

  function rentang() {
    const now = Date.now();
    if (periode === 'hari') return [Util.startOfDay(now), Util.endOfDay(now)];
    if (periode === 'bulan') {
      const d = new Date();
      return [new Date(d.getFullYear(), d.getMonth(), 1).getTime(), Util.endOfDay(now)];
    }
    if (periode === 'semua') {
      const first = Store.s.penjualan.length ? Math.min.apply(null, Store.s.penjualan.map(x => x.at)) : now;
      return [Util.startOfDay(first), Util.endOfDay(now)];
    }
    const n = Number(periode) || 30;
    return [Util.startOfDay(Util.addDays(now, -(n - 1))), Util.endOfDay(now)];
  }

  function render() {
    const [from, to] = rentang();
    const k = Store.kpi(from, to);
    const hariArr = hariSeries(from, to, k);
    const prevFrom = from - (to - from) - 86400000;
    const kPrev = Store.kpi(prevFrom, from - 1);
    const delta = kPrev.omzet ? (k.omzet - kPrev.omzet) / kPrev.omzet * 100 : 0;
    const margin = k.omzet ? (k.laba / k.omzet * 100) : 0;

    const topKat = Object.keys(k.kat).sort((a, b) => k.kat[b] - k.kat[a]);
    const jamSibuk = k.jam.indexOf(Math.max.apply(null, k.jam));
    const mati = Store.deadStock(periode === 'hari' ? 1 : periode === 'semua' ? 90 : Number(periode) || 30);
    const modalMati = Util.sum(mati, p => (Number(p.stok) || 0) * (Number(p.hpp) || 0));
    const rugi = k.rugi.slice(0, 5);

    W.querySelector('#l-body').innerHTML =
      // KPI
      '<div class="grid grid-4" style="margin-bottom:16px">' +
      '<div class="kpi kpi-accent"><div class="kpi-label">Omzet</div><div class="kpi-value sm">' + Util.rp(k.omzet) + '</div>' +
      '<div class="kpi-sub">' + (delta === 0 ? 'tidak ada pembanding' :
        '<span class="trend ' + (delta >= 0 ? 'up' : 'down') + '">' + Util.icon(delta >= 0 ? 'arrow-up' : 'arrow-down') +
        Math.abs(delta).toFixed(0) + '%</span> vs periode lalu') + '</div></div>' +
      '<div class="kpi"><div class="kpi-label">Laba kotor</div><div class="kpi-value sm">' + Util.rp(k.laba) + '</div>' +
      '<div class="kpi-sub">margin ' + margin.toFixed(0) + '% · HPP ' + Util.rp(k.hpp) + '</div></div>' +
      '<div class="kpi"><div class="kpi-label">Transaksi</div><div class="kpi-value">' + k.trx + '</div>' +
      '<div class="kpi-sub">' + k.item + ' item terjual</div></div>' +
      '<div class="kpi"><div class="kpi-label">Rata-rata / transaksi</div><div class="kpi-value sm">' + Util.rp(k.basket) + '</div>' +
      '<div class="kpi-sub">tunai ' + Util.rp(k.tunai) + '</div></div></div>' +

      // insight
      '<div class="grid grid-2" style="margin-bottom:16px;gap:12px">' +
      insightCard(k, topKat, jamSibuk, mati, modalMati) +
      '</div>' +

      // chart omzet
      '<div class="card" style="margin-bottom:16px">' +
      '<div class="card-head"><div><div class="card-title">Omzet harian</div>' +
      '<div class="card-sub">' + Util.fmtDate(from) + ' — ' + Util.fmtDate(to) + '</div></div>' +
      '<div class="legend"><span><i style="background:var(--accent)"></i>Omzet</span>' +
      '<span><i style="background:var(--info)"></i>Laba</span></div></div>' +
      barChart(hariArr, { h: 210, label: 'Omzet harian', dual: true }) + '</div>' +

      // jam + kategori
      '<div class="grid grid-2" style="margin-bottom:16px">' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Jam sibuk</div>' +
      '<div class="card-sub">total omzet per jam</div></div></div>' +
      hourHeat(k.jam) + '</div>' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Omzet per kategori</div>' +
      '<div class="card-sub">kontribusi terhadap omzet</div></div></div>' +
      katList(k) + '</div></div>' +

      // top produk + metode
      '<div class="grid grid-2" style="margin-bottom:16px">' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Produk terlaris</div>' +
      '<div class="card-sub">berdasarkan omzet</div></div><span class="badge badge-muted">' + k.produk.length + ' produk terjual</span></div>' +
      rankList(k.topOmzet.slice(0, 8), 'omzet') + '</div>' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Metode pembayaran</div>' +
      '<div class="card-sub">ke mana uang masuk</div></div></div>' +
      metodeList(k) + '</div></div>' +

      // ABC + rugi + mati
      '<div class="grid grid-2" style="margin-bottom:16px">' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Analisis ABC</div>' +
      '<div class="card-sub">produk A = 80% omzet pertama</div></div></div>' + abcTable(k) + '</div>' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Perlu perhatian</div>' +
      '<div class="card-sub">margin negatif & barang mati</div></div></div>' + perhatian(rugi, mati, modalMati) + '</div></div>' +

      '<div class="card"><div class="card-head"><div><div class="card-title">Rincian per produk</div>' +
      '<div class="card-sub">qty, omzet, HPP, laba, margin</div></div>' +
      '<button class="btn btn-sm" data-act="excel">' + Util.icon('dl') + ' Unduh Excel</button></div>' +
      '<div class="table-wrap" style="max-height:420px"><table class="tbl"><thead><tr>' +
      '<th>Produk</th><th>Kategori</th><th class="right">Qty</th><th class="right">Omzet</th>' +
      '<th class="right">HPP</th><th class="right">Laba</th><th class="right">Margin</th></tr></thead><tbody>' +
      (k.margin.length ? Util.sortBy(k.margin, x => x.omzet, true).map(x =>
        '<tr><td class="truncate" style="max-width:260px">' + Util.esc(x.nama) + '</td>' +
        '<td class="tiny muted">' + Util.esc(x.kategori) + '</td>' +
        '<td class="num">' + x.qty + '</td><td class="num">' + Util.rp(x.omzet) + '</td>' +
        '<td class="num muted">' + Util.rp(x.hpp) + '</td>' +
        '<td class="num ' + (x.margin < 0 ? 'ledger-out' : 'ledger-in') + '">' + Util.rp(x.margin) + '</td>' +
        '<td class="num"><span class="badge ' + (x.margin < 0 ? 'badge-danger' : x.marginPct < 15 ? 'badge-warn' : 'badge-ok') + '">' +
        x.marginPct.toFixed(0) + '%</span></td></tr>').join('')
        : '<tr><td colspan="7"><div class="empty">' + Util.icon('chart') + '<strong>Belum ada penjualan</strong></div></td></tr>') +
      '</tbody></table></div></div>';
  }

  function insightCard(k, topKat, jamSibuk, mati, modalMati) {
    const items = [];
    if (topKat.length) {
      const total = Util.sum(Object.values(k.kat));
      items.push('<strong>' + Util.esc(topKat[0]) + '</strong> menyumbang ' + (k.kat[topKat[0]] / (total || 1) * 100).toFixed(0) + '% omzet');
    }
    if (k.omzet) items.push('jam tersibuk <strong>' + String(jamSibuk).padStart(2, '0') + ':00</strong> (' + Util.rp(k.jam[jamSibuk]) + ')');
    if (mati.length) items.push('<strong>' + mati.length + ' produk</strong> tidak laku, modal tertahan ' + Util.rp(modalMati));
    if (k.rugi.length) items.push('<strong>' + k.rugi.length + ' produk</strong> dijual di bawah HPP');
    if (k.refund) items.push('refund ' + Util.rp(k.refund) + ' pada periode ini');
    return '<div class="card" style="background:var(--panel-2)">' +
      '<div class="card-head"><div><div class="card-title">' + Util.icon('bolt') + ' Yang perlu kamu tahu</div>' +
      '<div class="card-sub">dihitung otomatis dari data periode ini</div></div></div>' +
      (items.length ? '<ul style="display:flex;flex-direction:column;gap:7px">' + items.map(i =>
        '<li class="small dim" style="display:flex;gap:8px;align-items:flex-start"><span class="dot" style="margin-top:6px;background:var(--accent)"></span><span>' + i + '</span></li>').join('') + '</ul>'
        : '<p class="small muted">Belum cukup data untuk insight.</p>') +
      '</div>' +
      '<div class="card"><div class="card-head"><div><div class="card-title">Uang masuk</div>' +
      '<div class="card-sub">tunai vs non-tunai</div></div></div>' +
      '<div class="row" style="gap:16px;align-items:flex-end"><div class="grow"><div class="kpi-label">Tunai</div>' +
      '<div class="big strong">' + Util.rp(k.tunai) + '</div></div>' +
      '<div class="grow"><div class="kpi-label">Non-tunai</div><div class="big strong">' + Util.rp(k.nonTunai) + '</div></div></div>' +
      '<div class="bar mt-3"><i style="width:' + (k.omzet ? (k.tunai / (k.tunai + k.nonTunai || 1) * 100) : 0) + '%"></i></div>' +
      '<p class="hint mt-2">' + (k.tunai + k.nonTunai ? (k.tunai / (k.tunai + k.nonTunai) * 100).toFixed(0) + '% pembayaran tunai' : 'Belum ada pembayaran') + '</p>' +
      '</div>';
  }

  function hariSeries(from, to, k) {
    const out = [];
    let t = Util.startOfDay(from);
    const end = Util.startOfDay(to);
    let guard = 0;
    while (t <= end && guard < 400) {
      const key = Util.dayKey(t);
      const d = k.hari[key] || { omzet: 0, laba: 0, trx: 0 };
      out.push({ key, label: new Date(t).getDate() + '/' + (new Date(t).getMonth() + 1), v: d.omzet, v2: Math.max(0, d.laba), trx: d.trx });
      t = Util.addDays(t, 1);
      guard++;
    }
    return out;
  }

  function barChart(items, opts) {
    opts = opts || {};
    const H = opts.h || 200, Wd = 720;
    const pl = 48, pr = 8, pt = 14, pb = 26;
    const pw = Wd - pl - pr, ph = H - pt - pb;
    const max = Math.max(1, ...items.map(i => i.v));
    const step = pw / Math.max(1, items.length);
    const bw = Math.min(30, step * (opts.dual ? 0.34 : 0.62));
    const ticks = 4;
    let g = '';
    for (let i = 0; i <= ticks; i++) {
      const y = pt + ph - (ph * i / ticks);
      const val = max * i / ticks;
      g += '<line x1="' + pl + '" y1="' + y + '" x2="' + (Wd - pr) + '" y2="' + y + '"/>' +
        '<text x="' + (pl - 8) + '" y="' + (y + 3.5) + '" text-anchor="end">' + shortNum(val) + '</text>';
    }
    let bars = '';
    const labelEvery = Math.ceil(items.length / 12);
    items.forEach((it, i) => {
      const x = pl + step * i + step / 2;
      const h = it.v / max * ph;
      const h2 = (it.v2 || 0) / max * ph;
      if (opts.dual) {
        bars += '<rect class="c-bar" x="' + (x - bw - 1) + '" y="' + (pt + ph - h) + '" width="' + bw + '" height="' + Math.max(0, h) + '" rx="2">' +
          '<title>' + it.label + ': ' + Util.rp(it.v) + '</title></rect>' +
          '<rect class="c-bar" style="fill:var(--info)" x="' + (x + 1) + '" y="' + (pt + ph - h2) + '" width="' + bw + '" height="' + Math.max(0, h2) + '" rx="2">' +
          '<title>' + it.label + ': laba ' + Util.rp(it.v2) + '</title></rect>';
      } else {
        bars += '<rect class="c-bar" x="' + (x - bw / 2) + '" y="' + (pt + ph - h) + '" width="' + bw + '" height="' + Math.max(0, h) + '" rx="2">' +
          '<title>' + it.label + ': ' + Util.rp(it.v) + '</title></rect>';
      }
      if (i % labelEvery === 0) {
        bars += '<text class="c-lbl" x="' + x + '" y="' + (H - 8) + '" text-anchor="middle">' + it.label + '</text>';
      }
    });
    return '<div class="chart"><svg viewBox="0 0 ' + Wd + ' ' + H + '" role="img" aria-label="' + Util.esc(opts.label || 'Grafik') + '">' +
      '<g class="c-grid">' + g + '</g>' + bars + '</svg></div>';
  }

  function shortNum(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace('.', ',') + 'M';
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace('.', ',') + 'jt';
    if (n >= 1e3) return Math.round(n / 1e3) + 'rb';
    return String(Math.round(n));
  }

  function hourHeat(jam) {
    const max = Math.max(1, ...jam);
    let cells = '';
    for (let h = 0; h < 24; h++) {
      const v = jam[h] || 0;
      const a = v / max;
      const bg = v === 0 ? 'var(--panel-3)' : 'color-mix(in srgb, var(--accent) ' + Math.round(18 + a * 72) + '%, var(--panel))';
      cells += '<div class="heat-cell ' + (v === 0 ? 'zero' : '') + '" style="background:' + bg + '" title="' +
        String(h).padStart(2, '0') + ':00 — ' + Util.rp(v) + '">' + (h % 3 === 0 ? h : '') + '</div>';
    }
    return '<div class="heat">' + cells + '</div>' +
      '<div class="row row-between mt-3 tiny muted"><span>00:00</span><span>12:00</span><span>23:00</span></div>';
  }

  function katList(k) {
    const arr = Object.keys(k.kat).map(name => ({ name, v: k.kat[name] })).sort((a, b) => b.v - a.v);
    if (!arr.length) return '<div class="empty">' + Util.icon('tag') + '<strong>Belum ada data</strong></div>';
    const max = arr[0].v || 1;
    return arr.map(x => '<div style="margin-bottom:10px">' +
      '<div class="row row-between tiny" style="margin-bottom:4px"><span class="strong">' + Util.esc(x.name) + '</span>' +
      '<span class="muted">' + Util.rp(x.v) + '</span></div>' +
      '<div class="bar"><i style="width:' + (x.v / max * 100) + '%"></i></div></div>').join('');
  }

  function rankList(arr, key) {
    if (!arr.length) return '<div class="empty">' + Util.icon('box') + '<strong>Belum ada penjualan</strong></div>';
    const max = arr[0][key] || 1;
    return '<div class="rank-list">' + arr.map((x, i) =>
      '<div class="rank-item"><span class="rank-n">' + (i + 1) + '</span>' +
      '<span class="rank-name truncate">' + Util.esc(x.nama) + '<span class="tiny muted"> · ' + x.qty + ' pcs</span></span>' +
      '<span class="rank-bar"><span class="bar"><i style="width:' + (x[key] / max * 100) + '%"></i></span></span>' +
      '<span class="rank-val">' + Util.rp(x[key]) + '</span></div>').join('') + '</div>';
  }

  function metodeList(k) {
    const arr = Object.keys(k.metode).map(m => ({ m, v: k.metode[m] })).sort((a, b) => b.v - a.v);
    if (!arr.length) return '<div class="empty">' + Util.icon('wallet') + '<strong>Belum ada pembayaran</strong></div>';
    const total = Util.sum(arr, x => x.v) || 1;
    return arr.map(x => '<div style="margin-bottom:10px">' +
      '<div class="row row-between tiny" style="margin-bottom:4px"><span class="strong">' + Util.esc(x.m) + '</span>' +
      '<span class="muted">' + Util.rp(x.v) + ' · ' + (x.v / total * 100).toFixed(0) + '%</span></div>' +
      '<div class="bar"><i style="width:' + (x.v / total * 100) + '%"></i></div></div>').join('');
  }

  function abcTable(k) {
    if (!k.abc.length) return '<div class="empty">' + Util.icon('chart') + '<strong>Belum ada data</strong></div>';
    const kelas = { A: [], B: [], C: [] };
    k.abc.forEach(x => kelas[x.kelas].push(x));
    const totalOmzet = k.totalOmzetProduk || 1;
    return '<div class="grid grid-3" style="gap:10px;margin-bottom:12px">' +
      ['A', 'B', 'C'].map(c => {
        const arr = kelas[c];
        const v = Util.sum(arr, x => x.omzet);
        return '<div style="padding:10px;border-radius:10px;border:1px solid var(--line);background:var(--panel-2)">' +
          '<div class="kpi-label">Kelas ' + c + '</div>' +
          '<div class="big strong">' + arr.length + '</div>' +
          '<div class="tiny muted">' + (v / totalOmzet * 100).toFixed(0) + '% omzet</div></div>';
      }).join('') + '</div>' +
      '<div class="table-wrap" style="max-height:230px"><table class="tbl"><thead><tr><th>#</th><th>Produk</th>' +
      '<th class="right">Omzet</th><th class="right">Kumulatif</th></tr></thead><tbody>' +
      k.abc.slice(0, 30).map((x, i) => '<tr><td class="num tiny">' + (i + 1) + '</td>' +
        '<td class="truncate" style="max-width:200px">' + Util.esc(x.nama) + ' <span class="badge badge-muted">' + x.kelas + '</span></td>' +
        '<td class="num">' + Util.rp(x.omzet) + '</td><td class="num muted">' + (x.share * 100).toFixed(0) + '%</td></tr>').join('') +
      '</tbody></table></div>';
  }

  function perhatian(rugi, mati, modalMati) {
    let h = '';
    if (rugi.length) {
      h += '<div class="alert-strip danger" style="margin-bottom:10px">' + Util.icon('alert') +
        '<span class="grow"><strong>' + rugi.length + ' produk</strong> dijual di bawah modal: ' +
        rugi.slice(0, 3).map(x => Util.esc(x.nama)).join(', ') + '. Naikkan harga atau cek HPP.</span></div>';
    }
    if (mati.length) {
      h += '<div class="alert-strip">' + Util.icon('clock') +
        '<span class="grow"><strong>' + mati.length + ' produk</strong> tidak laku di periode ini. Modal tertahan ' +
        Util.rp(modalMati) + '.</span></div>' +
        '<div class="rank-list mt-3">' + mati.slice(0, 8).map(x =>
          '<div class="rank-item"><span class="rank-name truncate">' + Util.esc(x.nama) + '</span>' +
          '<span class="rank-val muted">' + (x.stok || 0) + ' · ' + Util.rp((Number(x.stok) || 0) * (Number(x.hpp) || 0)) + '</span></div>').join('') + '</div>';
    }
    if (!h) h = '<div class="alert-strip info">' + Util.icon('check') + '<span class="grow">Semua produk bergerak dan margin sehat. 👍</span></div>';
    return h;
  }

  /* ---------------- ekspor ---------------- */
  function eksporExcel() {
    try {
      const [from, to] = rentang();
      const k = Store.kpi(from, to);
      const hari = hariSeries(from, to, k);
      const namaFile = 'Laporan-Sikar-' + Util.dayKey(to) + '.xlsx';

      const ringkas = [
        [XLSX.head('LAPORAN ' + (Store.s.toko.nama || 'TOKO').toUpperCase())],
        [],
        ['Periode', Util.fmtDate(from) + ' — ' + Util.fmtDate(to)],
        ['Dibuat', Util.fmtDateTime(Date.now())],
        [],
        [XLSX.head('Ringkasan'), XLSX.head('Nilai')],
        ['Omzet', XLSX.rp(k.omzet)],
        ['HPP (modal terjual)', XLSX.rp(k.hpp)],
        ['Laba kotor', XLSX.rp(k.laba)],
        ['Margin', XLSX.pct(k.omzet ? k.laba / k.omzet : 0)],
        ['Transaksi', k.trx],
        ['Item terjual', k.item],
        ['Rata-rata / transaksi', XLSX.rp(k.basket)],
        ['Diskon diberikan', XLSX.rp(k.diskon)],
        ['Refund', XLSX.rp(k.refund)],
        ['Pembayaran tunai', XLSX.rp(k.tunai)],
        ['Pembayaran non-tunai', XLSX.rp(k.nonTunai)]
      ];

      const harian = [[XLSX.head('Tanggal'), XLSX.head('Omzet'), XLSX.head('Laba'), XLSX.head('Transaksi')]];
      hari.forEach(d => harian.push([XLSX.date(Util.startOfDay(new Date(d.key.replace(/-/g, '/')).getTime())), XLSX.money(d.v), XLSX.money(d.v2), d.trx]));
      harian.push([XLSX.bold('TOTAL'), XLSX.total(k.omzet), XLSX.total(k.laba), XLSX.bold(k.trx)]);

      const produk = [[XLSX.head('Produk'), XLSX.head('Kategori'), XLSX.head('Qty'), XLSX.head('Omzet'),
        XLSX.head('HPP'), XLSX.head('Laba'), XLSX.head('Margin %')]];
      Util.sortBy(k.margin, x => x.omzet, true).forEach(x => produk.push([
        x.nama, x.kategori, x.qty, XLSX.money(x.omzet), XLSX.money(x.hpp), XLSX.money(x.margin), XLSX.pct(x.marginPct / 100)
      ]));

      const trx = [[XLSX.head('No. Nota'), XLSX.head('Tanggal'), XLSX.head('Jam'), XLSX.head('Kasir'),
        XLSX.head('Item'), XLSX.head('Subtotal'), XLSX.head('Diskon'), XLSX.head('Pajak'),
        XLSX.head('Total'), XLSX.head('Metode'), XLSX.head('Status')]];
      Util.sortBy(k.list, x => x.at, false).forEach(x => trx.push([
        x.no, XLSX.date(x.at), Util.fmtTime(x.at), x.kasir || '',
        Util.sum(x.items, it => it.qty), XLSX.money(x.subtotal), XLSX.money(x.diskon),
        XLSX.money(x.pajak), XLSX.money(x.total),
        (x.bayar || []).map(b => b.metode).join(' + '), x.status
      ]));

      const stok = [[XLSX.head('Produk'), XLSX.head('Kategori'), XLSX.head('Stok'), XLSX.head('Min'),
        XLSX.head('HPP'), XLSX.head('Nilai stok')]];
      Store.s.produk.forEach(p => stok.push([
        p.nama, p.kategori, Number(p.stok) || 0, Number(p.minStok) || 0,
        XLSX.money(p.hpp), XLSX.money((Number(p.stok) || 0) * (Number(p.hpp) || 0))
      ]));

      XLSX.download([
        { name: 'Ringkasan', rows: ringkas, cols: [28, 20, 16, 14], freeze: 0, tab: true },
        { name: 'Harian', rows: harian, cols: [14, 16, 16, 12] },
        { name: 'Produk', rows: produk, cols: [32, 16, 8, 15, 15, 15, 11] },
        { name: 'Transaksi', rows: trx, cols: [20, 13, 8, 14, 8, 14, 12, 12, 14, 16, 12] },
        { name: 'Stok', rows: stok, cols: [32, 16, 9, 9, 14, 16] }
      ], namaFile);
      Util.toast('Excel diunduh: ' + namaFile, 'ok', 3200);
    } catch (e) {
      console.error(e);
      Util.toast('Gagal membuat Excel: ' + (e.message || e), 'err', 5000);
    }
  }

  function cetakRingkas() {
    const [from, to] = rentang();
    const k = Store.kpi(from, to);
    const line = (l, v) => '<div class="struk-line"><span class="nm">' + l + '</span><span class="vl">' + v + '</span></div>';
    let h = '<div class="struk-center struk-toko">' + Util.esc(Store.s.toko.nama) + '</div>' +
      '<div class="struk-center struk-small">RINGKASAN ' + Util.fmtDate(from) + ' — ' + Util.fmtDate(to) + '</div>' +
      '<div class="struk-sep"></div>' +
      line('Omzet', Util.num(k.omzet)) + line('HPP', Util.num(k.hpp)) + line('Laba kotor', Util.num(k.laba)) +
      line('Transaksi', String(k.trx)) + line('Item', String(k.item)) +
      '<div class="struk-sep"></div>' +
      line('Tunai', Util.num(k.tunai)) + line('Non-tunai', Util.num(k.nonTunai)) +
      '<div class="struk-sep"></div>' +
      '<div class="struk-center struk-small">Produk terlaris</div>' +
      k.topOmzet.slice(0, 5).map(x => line(x.nama.slice(0, 20), Util.num(x.omzet))).join('') +
      '<div class="struk-sep"></div>' +
      '<div class="struk-center struk-small">' + Util.fmtDateTime(Date.now()) + '</div>';
    Print.print(h, 80);
  }

  global.Views = global.Views || {};
  global.Views.laporan = mount;
})(window);
