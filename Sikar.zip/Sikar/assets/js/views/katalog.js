/* ============================================================
   views/katalog.js — produk & kategori
   ============================================================ */
(function (global) {
  'use strict';

  let W = null;
  let q = '', cat = 'Semua', sort = 'nama';

  function mount(root) {
    root.innerHTML =
      '<div class="view-anim" id="v-produk">' +
      '<div class="view-head"><div class="vh-text">' +
      '<h1>Produk</h1><p>Harga jual, HPP, dan stok dalam satu tempat. HPP dipakai untuk menghitung laba asli, bukan cuma omzet.</p>' +
      '</div><div class="view-actions">' +
      '<button class="btn" data-act="impor">' + Util.icon('up') + ' Impor</button>' +
      '<button class="btn" data-act="ekspor">' + Util.icon('dl') + ' Ekspor</button>' +
      '<button class="btn btn-primary" data-act="baru">' + Util.icon('plus') + ' Produk baru</button>' +
      '</div></div>' +
      '<div class="grid grid-4" id="p-kpi" style="margin-bottom:16px"></div>' +
      '<div class="card card-flush">' +
      '<div class="card-head" style="gap:10px;flex-wrap:wrap">' +
      '<div class="row grow" style="gap:8px;min-width:220px">' +
      '<div class="search" style="max-width:300px">' + Util.icon('search') +
      '<input id="p-cari" class="input" style="padding-left:38px" placeholder="Cari nama / barcode…"></div>' +
      '<select id="p-cat" class="select" style="width:150px"></select>' +
      '</div>' +
      '<div class="row row-tight"><select id="p-sort" class="select" style="width:150px">' +
      '<option value="nama">Urut: Nama</option><option value="stok">Urut: Stok</option>' +
      '<option value="margin">Urut: Margin</option><option value="harga">Urut: Harga</option></select>' +
      '<span class="badge" id="p-count">0</span></div>' +
      '</div>' +
      '<div class="table-wrap" style="max-height:calc(100dvh - 330px)">' +
      '<table class="tbl"><thead><tr>' +
      '<th>Produk</th><th>Kategori</th><th>Barcode</th><th class="right">Harga</th><th class="right">HPP</th>' +
      '<th class="right">Margin</th><th class="right">Stok</th><th></th>' +
      '</tr></thead><tbody id="p-list"></tbody></table></div></div>' +
      '</div>';
    W = root.querySelector('#v-produk');

    W.querySelector('#p-cari').addEventListener('input', e => { q = e.target.value; renderList(); });
    W.querySelector('#p-cat').addEventListener('change', e => { cat = e.target.value; renderList(); });
    W.querySelector('#p-sort').addEventListener('change', e => { sort = e.target.value; renderList(); });

    W.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      const act = t.dataset.act;
      if (act === 'baru') form(null);
      else if (act === 'edit') form(Store.p(t.dataset.pid));
      else if (act === 'hapus') hapus(t.dataset.pid);
      else if (act === 'impor') impor();
      else if (act === 'ekspor') ekspor();
    });

    renderKpi();
    renderCat();
    renderList();
    return { refresh() { renderKpi(); renderCat(); renderList(); } };
  }

  function renderKpi() {
    const s = Store.s.produk.filter(p => p.aktif !== false);
    const nilai = Util.sum(s, p => (Number(p.stok) || 0) * (Number(p.hpp) || 0));
    const kritis = s.filter(p => Number(p.stok) <= Number(p.minStok || 0)).length;
    const margin = s.length ? Util.sum(s, p => p.harga ? (p.harga - p.hpp) / p.harga : 0) / s.length * 100 : 0;
    W.querySelector('#p-kpi').innerHTML =
      '<div class="kpi"><div class="kpi-label">Produk aktif</div><div class="kpi-value">' + s.length + '</div>' +
      '<div class="kpi-sub">' + Store.kategori().length + ' kategori</div></div>' +
      '<div class="kpi"><div class="kpi-label">Nilai stok (HPP)</div><div class="kpi-value sm">' + Util.rp(nilai) + '</div>' +
      '<div class="kpi-sub">modal yang tertahan di rak</div></div>' +
      '<div class="kpi"><div class="kpi-label">Stok kritis</div><div class="kpi-value">' + kritis + '</div>' +
      '<div class="kpi-sub">di bawah stok minimum</div></div>' +
      '<div class="kpi"><div class="kpi-label">Margin rata-rata</div><div class="kpi-value">' + margin.toFixed(0) + '%</div>' +
      '<div class="kpi-sub">dari harga jual</div></div>';
  }

  function renderCat() {
    const sel = W.querySelector('#p-cat');
    const cats = Store.kategori();
    sel.innerHTML = '<option value="Semua">Semua kategori</option>' +
      cats.map(c => '<option value="' + Util.esc(c) + '"' + (cat === c ? ' selected' : '') + '>' + Util.esc(c) + '</option>').join('');
    if (cat !== 'Semua' && !cats.includes(cat)) cat = 'Semua';
  }

  function renderList() {
    let list = Store.s.produk.slice();
    if (cat !== 'Semua') list = list.filter(p => (p.kategori || 'Lainnya') === cat);
    const qq = q.toLowerCase().trim();
    if (qq) list = list.filter(p => (p.nama + ' ' + (p.barcode || '') + ' ' + (p.kategori || '')).toLowerCase().includes(qq));
    list = Util.sortBy(list, p => {
      if (sort === 'stok') return Number(p.stok) || 0;
      if (sort === 'harga') return Number(p.harga) || 0;
      if (sort === 'margin') return p.harga ? (p.harga - p.hpp) / p.harga : 0;
      return (p.nama || '').toLowerCase();
    }, sort !== 'nama');

    W.querySelector('#p-count').textContent = list.length + ' produk';
    const body = W.querySelector('#p-list');
    if (!list.length) {
      body.innerHTML = '<tr><td colspan="8"><div class="empty">' + Util.icon('box') +
        '<strong>Belum ada produk</strong><p>Tambahkan produk pertama, atau impor dari Excel/CSV.</p>' +
        '<button class="btn btn-primary btn-sm mt-2" data-act="baru">' + Util.icon('plus') + ' Produk baru</button></div></td></tr>';
      return;
    }
    body.innerHTML = list.map(p => {
      const stok = Number(p.stok) || 0;
      const min = Number(p.minStok) || 0;
      const cls = stok <= 0 ? 'out' : stok <= min ? 'low' : '';
      const m = p.harga ? (p.harga - p.hpp) / p.harga * 100 : 0;
      return '<tr>' +
        '<td><div class="prod-cell"><span class="prod-ico ' + cls + '">' + Util.esc((p.nama || '?').slice(0, 2)) + '</span>' +
        '<div style="min-width:0"><div class="truncate strong">' + Util.esc(p.nama) + '</div>' +
        '<div class="tiny muted">' + Util.esc(p.satuan || 'pcs') + (p.aktif === false ? ' · nonaktif' : '') + '</div></div></div></td>' +
        '<td><span class="badge badge-muted">' + Util.esc(p.kategori || 'Lainnya') + '</span></td>' +
        '<td class="mono tiny muted">' + Util.esc(p.barcode || '—') + '</td>' +
        '<td class="num">' + Util.rp(p.harga) + '</td>' +
        '<td class="num muted">' + Util.rp(p.hpp) + '</td>' +
        '<td class="num"><span class="' + (m < 15 ? 'badge badge-warn' : 'badge badge-ok') + '">' + m.toFixed(0) + '%</span></td>' +
        '<td class="num ' + (stok <= min ? 'strong' : '') + '">' + stok + '</td>' +
        '<td class="right nowrap">' +
        '<button class="btn-icon" data-act="edit" data-pid="' + p.id + '" title="Ubah">' + Util.icon('edit') + '</button>' +
        '<button class="btn-icon" data-act="hapus" data-pid="' + p.id + '" title="Hapus">' + Util.icon('trash') + '</button>' +
        '</td></tr>';
    }).join('');
  }

  function form(p) {
    const isNew = !p;
    p = p || { nama: '', kategori: 'Minuman', harga: 0, hpp: 0, stok: 0, minStok: 5, satuan: 'pcs', barcode: '', aktif: true, batch: [] };
    const cats = Store.kategori();
    Util.modal({
      title: isNew ? 'Produk baru' : 'Ubah produk',
      sub: isNew ? 'Isi harga jual dan HPP supaya laporan laba akurat.' : p.nama,
      body:
        '<div class="form-grid">' +
        '<div class="field full"><label class="label">Nama produk <span class="req">*</span></label>' +
        '<input id="f-nama" class="input" value="' + Util.esc(p.nama) + '" placeholder="mis. Kopi Susu Gula Aren" autofocus></div>' +
        '<div class="field"><label class="label">Kategori</label>' +
        '<input id="f-kat" class="input" list="f-kat-list" value="' + Util.esc(p.kategori || '') + '" placeholder="Minuman">' +
        '<datalist id="f-kat-list">' + cats.map(c => '<option value="' + Util.esc(c) + '">').join('') + '</datalist></div>' +
        '<div class="field"><label class="label">Barcode / SKU</label>' +
        '<input id="f-bc" class="input mono" value="' + Util.esc(p.barcode || '') + '" placeholder="bisa dikosongkan"></div>' +
        '<div class="field"><label class="label">Harga jual <span class="req">*</span></label>' +
        '<input id="f-harga" class="input input-money" inputmode="numeric" value="' + (p.harga ? Util.num(p.harga) : '') + '" placeholder="0"></div>' +
        '<div class="field"><label class="label">HPP (modal per unit)</label>' +
        '<input id="f-hpp" class="input input-money" inputmode="numeric" value="' + (p.hpp ? Util.num(p.hpp) : '') + '" placeholder="0">' +
        '<span class="hint">Dipakai untuk hitung laba & nilai stok.</span></div>' +
        '<div class="field"><label class="label">Stok saat ini</label>' +
        '<input id="f-stok" class="input num" inputmode="numeric" value="' + (Number(p.stok) || 0) + '"' + (isNew ? '' : ' readonly') + '>' +
        (isNew ? '' : '<span class="hint">Ubah lewat Stok Masuk / Opname.</span>') + '</div>' +
        '<div class="field"><label class="label">Stok minimum</label>' +
        '<input id="f-min" class="input num" inputmode="numeric" value="' + (Number(p.minStok) || 0) + '"></div>' +
        '<div class="field"><label class="label">Satuan</label>' +
        '<input id="f-sat" class="input" value="' + Util.esc(p.satuan || 'pcs') + '" placeholder="pcs / porsi / botol"></div>' +
        '<div class="field"><label class="label">Status</label>' +
        '<label class="switch"><input type="checkbox" id="f-aktif"' + (p.aktif !== false ? ' checked' : '') + '>' +
        '<span class="switch-track"></span><span class="switch-text">Jual di kasir</span></label></div>' +
        '</div>' +
        '<div class="alert-strip info mt-4" id="f-preview">' + Util.icon('tag') + '<span class="grow">Margin muncul di sini</span></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: isNew ? 'Simpan produk' : 'Simpan perubahan', class: 'btn-primary', icon: 'check',
          onClick: (node, close) => {
            const nama = node.querySelector('#f-nama').value.trim();
            const harga = Util.parseNum(node.querySelector('#f-harga').value);
            if (!nama) { Util.toast('Nama produk wajib diisi', 'err'); return; }
            if (harga <= 0) { Util.toast('Harga jual harus lebih dari 0', 'err'); return; }
            const data = {
              nama,
              kategori: node.querySelector('#f-kat').value.trim() || 'Lainnya',
              barcode: node.querySelector('#f-bc').value.trim(),
              harga,
              hpp: Util.parseNum(node.querySelector('#f-hpp').value),
              minStok: Util.parseNum(node.querySelector('#f-min').value),
              satuan: node.querySelector('#f-sat').value.trim() || 'pcs',
              aktif: node.querySelector('#f-aktif').checked
            };
            if (isNew) {
              const stok = Util.parseNum(node.querySelector('#f-stok').value);
              const baru = Object.assign({
                id: Util.uid('p'), stok: 0, batch: [], dibuat: Date.now()
              }, data);
              Store.s.produk.push(baru);
              if (stok > 0) Store.stokMasuk({ pid: baru.id, qty: stok, hpp: data.hpp, catatan: 'Stok awal' });
              Store.save('produk');
            } else {
              Object.assign(p, data);
              Store.save('produk');
            }
            close();
            Util.toast(isNew ? 'Produk ditambahkan' : 'Produk diperbarui', 'ok');
          }
        }
      ],
      onMount: (node) => {
        ['#f-harga', '#f-hpp'].forEach(sel => Util.moneyInput(node.querySelector(sel), preview));
        function preview() {
          const h = Util.parseNum(node.querySelector('#f-harga').value);
          const c = Util.parseNum(node.querySelector('#f-hpp').value);
          const el = node.querySelector('#f-preview');
          if (!h) { el.querySelector('span').textContent = 'Isi harga jual untuk melihat margin.'; return; }
          const m = h - c;
          el.className = 'alert-strip mt-4 ' + (m <= 0 ? 'danger' : m / h < 0.15 ? '' : 'info');
          el.querySelector('span').innerHTML = 'Laba per unit <strong>' + Util.rp(m) + '</strong> · margin <strong>' +
            (m / h * 100).toFixed(0) + '%</strong>' + (m <= 0 ? ' · harga di bawah modal!' : '');
        }
        preview();
      }
    });
  }

  async function hapus(pid) {
    const p = Store.p(pid);
    if (!p) return;
    const dipakai = Store.s.penjualan.some(x => (x.items || []).some(it => it.pid === pid));
    const yes = await Util.confirm({
      title: 'Hapus ' + p.nama + '?',
      body: dipakai ? 'Produk ini sudah pernah terjual. Riwayat transaksi tetap aman, tapi produk akan dinonaktifkan (tidak muncul di kasir).' : 'Produk akan dihapus dari daftar.',
      ok: dipakai ? 'Nonaktifkan' : 'Hapus', danger: true
    });
    if (!yes) return;
    if (dipakai) { p.aktif = false; }
    else Store.s.produk = Store.s.produk.filter(x => x.id !== pid);
    Store.save('produk');
    Util.toast(dipakai ? 'Produk dinonaktifkan' : 'Produk dihapus', 'ok');
  }

  function impor() {
    const contoh = 'nama;kategori;harga;hpp;stok;barcode\nKopi Susu;Minuman;18000;7000;40;8810004';
    Util.modal({
      title: 'Impor produk',
      sub: 'Tempel data dari Excel/Google Sheets, atau pilih berkas CSV.',
      body:
        '<div class="alert-strip info">' + Util.icon('up') +
        '<span class="grow">Format kolom: <strong>nama; kategori; harga; hpp; stok; barcode</strong> — baris judul boleh ikut, akan dilewati.</span></div>' +
        '<div class="field mt-4"><label class="label">Data</label>' +
        '<textarea id="i-teks" class="textarea mono" style="min-height:170px" placeholder="' + Util.esc(contoh) + '"></textarea></div>' +
        '<div class="row mt-3"><input type="file" id="i-file" accept=".csv,.txt,text/csv" class="input" style="padding-top:7px">' +
        '<button class="btn btn-sm" id="i-contoh">Unduh contoh</button></div>',
      actions: [
        { label: 'Batal', class: 'btn-ghost' },
        {
          label: 'Impor', class: 'btn-primary', icon: 'up', onClick: (node, close) => {
            const teks = node.querySelector('#i-teks').value.trim();
            if (!teks) { Util.toast('Belum ada data', 'err'); return; }
            const rows = parseCSV(teks);
            if (!rows.length) { Util.toast('Format tidak dikenali', 'err'); return; }
            let masuk = 0, update = 0;
            rows.forEach(r => {
              const nama = (r[0] || '').trim();
              if (!nama) return;
              const data = {
                nama,
                kategori: (r[1] || 'Lainnya').trim() || 'Lainnya',
                harga: Util.parseNum(r[2]),
                hpp: Util.parseNum(r[3]),
                stok: Util.parseNum(r[4]),
                barcode: (r[5] || '').trim()
              };
              if (!data.harga) return;
              const ada = Store.s.produk.find(x => x.nama.toLowerCase() === nama.toLowerCase());
              if (ada) {
                ada.kategori = data.kategori; ada.harga = data.harga; ada.hpp = data.hpp;
                if (data.barcode) ada.barcode = data.barcode;
                update++;
              } else {
                const baru = {
                  id: Util.uid('p'), nama, kategori: data.kategori, harga: data.harga,
                  hpp: data.hpp, stok: 0, minStok: 5, satuan: 'pcs', barcode: data.barcode,
                  aktif: true, batch: [], dibuat: Date.now()
                };
                Store.s.produk.push(baru);
                if (data.stok > 0) Store.stokMasuk({ pid: baru.id, qty: data.stok, hpp: data.hpp, catatan: 'Impor' });
                masuk++;
              }
            });
            Store.save('produk');
            close();
            Util.toast(masuk + ' produk baru, ' + update + ' diperbarui', 'ok', 3600);
          }
        }
      ],
      onMount: (node) => {
        node.querySelector('#i-contoh').addEventListener('click', () => {
          Util.downloadText(contoh, 'contoh-produk.csv', 'text/csv;charset=utf-8');
        });
        node.querySelector('#i-file').addEventListener('change', e => {
          const f = e.target.files && e.target.files[0];
          if (!f) return;
          const rd = new FileReader();
          rd.onload = () => { node.querySelector('#i-teks').value = String(rd.result || ''); };
          rd.readAsText(f);
        });
      }
    });
  }

  function parseCSV(text) {
    const lines = text.split(/\r?\n/).filter(l => l.trim());
    const first = lines[0] || '';
    let delim = ';';
    if (first.includes('\t')) delim = '\t';
    else if ((first.match(/,/g) || []).length > (first.match(/;/g) || []).length) delim = ',';
    const out = lines.map(l => l.split(delim).map(c => c.trim().replace(/^"|"$/g, '')));
    if (/nama|produk|product/i.test(out[0][0] || '')) out.shift();
    return out.filter(r => r.length >= 3);
  }

  function ekspor() {
    const rows = [['Nama', 'Kategori', 'Barcode', 'Harga', 'HPP', 'Margin%', 'Stok', 'Min', 'Satuan', 'Aktif']];
    Store.s.produk.forEach(p => rows.push([
      p.nama, p.kategori, p.barcode || '', p.harga, p.hpp,
      p.harga ? Math.round((p.harga - p.hpp) / p.harga * 100) : 0,
      p.stok, p.minStok, p.satuan || '', p.aktif !== false ? 'ya' : 'tidak'
    ]));
    Util.downloadCSV(rows, 'produk-sikar-' + Util.dayKey(Date.now()) + '.csv');
    Util.toast('Daftar produk diekspor', 'ok');
  }

  global.Views = global.Views || {};
  global.Views.produk = mount;
})(window);
