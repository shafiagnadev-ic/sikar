/* ============================================================
   store.js — state, penyimpanan, transaksi, stok, shift, laporan
   ============================================================ */
(function (global) {
  'use strict';

  const KEY = 'sikar.state.v1';
  const CART_KEY = 'sikar.cart.v1';

  const Store = {
    s: null,
    subs: [],
    storageOk: true,
    lastSaved: 0,
    _t: null,
    _chan: null,
    _applying: false,

    /* ---------------- init / persist ---------------- */
    init() {
      let raw = null;
      try { raw = localStorage.getItem(KEY); } catch (e) { Store.storageOk = false; }
      let state = null;
      if (raw) {
        try { state = JSON.parse(raw); } catch (e) { state = null; }
      }
      if (!state || !state.produk || !Array.isArray(state.produk) || state.v !== 1) {
        state = Seed.build(Date.now());
      }
      Store.s = Store.normalize(state);
      Store.persist();
      try {
        Store._chan = new BroadcastChannel('sikar-sync');
        Store._chan.onmessage = (ev) => {
          if (ev.data && ev.data.type === 'sync') {
            Store.reloadFromDisk();
          }
        };
      } catch (e) { Store._chan = null; }

      window.addEventListener('beforeunload', () => Store.flush());
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') Store.flush();
      });
      return Store.s;
    },

    normalize(st) {
      st.toko = Object.assign({
        nama: 'Toko Saya', alamat: '', telp: '', footer: 'Terima kasih',
        pajakOn: false, pajak: 11, serviceOn: false, service: 5, bulatkan: true,
        pin: '1234', kasir: 'Kasir', qris: '', cetak: 80, demo: false
      }, st.toko || {});
      st.produk = (st.produk || []).map(p => Object.assign({
        id: Util.uid('p'), nama: 'Produk', kategori: 'Lainnya', harga: 0, hpp: 0,
        stok: 0, minStok: 0, satuan: 'pcs', barcode: '', aktif: true, batch: [], dibuat: Date.now()
      }, p));
      st.pelanggan = st.pelanggan || [];
      st.penjualan = (st.penjualan || []).map(x => {
        if (x.hpp == null) x.hpp = Util.sum(x.items || [], it => (Number(it.hpp) || 0) * (Number(it.qty) || 0));
        return x;
      });
      st.gerakanStok = st.gerakanStok || [];
      st.shift = st.shift || [];
      st.tahan = st.tahan || [];
      st.riwayatPiutang = st.riwayatPiutang || [];
      st.counter = st.counter || { nota: 1, trx: 0 };
      return st;
    },

    persist() {
      if (!Store.storageOk) return;
      try {
        localStorage.setItem(KEY, JSON.stringify(Store.s));
        Store.lastSaved = Date.now();
      } catch (e) {
        Store.storageOk = false;
        Util.toast('Penyimpanan browser penuh — unduh backup sekarang', 'err', 6000);
      }
    },

    save(kind) {
      clearTimeout(Store._t);
      Store._t = setTimeout(() => {
        Store.persist();
        if (Store._chan) { try { Store._chan.postMessage({ type: 'sync' }); } catch (e) {} }
      }, 180);
      Store.emit(kind || 'ubah');
    },

    flush() {
      clearTimeout(Store._t);
      Store.persist();
    },

    reloadFromDisk() {
      let raw = null;
      try { raw = localStorage.getItem(KEY); } catch (e) { return; }
      if (!raw) return;
      try {
        const st = JSON.parse(raw);
        if (!st || st.v !== 1) return;
        Store._applying = true;
        Store.s = Store.normalize(st);
        Store.emit('sync');
      } catch (e) {}
      Store._applying = false;
    },

    sub(fn) { Store.subs.push(fn); return () => { Store.subs = Store.subs.filter(f => f !== fn); }; },
    emit(kind) {
      if (Store._applying) return;
      Store.subs.forEach(fn => { try { fn(kind); } catch (e) { console.error(e); } });
    },

    /* ---------------- akses ---------------- */
    p(id) { return Store.s.produk.find(x => x.id === id); },
    pel(id) { return Store.s.pelanggan.find(x => x.id === id); },
    cariProduk(q) {
      q = String(q || '').toLowerCase().trim();
      const list = Store.s.produk.filter(p => p.aktif !== false);
      if (!q) return list;
      const exact = list.find(p => String(p.barcode || '') === q || String(p.sku || '').toLowerCase() === q);
      if (exact) return [exact];
      return list.filter(p => (p.nama + ' ' + p.kategori + ' ' + (p.barcode || '')).toLowerCase().includes(q));
    },
    kategori() {
      const set = {};
      Store.s.produk.forEach(p => { if (p.aktif !== false) set[p.kategori || 'Lainnya'] = (set[p.kategori || 'Lainnya'] || 0) + 1; });
      return Object.keys(set).sort();
    },
    stokKritis() {
      return Store.s.produk.filter(p => p.aktif !== false && Number(p.stok) <= Number(p.minStok));
    },
    stokHabis() {
      return Store.s.produk.filter(p => p.aktif !== false && Number(p.stok) <= 0);
    },
    hampirExp(hari) {
      const batas = Date.now() + (hari || 30) * 86400000;
      const out = [];
      Store.s.produk.forEach(p => (p.batch || []).forEach(b => {
        if (b.qty > 0 && b.exp && b.exp <= batas) out.push({ produk: p, batch: b });
      }));
      return out.sort((a, b) => a.batch.exp - b.batch.exp);
    },

    /* ---------------- hitung keranjang ---------------- */
    hitung(items, opt) {
      const t = Store.s.toko;
      opt = Object.assign({
        diskonTipe: 'nominal', diskonNilai: 0,
        pajakOn: t.pajakOn, pajak: t.pajak,
        serviceOn: t.serviceOn, service: t.service,
        bulatkan: t.bulatkan
      }, opt || {});
      const subtotal = (items || []).reduce((s, it) => s + (Number(it.harga) || 0) * (Number(it.qty) || 0) - (Number(it.diskon) || 0), 0);
      const diskon = opt.diskonTipe === 'persen'
        ? Math.round(subtotal * (Number(opt.diskonNilai) || 0) / 100)
        : Math.min(subtotal, Math.max(0, Number(opt.diskonNilai) || 0));
      const dasar = Math.max(0, subtotal - diskon);
      const service = opt.serviceOn ? Math.round(dasar * (Number(opt.service) || 0) / 100) : 0;
      const pajak = opt.pajakOn ? Math.round((dasar + service) * (Number(opt.pajak) || 0) / 100) : 0;
      const total0 = dasar + service + pajak;
      const pembulatan = opt.bulatkan ? Math.ceil(total0 / 100) * 100 - total0 : 0;
      const total = total0 + pembulatan;
      const hpp = (items || []).reduce((s, it) => s + (Number(it.hpp) || 0) * (Number(it.qty) || 0), 0);
      const qty = (items || []).reduce((s, it) => s + (Number(it.qty) || 0), 0);
      return { subtotal, diskon, service, pajak, total0, pembulatan, total, hpp, qty, laba: total - pajak - hpp };
    },

    /* ---------------- nomor nota ---------------- */
    nextNo(ts) {
      const t = ts || Date.now();
      const ymd = Util.dayKey(t).slice(2).replace(/-/g, '');
      const n = (Store.s.counter.nota || 1);
      return 'SK-' + ymd + '-' + String(n).padStart(4, '0');
    },

    /* ---------------- stok ---------------- */
    _kurangiStok(p, qty, saleId, at) {
      let need = qty;
      if (p.batch && p.batch.length) {
        p.batch.sort((a, b) => (a.exp || Infinity) - (b.exp || Infinity));
        for (const b of p.batch) {
          if (need <= 0) break;
          const take = Math.min(b.qty, need);
          b.qty -= take; need -= take;
        }
        p.batch = p.batch.filter(b => b.qty > 0);
        p.stok = p.batch.reduce((s, b) => s + b.qty, 0) - Math.max(0, need);
      } else {
        p.stok = Number(p.stok || 0) - qty;
      }
      Store._gerak(p, -qty, 'jual', saleId, '', at);
    },

    _tambahStok(p, qty, hpp, exp, tipe, ref, catatan, at) {
      if (p.batch && p.batch.length) {
        const same = exp ? p.batch.find(b => b.exp === exp && b.hpp === hpp) : null;
        if (same) same.qty += qty;
        else p.batch.push({ id: Util.uid('b'), qty, hpp: hpp || p.hpp, exp: exp || null });
        p.stok = p.batch.reduce((s, b) => s + b.qty, 0);
      } else {
        p.stok = Number(p.stok || 0) + qty;
        if (exp) p.batch = [{ id: Util.uid('b'), qty, hpp: hpp || p.hpp, exp }];
      }
      Store._gerak(p, qty, tipe, ref, catatan, at, hpp, exp);
    },

    _gerak(p, qty, tipe, ref, catatan, at, hpp, exp) {
      Store.s.gerakanStok.push({
        id: Util.uid('g'), at: at || Date.now(), pid: p.id, qty,
        tipe, ref: ref || '', catatan: catatan || '',
        hpp: hpp === undefined ? p.hpp : hpp, exp: exp || null,
        saldo: Number(p.stok) || 0
      });
      if (Store.s.gerakanStok.length > 4000) Store.s.gerakanStok.splice(0, 500);
    },

    /* ---------------- jual ---------------- */
    jual(data) {
      const s = Store.s;
      const items = (data.items || []).map(it => {
        const p = Store.p(it.pid);
        return {
          pid: it.pid,
          nama: p ? p.nama : it.nama,
          kategori: p ? p.kategori : (it.kategori || ''),
          qty: Number(it.qty) || 0,
          harga: Number(it.harga) || 0,
          hpp: p ? Number(p.hpp) || 0 : Number(it.hpp) || 0,
          diskon: Number(it.diskon) || 0,
          catatan: it.catatan || ''
        };
      }).filter(it => it.qty > 0);
      if (!items.length) return { ok: false, error: 'Keranjang kosong' };

      const shift = Store.shiftAktif();
      if (!shift) return { ok: false, error: 'Shift kasir belum dibuka' };

      // cek stok
      if (!data.izinkanMinus) {
        const kurang = [];
        items.forEach(it => {
          const p = Store.p(it.pid);
          if (p && Number(p.stok) < it.qty) kurang.push(p.nama + ' (sisa ' + p.stok + ')');
        });
        if (kurang.length) return { ok: false, error: 'Stok tidak cukup: ' + kurang.slice(0, 3).join(', '), kurangStok: true };
      }

      const t = Store.hitung(items, data);
      const bayar = (data.bayar || []).map(b => ({ metode: b.metode, nominal: Math.round(Number(b.nominal) || 0) }));
      const totalBayar = Util.sum(bayar, b => b.nominal);
      if (totalBayar < t.total) return { ok: false, error: 'Pembayaran kurang ' + Util.rp(t.total - totalBayar) };

      const at = Date.now();
      const sale = {
        id: Util.uid('trx'),
        no: Store.nextNo(at),
        at,
        items,
        subtotal: t.subtotal, diskon: t.diskon, diskonKet: data.diskonKet || '',
        diskonTipe: data.diskonTipe || 'nominal', diskonNilai: data.diskonNilai || 0,
        pajak: t.pajak, service: t.service, pembulatan: t.pembulatan, total: t.total,
        hpp: t.hpp,
        bayar,
        kembali: Math.max(0, totalBayar - t.total),
        kasir: data.kasir || s.toko.kasir || 'Kasir',
        shiftId: shift.id,
        pelangganId: data.pelangganId || null,
        status: 'lunas',
        catatan: data.catatan || ''
      };

      items.forEach(it => {
        const p = Store.p(it.pid);
        if (p) Store._kurangiStok(p, it.qty, sale.id, at);
      });

      // pelanggan: poin + bon
      const pel = sale.pelangganId ? Store.pel(sale.pelangganId) : null;
      if (pel) {
        pel.poin = (Number(pel.poin) || 0) + Math.floor(t.total / 10000);
        const bon = bayar.filter(b => b.metode === 'Bon').reduce((a, b) => a + b.nominal, 0);
        if (bon > 0) {
          pel.piutang = (Number(pel.piutang) || 0) + bon;
          s.riwayatPiutang.push({ id: Util.uid('d'), at, pelangganId: pel.id, tipe: 'bon', nominal: bon, ref: sale.no });
        }
      }

      s.penjualan.push(sale);
      s.counter.nota = (s.counter.nota || 1) + 1;
      s.counter.trx = (s.counter.trx || 0) + 1;
      Store.save('jual');
      return { ok: true, sale };
    },

    /* ---------------- void ---------------- */
    voidJual(id, alasan, oleh) {
      const sale = Store.s.penjualan.find(x => x.id === id);
      if (!sale) return { ok: false, error: 'Transaksi tidak ditemukan' };
      if (sale.status === 'void') return { ok: false, error: 'Sudah dibatalkan' };
      const at = Date.now();
      sale.items.forEach(it => {
        const p = Store.p(it.pid);
        if (p) Store._tambahStok(p, it.qty, it.hpp, null, 'void', sale.no, 'Void: ' + (alasan || ''), at);
      });
      sale.status = 'void';
      sale.voidAt = at;
      sale.voidAlasan = alasan || '';
      sale.voidOleh = oleh || '';
      const pel = sale.pelangganId ? Store.pel(sale.pelangganId) : null;
      if (pel) {
        pel.poin = Math.max(0, (Number(pel.poin) || 0) - Math.floor(sale.total / 10000));
        const bon = (sale.bayar || []).filter(b => b.metode === 'Bon').reduce((a, b) => a + b.nominal, 0);
        if (bon > 0) {
          pel.piutang = Math.max(0, (Number(pel.piutang) || 0) - bon);
          Store.s.riwayatPiutang.push({ id: Util.uid('d'), at, pelangganId: pel.id, tipe: 'bayar', nominal: bon, ref: 'VOID ' + sale.no });
        }
      }
      Store.save('void');
      return { ok: true };
    },

    /* ---------------- refund (sebagian / penuh) ---------------- */
    refund(id, qtyMap, alasan) {
      const sale = Store.s.penjualan.find(x => x.id === id);
      if (!sale || sale.status === 'void') return { ok: false, error: 'Transaksi tidak bisa direfund' };
      const at = Date.now();
      const sisa = Store.sisaRefund(sale);
      const items = [];
      sale.items.forEach((it, idx) => {
        const q = Math.min(Number(qtyMap[idx] || 0), sisa[idx] || 0);
        if (q <= 0) return;
        items.push({
          pid: it.pid, nama: it.nama, kategori: it.kategori,
          qty: -q, harga: it.harga, hpp: it.hpp, diskon: 0
        });
        const p = Store.p(it.pid);
        if (p) Store._tambahStok(p, q, it.hpp, null, 'refund', sale.no, 'Refund: ' + (alasan || ''), at);
      });
      if (!items.length) return { ok: false, error: 'Tidak ada item yang dipilih' };

      const totalItem = items.reduce((a, it) => a + it.harga * it.qty, 0);
      const proporsi = sale.subtotal ? totalItem / sale.subtotal : 0;
      const kembali = Math.round(sale.total * proporsi);
      const rec = {
        id: Util.uid('trx'),
        no: 'RF-' + sale.no.replace(/^SK-/, ''),
        at,
        items,
        subtotal: totalItem, diskon: 0, diskonKet: '',
        pajak: -Math.round(sale.pajak * proporsi),
        service: -Math.round(sale.service * proporsi),
        pembulatan: 0,
        total: kembali,
        hpp: items.reduce((a, it) => a + it.hpp * it.qty, 0),
        bayar: [{ metode: 'Refund', nominal: kembali }],
        kembali: 0,
        kasir: sale.kasir,
        shiftId: Store.shiftAktif() ? Store.shiftAktif().id : sale.shiftId,
        pelangganId: sale.pelangganId,
        status: 'refund',
        ref: sale.id,
        catatan: alasan || ''
      };
      sale.refunded = (sale.refunded || []).concat(items.map((it, i) => ({ idx: i, qty: -it.qty })));
      Store._applyRefunded(sale);
      Store.s.penjualan.push(rec);
      Store.save('refund');
      return { ok: true, rec };
    },

    sisaRefund(sale) {
      const out = sale.items.map(it => it.qty);
      (Store.s.penjualan || []).forEach(r => {
        if (r.status === 'refund' && r.ref === sale.id) {
          r.items.forEach(ri => {
            const idx = sale.items.findIndex(x => x.pid === ri.pid);
            if (idx >= 0) out[idx] += ri.qty; // ri.qty negatif
          });
        }
      });
      return out.map(v => Math.max(0, v));
    },

    _applyRefunded(sale) {
      const sisa = Store.sisaRefund(sale);
      sale.status = sisa.every(v => v === 0) ? 'refund' : 'sebagian';
    },

    /* ---------------- stok masuk / opname ---------------- */
    stokMasuk(d) {
      const p = Store.p(d.pid);
      if (!p) return { ok: false, error: 'Produk tidak ada' };
      const qty = Math.round(Number(d.qty) || 0);
      if (qty <= 0) return { ok: false, error: 'Jumlah harus lebih dari 0' };
      const hpp = Math.round(Number(d.hpp) || 0);
      const at = Date.now();
      const stokLama = Math.max(0, Number(p.stok) || 0);
      if (hpp > 0 && stokLama > 0) {
        p.hpp = Math.round((stokLama * (Number(p.hpp) || 0) + qty * hpp) / (stokLama + qty));
      } else if (hpp > 0) {
        p.hpp = hpp;
      }
      Store._tambahStok(p, qty, hpp || p.hpp, d.exp || null, 'masuk', d.ref || 'PO', d.supplier || d.catatan || '', at);
      Store.save('stok');
      return { ok: true, produk: p };
    },

    opname(pid, qtyFisik, alasan) {
      const p = Store.p(pid);
      if (!p) return { ok: false, error: 'Produk tidak ada' };
      const qf = Math.round(Number(qtyFisik) || 0);
      const diff = qf - Number(p.stok || 0);
      if (!diff) return { ok: false, error: 'Stok sudah sama' };
      const at = Date.now();
      if (diff > 0) {
        Store._tambahStok(p, diff, p.hpp, null, 'opname', 'OPN', alasan || '', at);
      } else {
        if (p.batch && p.batch.length) {
          let need = -diff;
          p.batch.sort((a, b) => (a.exp || Infinity) - (b.exp || Infinity));
          for (const b of p.batch) {
            if (need <= 0) break;
            const take = Math.min(b.qty, need); b.qty -= take; need -= take;
          }
          p.batch = p.batch.filter(b => b.qty > 0);
          p.stok = p.batch.reduce((s, b) => s + b.qty, 0) - Math.max(0, need);
        } else {
          p.stok = qf;
        }
        Store._gerak(p, diff, 'opname', 'OPN', alasan || '', at);
      }
      Store.save('stok');
      return { ok: true, diff };
    },

    /* ---------------- shift ---------------- */
    shiftAktif() { return Store.s.shift.find(x => !x.tutup) || null; },
    shiftRiwayat() { return Store.s.shift.filter(x => x.tutup).sort((a, b) => b.buka - a.buka); },

    bukaShift(modalAwal, kasir) {
      if (Store.shiftAktif()) return { ok: false, error: 'Masih ada shift terbuka' };
      const sh = {
        id: Util.uid('sh'), buka: Date.now(), tutup: null,
        modalAwal: Math.round(Number(modalAwal) || 0),
        kasir: kasir || Store.s.toko.kasir || 'Kasir',
        hitung: null, selisih: null, pecahan: null
      };
      Store.s.shift.push(sh);
      Store.save('shift');
      return { ok: true, shift: sh };
    },

    ringkasShift(sh) {
      const list = Store.s.penjualan.filter(x => x.shiftId === sh.id && x.status !== 'void');
      let tunai = 0, nonTunai = 0, omzet = 0, trx = 0, refund = 0;
      list.forEach(x => {
        if (x.status === 'refund') { refund += Math.abs(x.total); return; }
        omzet += x.total;
        trx++;
        (x.bayar || []).forEach(b => {
          if (b.metode === 'Tunai') tunai += b.nominal - (x.kembali || 0);
          else if (b.metode !== 'Bon') nonTunai += b.nominal;
        });
      });
      const harapan = sh.modalAwal + tunai;
      return { tunai, nonTunai, omzet, trx, refund, harapan, jumlah: list.length };
    },

    tutupShift(hitung, pecahan) {
      const sh = Store.shiftAktif();
      if (!sh) return { ok: false, error: 'Tidak ada shift terbuka' };
      const r = Store.ringkasShift(sh);
      sh.tutup = Date.now();
      sh.hitung = Math.round(Number(hitung) || 0);
      sh.pecahan = pecahan || null;
      sh.selisih = sh.hitung - r.harapan;
      sh.ringkas = r;
      Store.save('shift');
      return { ok: true, shift: sh, ringkas: r };
    },

    /* ---------------- pelanggan / piutang ---------------- */
    bayarPiutang(pelangganId, nominal, catatan) {
      const pel = Store.pel(pelangganId);
      if (!pel) return { ok: false, error: 'Pelanggan tidak ada' };
      const n = Math.round(Number(nominal) || 0);
      if (n <= 0) return { ok: false, error: 'Nominal harus lebih dari 0' };
      if (n > pel.piutang) return { ok: false, error: 'Melebihi sisa piutang ' + Util.rp(pel.piutang) };
      pel.piutang -= n;
      Store.s.riwayatPiutang.push({
        id: Util.uid('d'), at: Date.now(), pelangganId,
        tipe: 'bayar', nominal: n, ref: catatan || 'Bayar bon'
      });
      Store.save('pelanggan');
      return { ok: true };
    },

    /* ---------------- laporan ---------------- */
    penjualanRentang(from, to) {
      return Store.s.penjualan.filter(x => x.at >= from && x.at <= to && x.status !== 'void');
    },

    kpi(from, to) {
      const list = Store.penjualanRentang(from, to);
      const hari = {};
      const jam = new Array(24).fill(0);
      const kat = {};
      const metode = {};
      const kasir = {};
      const produk = {};
      let omzet = 0, hpp = 0, trx = 0, item = 0, diskon = 0, refund = 0, tunai = 0, nonTunai = 0;

      list.forEach(x => {
        const isRefund = x.status === 'refund';
        omzet += x.total;
        hpp += x.hpp || 0;
        diskon += x.diskon || 0;
        if (isRefund) refund += Math.abs(x.total);
        else trx++;

        const dk = Util.dayKey(x.at);
        hari[dk] = hari[dk] || { key: dk, omzet: 0, laba: 0, trx: 0, hpp: 0 };
        hari[dk].omzet += x.total;
        hari[dk].hpp += x.hpp || 0;
        hari[dk].laba += x.total - x.pajak - (x.hpp || 0);
        if (!isRefund) hari[dk].trx++;

        jam[new Date(x.at).getHours()] += Math.max(0, x.total);

        (x.bayar || []).forEach(b => {
          metode[b.metode] = (metode[b.metode] || 0) + b.nominal;
          if (b.metode === 'Tunai') tunai += b.nominal - (x.kembali || 0);
          else if (b.metode !== 'Bon' && b.metode !== 'Refund') nonTunai += b.nominal;
        });

        if (!isRefund) kasir[x.kasir || '-'] = (kasir[x.kasir || '-'] || 0) + x.total;

        (x.items || []).forEach(it => {
          item += it.qty;
          const key = it.pid || it.nama;
          produk[key] = produk[key] || {
            pid: it.pid, nama: it.nama, kategori: it.kategori || '',
            qty: 0, omzet: 0, hpp: 0
          };
          produk[key].qty += it.qty;
          produk[key].omzet += it.harga * it.qty;
          produk[key].hpp += (it.hpp || 0) * it.qty;
          if (it.qty > 0) kat[it.kategori || 'Lainnya'] = (kat[it.kategori || 'Lainnya'] || 0) + it.harga * it.qty - (it.diskon || 0);
        });
      });

      const laba = omzet - list.reduce((s, x) => s + (x.pajak || 0), 0) - hpp;
      const produkArr = Object.values(produk);
      const topOmzet = Util.sortBy(produkArr, x => x.omzet, true);
      const topQty = Util.sortBy(produkArr, x => x.qty, true);
      const margin = produkArr.filter(x => x.qty > 0).map(x => ({
        ...x, margin: x.omzet - x.hpp, marginPct: x.omzet ? (x.omzet - x.hpp) / x.omzet * 100 : 0
      }));
      const rugi = margin.filter(x => x.margin < 0).sort((a, b) => a.margin - b.margin);

      // analisis ABC (80% omzet)
      const sorted = Util.sortBy(produkArr.filter(x => x.omzet > 0), x => x.omzet, true);
      let cum = 0;
      const totalOmzetProduk = Util.sum(sorted, x => x.omzet) || 1;
      const abc = sorted.map(x => {
        cum += x.omzet;
        const share = cum / totalOmzetProduk;
        return { ...x, share, kelas: share <= 0.8 ? 'A' : share <= 0.95 ? 'B' : 'C' };
      });

      return {
        list, omzet, laba, hpp, trx, item, diskon, refund, tunai, nonTunai,
        basket: trx ? omzet / trx : 0,
        hari, jam, kat, metode, kasir,
        produk: produkArr, topOmzet, topQty, margin, rugi, abc,
        totalOmzetProduk
      };
    },

    deadStock(hari) {
      const batas = Date.now() - (hari || 30) * 86400000;
      const laku = {};
      Store.s.penjualan.forEach(x => {
        if (x.at < batas || x.status === 'void') return;
        (x.items || []).forEach(it => { laku[it.pid] = (laku[it.pid] || 0) + it.qty; });
      });
      return Store.s.produk.filter(p => p.aktif !== false && (Number(p.stok) || 0) > 0 && !laku[p.id]);
    },

    /* ---------------- backup ---------------- */
    backup() {
      return {
        app: 'Sikar', v: 1, exportedAt: new Date().toISOString(),
        state: Store.s
      };
    },
    restore(obj) {
      if (!obj || !obj.state || !Array.isArray(obj.state.produk)) {
        return { ok: false, error: 'Berkas backup tidak dikenali' };
      }
      const st = Store.normalize(obj.state);
      if (st.v !== 1) return { ok: false, error: 'Versi backup tidak cocok' };
      Store.s = st;
      Store.save('restore');
      return { ok: true, jumlah: { produk: st.produk.length, transaksi: st.penjualan.length } };
    },
    resetDemo() {
      Store.s = Store.normalize(Seed.build(Date.now()));
      Store.save('reset');
    },
    resetKosong() {
      const now = Date.now();
      Store.s = Store.normalize({
        v: 1, dibuat: now,
        toko: {
          nama: 'Toko Saya', alamat: '', telp: '', footer: 'Terima kasih sudah berbelanja',
          pajakOn: false, pajak: 11, serviceOn: false, service: 5, bulatkan: true,
          pin: '1234', kasir: 'Kasir', qris: '', cetak: 80, demo: false
        },
        produk: [], pelanggan: [], penjualan: [], gerakanStok: [],
        shift: [], tahan: [], riwayatPiutang: [],
        counter: { nota: 1, trx: 0 }
      });
      Store.save('reset');
    },

    /* ---------------- keranjang tersimpan ---------------- */
    simpanKeranjang(cart) {
      try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch (e) {}
    },
    bacaKeranjang() {
      try {
        const raw = localStorage.getItem(CART_KEY);
        return raw ? JSON.parse(raw) : null;
      } catch (e) { return null; }
    },
    hapusKeranjang() { try { localStorage.removeItem(CART_KEY); } catch (e) {} },

    /* ---------------- tahan / buka tagihan ---------------- */
    tahanBill(data) {
      const b = Object.assign({ id: Util.uid('hold'), at: Date.now() }, data);
      Store.s.tahan.push(b);
      Store.save('tahan');
      return b;
    },
    ambilBill(id) {
      const i = Store.s.tahan.findIndex(x => x.id === id);
      if (i < 0) return null;
      const b = Store.s.tahan[i];
      Store.s.tahan.splice(i, 1);
      Store.save('tahan');
      return b;
    },
    hapusBill(id) {
      Store.s.tahan = Store.s.tahan.filter(x => x.id !== id);
      Store.save('tahan');
    }
  };

  global.Store = Store;
})(window);
