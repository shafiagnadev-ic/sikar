/* ============================================================
   util.js — helper DOM, format, dialog, unduhan
   ============================================================ */
(function (global) {
  'use strict';

  const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  const HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

  const Util = {
    /* ---------- angka & uang ---------- */
    num(n) {
      n = Math.round(Number(n) || 0);
      return n.toLocaleString('id-ID');
    },
    rp(n) {
      n = Math.round(Number(n) || 0);
      const neg = n < 0;
      return (neg ? '-' : '') + 'Rp ' + Math.abs(n).toLocaleString('id-ID');
    },
    rpShort(n) {
      n = Number(n) || 0;
      const a = Math.abs(n);
      if (a >= 1e9) return 'Rp ' + (n / 1e9).toFixed(a >= 1e10 ? 0 : 1).replace('.', ',') + ' M';
      if (a >= 1e6) return 'Rp ' + (n / 1e6).toFixed(a >= 1e7 ? 0 : 1).replace('.', ',') + ' jt';
      if (a >= 1e3) return 'Rp ' + Math.round(n / 1e3) + ' rb';
      return 'Rp ' + n;
    },
    pct(n, d) {
      const v = (Number(n) || 0) / (Number(d) || 1) * 100;
      return (v >= 100 ? Math.round(v) : v.toFixed(1).replace('.', ',')) + '%';
    },
    /* parse input nominal Indonesia: "25rb", "1,5jt", "1.500", "1500", "12.500,50" */
    parseNum(v) {
      if (typeof v === 'number') return Math.round(v);
      if (v == null) return 0;
      let s = String(v).toLowerCase().trim();
      if (!s) return 0;
      let mult = 1;
      if (/(jt|juta)$/.test(s)) { mult = 1e6; s = s.replace(/(jt|juta)$/, ''); }
      else if (/(rb|ribu|k)$/.test(s)) { mult = 1e3; s = s.replace(/(rb|ribu|k)$/, ''); }
      s = s.replace(/[^0-9,.\-]/g, '');
      if (!s) return 0;
      if (s.includes(',')) {
        const last = s.lastIndexOf(',');
        const tail = s.slice(last + 1);
        if (tail.length <= 2 && mult === 1) {
          s = s.slice(0, last).replace(/\./g, '') + '.' + tail;
          return Math.round(parseFloat(s) * mult);
        }
        s = s.replace(/,/g, '');
      }
      s = s.replace(/\./g, '');
      const n = parseFloat(s);
      return isNaN(n) ? 0 : Math.round(n * mult);
    },
    /* pasang format ribuan langsung pada input (caret dijaga) */
    moneyInput(input, onInput) {
      if (!input) return;
      input.addEventListener('input', () => {
        const raw = input.value;
        if (/[a-zA-Z]/.test(raw) || /,\d{1,2}$/.test(raw)) return; // biarkan singkatan (25rb / 1,5jt)
        const digitsBefore = raw.slice(0, input.selectionStart || 0).replace(/\D/g, '').length;
        const n = Util.parseNum(raw);
        if (!n && raw.replace(/\D/g, '') === '') { input.value = ''; if (onInput) onInput(0); return; }
        input.value = n ? Util.num(n) : '';
        let seen = 0, pos = input.value.length;
        for (let i = 0; i < input.value.length; i++) {
          if (/\d/.test(input.value[i])) seen++;
          if (seen === digitsBefore) { pos = i + 1; break; }
        }
        try { input.setSelectionRange(pos, pos); } catch (e) {}
        if (onInput) onInput(n);
      });
      input.addEventListener('blur', () => {
        const n = Util.parseNum(input.value);
        input.value = n ? Util.num(n) : '';
        if (onInput) onInput(n);
      });
    },

    /* ---------- tanggal ---------- */
    now() { return Date.now(); },
    iso(ts) { return new Date(ts || Date.now()).toISOString(); },
    d(ts) { return new Date(ts); },
    dayKey(ts) {
      const d = new Date(ts);
      return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    },
    startOfDay(ts) { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); },
    endOfDay(ts) { const d = new Date(ts); d.setHours(23, 59, 59, 999); return d.getTime(); },
    addDays(ts, n) { const d = new Date(ts); d.setDate(d.getDate() + n); return d.getTime(); },
    fmtDate(ts) {
      const d = new Date(ts);
      return d.getDate() + ' ' + BULAN[d.getMonth()] + ' ' + d.getFullYear();
    },
    fmtDateFull(ts) {
      const d = new Date(ts);
      return HARI[d.getDay()] + ', ' + d.getDate() + ' ' + BULAN[d.getMonth()] + ' ' + d.getFullYear();
    },
    fmtDateNum(ts) {
      const d = new Date(ts);
      return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
    },
    fmtTime(ts) {
      const d = new Date(ts);
      return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
    },
    fmtDateTime(ts) { return Util.fmtDate(ts) + ' · ' + Util.fmtTime(ts); },
    fmtDur(ms) {
      const m = Math.max(0, Math.round(ms / 60000));
      const h = Math.floor(m / 60);
      return h > 0 ? h + 'j ' + (m % 60) + 'm' : m + 'm';
    },
    rel(ts) {
      const diff = Date.now() - ts;
      if (diff < 60000) return 'baru saja';
      if (diff < 3600000) return Math.floor(diff / 60000) + ' menit lalu';
      if (diff < 86400000) return Math.floor(diff / 3600000) + ' jam lalu';
      if (diff < 604800000) return Math.floor(diff / 86400000) + ' hari lalu';
      return Util.fmtDate(ts);
    },

    /* ---------- DOM ---------- */
    q(sel, root) { return (root || document).querySelector(sel); },
    qa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); },
    esc(s) {
      return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    },
    html(el, str) { if (el) el.innerHTML = str; return el; },
    on(root, type, sel, fn) {
      if (!root) return;
      root.addEventListener(type, function (ev) {
        const t = ev.target.closest(sel);
        if (t && root.contains(t)) fn(ev, t);
      });
    },
    uid(p) { return (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); },
    icon(id, cls) { return '<svg class="ic ' + (cls || '') + '" aria-hidden="true"><use href="#i-' + id + '"/></svg>'; },

    debounce(fn, ms) {
      let t;
      return function () {
        const a = arguments, c = this;
        clearTimeout(t);
        t = setTimeout(() => fn.apply(c, a), ms || 200);
      };
    },
    clamp(n, a, b) { return Math.min(b, Math.max(a, n)); },
    sum(arr, fn) { return (arr || []).reduce((s, x) => s + (fn ? fn(x) : x), 0); },
    groupBy(arr, fn) {
      const out = {};
      (arr || []).forEach(x => { const k = fn(x); (out[k] = out[k] || []).push(x); });
      return out;
    },
    sortBy(arr, fn, desc) {
      return (arr || []).slice().sort((a, b) => {
        const va = fn(a), vb = fn(b);
        if (va === vb) return 0;
        return (va < vb ? -1 : 1) * (desc ? -1 : 1);
      });
    },
    bytes(n) {
      if (n < 1024) return n + ' B';
      if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
      return (n / 1048576).toFixed(1) + ' MB';
    },

    /* ---------- toast ---------- */
    toast(msg, type, ms) {
      const root = document.getElementById('toast-root');
      if (!root) return;
      const el = document.createElement('div');
      el.className = 'toast toast-' + (type || 'ok');
      const ic = type === 'err' ? 'x' : type === 'warn' ? 'alert' : 'check';
      el.innerHTML = Util.icon(ic) + '<span>' + Util.esc(msg) + '</span>';
      root.appendChild(el);
      const kill = () => { el.classList.add('is-out'); setTimeout(() => el.remove(), 220); };
      setTimeout(kill, ms || 2600);
      el.addEventListener('click', kill);
    },

    /* ---------- overlay / modal ---------- */
    _layers: [],
    openLayer(node, opts) {
      opts = opts || {};
      const root = document.getElementById('overlay-root');
      const scrim = document.createElement('div');
      scrim.className = 'scrim';
      root.appendChild(scrim);
      root.appendChild(node);
      const layer = { node, scrim, onClose: opts.onClose };
      Util._layers.push(layer);
      const close = () => Util.closeLayer(layer);
      scrim.addEventListener('click', () => { if (!opts.noScrimClose) close(); });
      node.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { e.stopPropagation(); close(); }
        if (e.key === 'Tab') {
          const f = Util.qa('a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex]:not([tabindex="-1"])', node)
            .filter(x => x.offsetParent !== null);
          if (!f.length) return;
          const first = f[0], last = f[f.length - 1];
          if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
          else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
      });
      Util._focusGuard(true);
      const focusable = Util.qa('input,select,textarea,button', node).filter(x => x.offsetParent !== null);
      const auto = node.querySelector('[autofocus]') || focusable[0];
      if (auto) setTimeout(() => { try { auto.focus(); if (auto.select && auto.tagName === 'INPUT') auto.select(); } catch (e) {} }, 30);
      return { close, node, layer };
    },
    closeLayer(layer) {
      const i = Util._layers.indexOf(layer);
      if (i < 0) return;
      Util._layers.splice(i, 1);
      layer.node.remove();
      layer.scrim.remove();
      if (!Util._layers.length) Util._focusGuard(false);
      if (layer.onClose) layer.onClose();
    },
    closeTop() { const l = Util._layers[Util._layers.length - 1]; if (l) Util.closeLayer(l); },
    _guardBound: false,
    _focusGuard(on) {
      if (on && !Util._guardBound) {
        Util._guardBound = true;
        document.addEventListener('focusin', Util._guardFocus, true);
      } else if (!on && Util._guardBound) {
        Util._guardBound = false;
        document.removeEventListener('focusin', Util._guardFocus, true);
      }
    },
    _guardFocus(e) {
      const top = Util._layers[Util._layers.length - 1];
      if (!top) return;
      if (!top.node.contains(e.target)) {
        const f = top.node.querySelector('input,select,textarea,button');
        if (f) f.focus();
      }
    },
    modal(opts) {
      const node = document.createElement('div');
      node.className = 'modal ' + (opts.wide ? 'modal-wide' : opts.narrow ? 'modal-narrow' : '');
      node.setAttribute('role', 'dialog');
      node.setAttribute('aria-modal', 'true');
      node.setAttribute('aria-label', opts.title || 'Dialog');
      const actions = (opts.actions || []).map((a, i) =>
        '<button class="btn ' + (a.class || '') + '" data-idx="' + i + '"' + (a.disabled ? ' disabled' : '') + '>' +
        (a.icon ? Util.icon(a.icon) : '') + Util.esc(a.label) + '</button>').join('');
      node.innerHTML =
        '<div class="modal-head"><div><h2>' + Util.esc(opts.title || '') + '</h2>' +
        (opts.sub ? '<p>' + Util.esc(opts.sub) + '</p>' : '') + '</div>' +
        '<button class="btn-icon" data-x aria-label="Tutup">' + Util.icon('x') + '</button></div>' +
        '<div class="modal-body">' + (opts.body || '') + '</div>' +
        (actions ? '<div class="modal-foot">' + (opts.footLeft || '') + actions + '</div>' : '');
      const h = Util.openLayer(node, { onClose: opts.onClose, noScrimClose: opts.noScrimClose });
      node.querySelector('[data-x]').addEventListener('click', h.close);
      node.querySelectorAll('[data-idx]').forEach(btn => {
        btn.addEventListener('click', () => {
          const a = opts.actions[Number(btn.dataset.idx)];
          if (a && a.onClick) a.onClick(node, h.close);
          else if (a && a.close !== false) h.close();
        });
      });
      if (opts.onMount) setTimeout(() => opts.onMount(node, h.close), 0);
      return h;
    },
    confirm(opts) {
      return new Promise(resolve => {
        let done = false;
        const h = Util.modal({
          title: opts.title || 'Konfirmasi',
          sub: opts.sub || '',
          narrow: true,
          body: '<p class="dim small" style="margin-bottom:4px">' + Util.esc(opts.body || '') + '</p>',
          actions: [
            { label: opts.cancel || 'Batal', class: 'btn-ghost', onClick: (n, close) => { done = true; close(); resolve(false); } },
            { label: opts.ok || 'Lanjut', class: opts.danger ? 'btn-danger' : 'btn-primary', onClick: (n, close) => { done = true; close(); resolve(true); } }
          ],
          onClose: () => { if (!done) resolve(false); }
        });
        setTimeout(() => { const b = h.node.querySelectorAll('.modal-foot .btn'); if (b[1]) b[1].focus(); }, 40);
      });
    },
    /* PIN pemilik — dipakai untuk void, refund, ubah harga, buka pengaturan */
    pin(opts) {
      opts = opts || {};
      return new Promise(resolve => {
        let done = false;
        const h = Util.modal({
          title: opts.title || 'PIN pemilik',
          sub: opts.sub || 'Tindakan ini butuh izin pemilik.',
          narrow: true,
          body:
            '<div class="field"><label class="label" for="pin-in">PIN 4 digit</label>' +
            '<input id="pin-in" class="input input-lg mono" inputmode="numeric" maxlength="4" autocomplete="off" autofocus placeholder="••••" style="letter-spacing:.5em;text-align:center">' +
            '<span class="hint">PIN bawaan: 1234 — ganti di Pengaturan.</span></div>',
          actions: [
            { label: 'Batal', class: 'btn-ghost', onClick: (n, close) => { done = true; close(); resolve(false); } },
            { label: 'Buka', class: 'btn-primary', icon: 'lock', onClick: (n, close) => submit(n, close) }
          ],
          onMount: (node, close) => {
            const inp = node.querySelector('#pin-in');
            inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); submit(node, close); } });
            setTimeout(() => inp.focus(), 60);
          },
          onClose: () => { if (!done) resolve(false); }
        });
        function submit(node, close) {
          const inp = node.querySelector('#pin-in');
          const val = (inp.value || '').trim();
          if (val === String(Store.s.toko.pin || '1234')) { done = true; close(); resolve(true); }
          else {
            inp.value = '';
            inp.focus();
            node.animate(
              [{ transform: 'translateX(0)' }, { transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }, { transform: 'translateX(0)' }],
              { duration: 220 });
            Util.toast('PIN salah', 'err');
          }
        }
      });
    },

    /* ---------- unduhan ---------- */
    download(blob, filename) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1500);
    },
    downloadText(text, filename, mime) {
      Util.download(new Blob([text], { type: mime || 'text/plain;charset=utf-8' }), filename);
    },
    downloadJSON(obj, filename) {
      Util.downloadText(JSON.stringify(obj, null, 2), filename, 'application/json');
    },
    downloadCSV(rows, filename) {
      const csv = rows.map(r => r.map(c => {
        const s = c == null ? '' : String(c);
        return /[",;\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      }).join(';')).join('\r\n');
      Util.downloadText('\ufeff' + csv, filename, 'text/csv;charset=utf-8');
    },
    copy(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text).catch(() => Util._copyFallback(text));
      }
      return Promise.resolve(Util._copyFallback(text));
    },
    _copyFallback(text) {
      const ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove();
    },
    shareText(text, title) {
      if (navigator.share) return navigator.share({ text, title }).catch(() => {});
      return Util.copy(text).then(() => Util.toast('Teks disalin', 'ok'));
    },
    fullscreen() {
      if (!document.fullscreenElement) {
        (document.documentElement.requestFullscreen || (() => {})).call(document.documentElement).catch(() => {});
      } else if (document.exitFullscreen) document.exitFullscreen();
    }
  };

  global.Util = Util;
})(window);
