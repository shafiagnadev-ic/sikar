/* ============================================================
   print.js — struk (58/80mm), teks WhatsApp, Z-report, ESC/POS
   ============================================================ */
(function (global) {
  'use strict';

  const Print = {
    width(sale) {
      const w = Number(Store.s.toko.cetak) || 80;
      return w === 58 ? 58 : 80;
    },

    /* ---------------- HTML struk ---------------- */
    receiptDoc(sale, opts) {
      opts = opts || {};
      const t = Store.s.toko;
      const pel = sale.pelangganId ? Store.pel(sale.pelangganId) : null;
      const line = (l, r, cls) =>
        '<div class="struk-line ' + (cls || '') + '"><span class="nm">' + l + '</span><span class="vl">' + r + '</span></div>';
      let h = '';
      h += '<div class="struk-center struk-toko">' + Util.esc(t.nama || 'Toko') + '</div>';
      if (t.alamat) h += '<div class="struk-center struk-small">' + Util.esc(t.alamat) + '</div>';
      if (t.telp) h += '<div class="struk-center struk-small">' + Util.esc(t.telp) + '</div>';
      h += '<div class="struk-sep"></div>';
      h += line('No. ' + Util.esc(sale.no), '');
      h += line(Util.fmtDateNum(sale.at) + ' ' + Util.fmtTime(sale.at), Util.esc(sale.kasir || ''));
      if (pel) h += line('Pelanggan', Util.esc(pel.nama));
      h += '<div class="struk-sep"></div>';

      (sale.items || []).forEach(it => {
        const nama = Util.esc(it.nama);
        const qty = it.qty < 0 ? it.qty : it.qty;
        h += '<div class="struk-item">' +
          '<div class="struk-line"><span class="nm">' + nama + '</span><span class="vl">' + Util.num(it.harga * it.qty) + '</span></div>' +
          '<div class="struk-line struk-sub"><span class="nm">' + qty + ' x ' + Util.num(it.harga) +
          (it.diskon ? ' − ' + Util.num(it.diskon) : '') + '</span><span class="vl"></span></div>' +
          '</div>';
      });

      h += '<div class="struk-sep"></div>';
      h += line('Subtotal', Util.num(sale.subtotal));
      if (sale.diskon) h += line('Diskon' + (sale.diskonKet ? ' (' + Util.esc(sale.diskonKet) + ')' : ''), '−' + Util.num(sale.diskon));
      if (sale.service) h += line('Service ' + Store.s.toko.service + '%', Util.num(sale.service));
      if (sale.pajak) h += line('Pajak ' + Store.s.toko.pajak + '%', Util.num(sale.pajak));
      if (sale.pembulatan) h += line('Pembulatan', Util.num(sale.pembulatan));
      h += '<div class="struk-sep"></div>';
      h += '<div class="struk-line struk-total"><span class="nm">TOTAL</span><span class="vl">' + Util.rp(sale.total) + '</span></div>';
      (sale.bayar || []).forEach(b => { h += line(Util.esc(b.metode), Util.num(b.nominal)); });
      if (sale.kembali) h += line('Kembali', Util.num(sale.kembali));
      if (pel) h += line('Poin', String(pel.poin || 0));
      h += '<div class="struk-sep"></div>';

      if (opts.qris && t.qris) {
        h += '<div class="struk-qr"><img src="' + t.qris + '" alt="QRIS"></div>' +
          '<div class="struk-center struk-small">Scan QRIS untuk bayar</div>';
      }
      if (t.footer) h += '<div class="struk-center struk-small">' + Util.esc(t.footer) + '</div>';
      h += '<div class="struk-bc">' + Util.esc(String(sale.no).replace(/[^A-Za-z0-9]/g, '')) + '</div>';
      return h;
    },

    /* ---------------- teks (WhatsApp) ---------------- */
    text(sale) {
      const t = Store.s.toko;
      const W = 32;
      const line = (l, r) => {
        const pad = Math.max(1, W - l.length - String(r).length);
        return l + ' '.repeat(pad) + r;
      };
      const center = s => {
        const pad = Math.max(0, Math.floor((W - s.length) / 2));
        return ' '.repeat(pad) + s;
      };
      let out = [];
      out.push(center(t.nama || 'Toko'));
      if (t.alamat) out.push(center(t.alamat));
      if (t.telp) out.push(center(t.telp));
      out.push('-'.repeat(W));
      out.push(line('No ' + sale.no, ''));
      out.push(line(Util.fmtDateNum(sale.at) + ' ' + Util.fmtTime(sale.at), sale.kasir || ''));
      out.push('-'.repeat(W));
      (sale.items || []).forEach(it => {
        out.push(it.nama);
        out.push(line('  ' + it.qty + ' x ' + Util.num(it.harga), Util.num(it.harga * it.qty)));
      });
      out.push('-'.repeat(W));
      out.push(line('Subtotal', Util.num(sale.subtotal)));
      if (sale.diskon) out.push(line('Diskon', '-' + Util.num(sale.diskon)));
      if (sale.pajak) out.push(line('Pajak', Util.num(sale.pajak)));
      if (sale.service) out.push(line('Service', Util.num(sale.service)));
      if (sale.pembulatan) out.push(line('Pembulatan', Util.num(sale.pembulatan)));
      out.push(line('TOTAL', Util.rp(sale.total)));
      (sale.bayar || []).forEach(b => out.push(line(b.metode, Util.num(b.nominal))));
      if (sale.kembali) out.push(line('Kembali', Util.num(sale.kembali)));
      out.push('-'.repeat(W));
      if (t.footer) out.push(center(t.footer));
      out.push(center('Terima kasih'));
      return out.join('\n');
    },

    /* ---------------- cetak lewat browser ---------------- */
    print(html, widthMm) {
      const root = document.getElementById('cetak');
      const mm = widthMm || 80;
      root.innerHTML = '<div class="print-doc" style="width:' + mm + 'mm">' + html + '</div>';
      let st = document.getElementById('print-style');
      if (!st) {
        st = document.createElement('style');
        st.id = 'print-style';
        document.head.appendChild(st);
      }
      st.textContent =
        '@page{size:' + mm + 'mm auto;margin:2mm}' +
        '.print-doc{font-family:ui-monospace,Consolas,monospace;font-size:11px;line-height:1.45;color:#000;background:#fff}' +
        '.print-doc .struk-line{display:flex;justify-content:space-between;gap:6px}' +
        '.print-doc .struk-line .nm{flex:1 1 auto;word-break:break-word}' +
        '.print-doc .struk-line .vl{white-space:nowrap}' +
        '.print-doc .struk-center{text-align:center}' +
        '.print-doc .struk-toko{font-size:14px;font-weight:700}' +
        '.print-doc .struk-small{font-size:9.5px}' +
        '.print-doc .struk-sep{border-top:1px dashed #000;margin:4px 0}' +
        '.print-doc .struk-total{font-size:12.5px;font-weight:700}' +
        '.print-doc .struk-item{margin-bottom:2px}' +
        '.print-doc .struk-bc{text-align:center;letter-spacing:2px;font-size:12px;margin-top:4px}' +
        '.print-doc .struk-qr{text-align:center;margin:4px 0}' +
        '.print-doc .struk-qr img{width:34mm;height:34mm;object-fit:contain;margin:0 auto}';
      const go = () => {
        try { window.print(); } catch (e) { Util.toast('Cetak gagal: ' + e.message, 'err'); }
      };
      setTimeout(go, 120);
    },

    struk(sale) {
      Print.print(Print.receiptDoc(sale), Print.width(sale));
    },

    zReport(sh) {
      const t = Store.s.toko;
      const r = sh.ringkas || Store.ringkasShift(sh);
      const line = (l, v) => '<div class="struk-line"><span class="nm">' + l + '</span><span class="vl">' + v + '</span></div>';
      let h = '';
      h += '<div class="struk-center struk-toko">' + Util.esc(t.nama) + '</div>';
      h += '<div class="struk-center struk-small">LAPORAN TUTUP KASIR</div>';
      h += '<div class="struk-sep"></div>';
      h += line('Buka', Util.fmtDateTime(sh.buka));
      h += line('Tutup', sh.tutup ? Util.fmtDateTime(sh.tutup) : '-');
      h += line('Kasir', Util.esc(sh.kasir || '-'));
      h += '<div class="struk-sep"></div>';
      h += line('Transaksi', String(r.trx));
      h += line('Omzet', Util.num(r.omzet));
      if (r.refund) h += line('Refund', '-' + Util.num(r.refund));
      h += line('Tunai', Util.num(r.tunai));
      h += line('Non-tunai', Util.num(r.nonTunai));
      h += '<div class="struk-sep"></div>';
      h += line('Modal awal', Util.num(sh.modalAwal));
      h += line('Kas seharusnya', Util.num(r.harapan));
      h += line('Kas dihitung', Util.num(sh.hitung || 0));
      h += '<div class="struk-sep"></div>';
      h += line('Selisih', Util.num(sh.selisih || 0));
      h += '<div class="struk-sep"></div>';
      h += '<div class="struk-center struk-small">' + Util.fmtDateTime(Date.now()) + '</div>';
      return h;
    },

    /* ---------------- ESC/POS (printer thermal USB) ---------------- */
    escpos(sale, widthMm) {
      const W = (widthMm || 80) === 58 ? 32 : 48;
      const out = [];
      const push = function () { for (let i = 0; i < arguments.length; i++) out.push(arguments[i]); };
      const ascii = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E\n]/g, '');
      const text = s => { const a = ascii(s); for (let i = 0; i < a.length; i++) out.push(a.charCodeAt(i)); };
      const line = (l, r) => {
        l = ascii(l); r = ascii(String(r));
        const pad = Math.max(1, W - l.length - r.length);
        text(l + ' '.repeat(pad) + r + '\n');
      };
      const center = s => {
        s = ascii(s);
        const pad = Math.max(0, Math.floor((W - s.length) / 2));
        text(' '.repeat(pad) + s + '\n');
      };
      const sep = () => text('-'.repeat(W) + '\n');

      push(0x1B, 0x40);                 // init
      push(0x1B, 0x61, 0x01);           // center
      push(0x1B, 0x45, 0x01);           // bold
      text(Store.s.toko.nama + '\n');
      push(0x1B, 0x45, 0x00);
      if (Store.s.toko.alamat) text(Store.s.toko.alamat + '\n');
      if (Store.s.toko.telp) text(Store.s.toko.telp + '\n');
      push(0x1B, 0x61, 0x00);           // left
      sep();
      line('No', sale.no);
      line('Tgl', Util.fmtDateNum(sale.at) + ' ' + Util.fmtTime(sale.at));
      line('Kasir', sale.kasir || '');
      sep();
      (sale.items || []).forEach(it => {
        text(it.nama + '\n');
        line('  ' + it.qty + ' x ' + Util.num(it.harga), Util.num(it.harga * it.qty));
      });
      sep();
      line('Subtotal', Util.num(sale.subtotal));
      if (sale.diskon) line('Diskon', '-' + Util.num(sale.diskon));
      if (sale.pajak) line('Pajak', Util.num(sale.pajak));
      if (sale.service) line('Service', Util.num(sale.service));
      if (sale.pembulatan) line('Pembulatan', Util.num(sale.pembulatan));
      push(0x1B, 0x45, 0x01);
      line('TOTAL', Util.rp(sale.total));
      push(0x1B, 0x45, 0x00);
      (sale.bayar || []).forEach(b => line(b.metode, Util.num(b.nominal)));
      if (sale.kembali) line('Kembali', Util.num(sale.kembali));
      sep();
      push(0x1B, 0x61, 0x01);
      if (Store.s.toko.footer) text(Store.s.toko.footer + '\n');
      text('\n\n');
      push(0x1D, 0x56, 0x42, 0x00);     // cut
      return new Uint8Array(out);
    },

    async serial(bytes) {
      if (!('serial' in navigator)) {
        throw new Error('Browser ini tidak mendukung Web Serial. Pakai Chrome/Edge di desktop.');
      }
      const port = await navigator.serial.requestPort();
      await port.open({ baudRate: 9600 });
      try {
        const writer = port.writable.getWriter();
        await writer.write(bytes);
        writer.releaseLock();
      } finally {
        try { await port.close(); } catch (e) {}
      }
      return true;
    },

    async printESC(sale) {
      try {
        const bytes = Print.escpos(sale, Print.width(sale));
        await Print.serial(bytes);
        Util.toast('Terkirim ke printer thermal', 'ok');
      } catch (e) {
        Util.toast(e && e.message ? e.message : 'Gagal mencetak', 'err', 5000);
      }
    }
  };

  global.Print = Print;
})(window);
