/* ============================================================
   xlsx.js — penulis .xlsx asli tanpa pustaka (ZIP store + OOXML)
   ============================================================ */
(function (global) {
  'use strict';

  /* ---------- CRC32 ---------- */
  const CRC = (function () {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(buf) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  const enc = new TextEncoder();
  const bytes = s => enc.encode(s);

  function zip(files) {
    const parts = [];
    const central = [];
    let offset = 0;
    files.forEach(f => {
      const name = bytes(f.name);
      const data = f.data;
      const crc = crc32(data);
      const head = new Uint8Array(30 + name.length);
      const dv = new DataView(head.buffer);
      dv.setUint32(0, 0x04034b50, true);
      dv.setUint16(4, 20, true);
      dv.setUint16(6, 0x0800, true);
      dv.setUint16(8, 0, true);
      dv.setUint16(10, 0, true);
      dv.setUint16(12, 0x21, true);
      dv.setUint32(14, crc, true);
      dv.setUint32(18, data.length, true);
      dv.setUint32(22, data.length, true);
      dv.setUint16(26, name.length, true);
      dv.setUint16(28, 0, true);
      head.set(name, 30);
      parts.push(head, data);
      central.push({ name, crc, size: data.length, offset });
      offset += head.length + data.length;
    });

    let cdSize = 0;
    const cds = central.map(c => {
      const b = new Uint8Array(46 + c.name.length);
      const dv = new DataView(b.buffer);
      dv.setUint32(0, 0x02014b50, true);
      dv.setUint16(4, 20, true);
      dv.setUint16(6, 20, true);
      dv.setUint16(8, 0x0800, true);
      dv.setUint16(10, 0, true);
      dv.setUint16(12, 0, true);
      dv.setUint16(14, 0x21, true);
      dv.setUint32(16, c.crc, true);
      dv.setUint32(20, c.size, true);
      dv.setUint32(24, c.size, true);
      dv.setUint16(28, c.name.length, true);
      dv.setUint16(30, 0, true);
      dv.setUint16(32, 0, true);
      dv.setUint16(34, 0, true);
      dv.setUint16(36, 0, true);
      dv.setUint32(38, 0, true);
      dv.setUint32(42, c.offset, true);
      b.set(c.name, 46);
      cdSize += b.length;
      return b;
    });

    const eocd = new Uint8Array(22);
    const ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(4, 0, true);
    ev.setUint16(6, 0, true);
    ev.setUint16(8, files.length, true);
    ev.setUint16(10, files.length, true);
    ev.setUint32(12, cdSize, true);
    ev.setUint32(16, offset, true);
    ev.setUint16(20, 0, true);

    return new Blob(parts.concat(cds, [eocd]), {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
  }

  /* ---------- XML ---------- */
  const xesc = s => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');

  function colName(i) {
    let s = '';
    i = i + 1;
    while (i > 0) {
      const m = (i - 1) % 26;
      s = String.fromCharCode(65 + m) + s;
      i = Math.floor((i - 1) / 26);
    }
    return s;
  }

  function dateSerial(ts) {
    const d = new Date(ts);
    const utc = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds());
    return utc / 86400000 + 25569;
  }

  /* gaya: 0 biasa | 1 header | 2 angka | 3 tanggal | 4 tebal | 5 rupiah | 6 persen | 7 tebal+angka */
  const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="4">
<numFmt numFmtId="164" formatCode="#,##0"/>
<numFmt numFmtId="165" formatCode="dd/mm/yyyy"/>
<numFmt numFmtId="166" formatCode="&quot;Rp&quot;\\ #,##0"/>
<numFmt numFmtId="167" formatCode="0.0%"/>
</numFmts>
<fonts count="3">
<font><sz val="11"/><name val="Calibri"/><color theme="1"/></font>
<font><b/><sz val="11"/><name val="Calibri"/><color rgb="FF0A5B43"/></font>
<font><b/><sz val="11"/><name val="Calibri"/><color theme="1"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE6F4EE"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left/><right/><top/><bottom style="thin"><color rgb="FFB7E0CE"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="8">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="167" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="164" fontId="2" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

  function cellXml(ref, v) {
    if (v === null || v === undefined || v === '') {
      if (v === '') return '';
      return '';
    }
    let style = 0, type = null, val = v;
    if (typeof v === 'object' && !(v instanceof Date)) {
      style = v.s || 0;
      if (v.f) { // formula
        const f = String(v.f).replace(/^=/, '');
        const cached = v.v === undefined ? '' : v.v;
        return '<c r="' + ref + '"' + (style ? ' s="' + style + '"' : '') + '><f>' + xesc(f) + '</f>' +
          (cached === '' ? '' : '<v>' + cached + '</v>') + '</c>';
      }
      val = v.v;
      type = v.t || null;
      if (val === null || val === undefined) return '';
    }
    if (val instanceof Date) { val = dateSerial(val.getTime()); if (!style) style = 3; }
    if (typeof val === 'number' && isFinite(val)) {
      return '<c r="' + ref + '"' + (style ? ' s="' + style + '"' : '') + '><v>' + val + '</v></c>';
    }
    if (typeof val === 'boolean') {
      return '<c r="' + ref + '" t="b"' + (style ? ' s="' + style + '"' : '') + '><v>' + (val ? 1 : 0) + '</v></c>';
    }
    const str = String(val);
    if (str.length > 32000) return '';
    return '<c r="' + ref + '" t="inlineStr"' + (style ? ' s="' + style + '"' : '') + '><is><t xml:space="preserve">' + xesc(str) + '</t></is></c>';
  }

  function sheetXml(sheet) {
    const rows = sheet.rows || [];
    const cols = sheet.cols || [];
    const freeze = sheet.freeze === undefined ? 1 : sheet.freeze;
    let xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
    xml += '<sheetViews><sheetView workbookViewId="0"' + (sheet.tab ? ' tabSelected="1"' : '') + '>' +
      (freeze > 0 ? '<pane ySplit="' + freeze + '" topLeftCell="A' + (freeze + 1) + '" activePane="bottomLeft" state="frozen"/>' : '') +
      '</sheetView></sheetViews>';
    xml += '<sheetFormatPr defaultRowHeight="15"/>';
    if (cols.length) {
      xml += '<cols>' + cols.map((w, i) => '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + (w || 14) + '" customWidth="1"/>').join('') + '</cols>';
    }
    xml += '<sheetData>';
    rows.forEach((row, r) => {
      if (!row) return;
      const cells = [];
      for (let c = 0; c < row.length; c++) {
        const x = cellXml(colName(c) + (r + 1), row[c]);
        if (x) cells.push(x);
      }
      xml += '<row r="' + (r + 1) + '">' + cells.join('') + '</row>';
    });
    xml += '</sheetData></worksheet>';
    return xml;
  }

  const XLSX = {
    /**
     * sheets: [{ name, rows, cols, freeze, tab }]
     * rows: array baris; sel = angka | teks | Date | {v, s, f}
     */
    build(sheets) {
      const names = sheets.map((s, i) => (String(s.name || 'Sheet' + (i + 1)).replace(/[\\\/\?\*\[\]:]/g, ' ').slice(0, 31) || 'Sheet' + (i + 1)));
      const files = [];

      files.push({
        name: '[Content_Types].xml',
        data: bytes('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
          '<Default Extension="xml" ContentType="application/xml"/>' +
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
          sheets.map((s, i) => '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('') +
          '</Types>')
      });

      files.push({
        name: '_rels/.rels',
        data: bytes('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
          '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
          '</Relationships>')
      });

      files.push({
        name: 'xl/workbook.xml',
        data: bytes('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
          '<sheets>' + names.map((n, i) => '<sheet name="' + xesc(n) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>').join('') + '</sheets>' +
          '<calcPr calcId="171027" fullCalcOnLoad="1"/></workbook>')
      });

      files.push({
        name: 'xl/_rels/workbook.xml.rels',
        data: bytes('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
          sheets.map((s, i) => '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>').join('') +
          '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
          '</Relationships>')
      });

      files.push({ name: 'xl/styles.xml', data: bytes(STYLES) });

      sheets.forEach((s, i) => {
        files.push({ name: 'xl/worksheets/sheet' + (i + 1) + '.xml', data: bytes(sheetXml(s)) });
      });

      return zip(files);
    },

    download(sheets, filename) {
      const blob = XLSX.build(sheets);
      Util.download(blob, filename);
      return blob;
    },

    /* pembantu gaya sel */
    head(v) { return { v: v, s: 1 }; },
    money(v) { return { v: Math.round(Number(v) || 0), s: 2 }; },
    rp(v) { return { v: Math.round(Number(v) || 0), s: 5 }; },
    date(ts) { return { v: new Date(ts), s: 3 }; },
    bold(v) { return { v: v, s: 4 }; },
    pct(v) { return { v: Number(v) || 0, s: 6 }; },
    total(v) { return { v: Math.round(Number(v) || 0), s: 7 }; }
  };

  global.XLSX = XLSX;
})(window);
