/* ============================================================
   seed.js — data demo deterministik (PRNG bersemai)
   ============================================================ */
(function (global) {
  'use strict';

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const PRODUK = [
    // nama, kategori, harga, hpp, stok, minStok, satuan, barcode
    ['Es Teh Manis', 'Minuman', 6000, 1800, 140, 20, 'gelas', '8810001'],
    ['Teh Hangat', 'Minuman', 5000, 1500, 140, 20, 'gelas', '8810002'],
    ['Kopi Hitam', 'Minuman', 8000, 2500, 90, 15, 'gelas', '8810003'],
    ['Kopi Susu Gula Aren', 'Minuman', 18000, 7000, 80, 15, 'gelas', '8810004'],
    ['Es Jeruk', 'Minuman', 10000, 3500, 70, 12, 'gelas', '8810005'],
    ['Air Mineral 600ml', 'Minuman', 4000, 2600, 96, 24, 'botol', '8810006'],
    ['Teh Botol', 'Minuman', 5000, 3800, 60, 12, 'botol', '8810007'],
    ['Coca Cola Kaleng', 'Minuman', 6000, 4500, 48, 12, 'kaleng', '8810008'],
    ['Ultra Milk Cokelat', 'Minuman', 7000, 5500, 36, 12, 'kotak', '8810009'],
    ['Pocari Sweat', 'Minuman', 9000, 7500, 24, 8, 'botol', '8810010'],
    ['Good Day Freeze', 'Minuman', 8000, 6500, 30, 10, 'botol', '8810011'],
    ['Susu Jahe Hangat', 'Minuman', 12000, 5000, 40, 8, 'gelas', '8810012'],

    ['Nasi Goreng Sikar', 'Makanan', 25000, 12000, 45, 8, 'porsi', '8820001'],
    ['Mie Goreng Spesial', 'Makanan', 22000, 10000, 40, 8, 'porsi', '8820002'],
    ['Ayam Geprek + Nasi', 'Makanan', 23000, 13000, 35, 8, 'porsi', '8820003'],
    ['Nasi Uduk', 'Makanan', 18000, 9000, 30, 6, 'porsi', '8820004'],
    ['Roti Bakar Cokelat', 'Makanan', 15000, 6000, 28, 6, 'porsi', '8820005'],
    ['Indomie Telur', 'Makanan', 12000, 6000, 50, 10, 'porsi', '8820006'],
    ['Kentang Goreng', 'Makanan', 15000, 6000, 26, 6, 'porsi', '8820007'],
    ['Pisang Goreng (5)', 'Makanan', 10000, 4000, 22, 6, 'porsi', '8820008'],

    ['Chitato Sapi Panggang', 'Snack', 11000, 8500, 34, 10, 'pcs', '8830001'],
    ['Taro Net', 'Snack', 9000, 7000, 28, 10, 'pcs', '8830002'],
    ['Oreo Vanilla', 'Snack', 8000, 6200, 32, 10, 'pcs', '8830003'],
    ['Beng Beng', 'Snack', 3000, 2300, 80, 20, 'pcs', '8830004'],
    ['Kopiko', 'Snack', 2000, 1500, 120, 30, 'pcs', '8830005'],
    ['Silverqueen', 'Snack', 15000, 12000, 18, 6, 'pcs', '8830006'],
    ['Wafer Tango', 'Snack', 5000, 3800, 44, 12, 'pcs', '8830007'],
    ['Kacang Garuda', 'Snack', 8000, 6000, 25, 8, 'pcs', '8830008'],

    ['Beras 5kg', 'Sembako', 68000, 62000, 14, 5, 'karung', '8840001'],
    ['Minyak Goreng 1L', 'Sembako', 18000, 16000, 26, 8, 'botol', '8840002'],
    ['Gula Pasir 1kg', 'Sembako', 16000, 14500, 22, 8, 'kg', '8840003'],
    ['Telur Ayam 1kg', 'Sembako', 30000, 27000, 18, 6, 'kg', '8840004'],
    ['Mi Instan', 'Sembako', 3500, 2900, 60, 20, 'pcs', '8840005'],
    ['Sabun Mandi', 'Sembako', 5000, 3800, 30, 10, 'pcs', '8840006'],
    ['Sampo Sachet', 'Sembako', 1500, 1000, 90, 25, 'pcs', '8840007'],
    ['Kopi Sachet', 'Sembako', 2500, 1800, 75, 20, 'pcs', '8840008'],

    ['Rokok Filter 12', 'Rokok', 25000, 22000, 40, 10, 'bungkus', '8850001'],
    ['Rokok Mild 16', 'Rokok', 32000, 29000, 32, 10, 'bungkus', '8850002'],
    ['Rokok Kretek 12', 'Rokok', 23000, 20500, 28, 10, 'bungkus', '8850003'],

    ['Gas LPG 3kg', 'Lainnya', 22000, 19000, 16, 5, 'tabung', '8860001'],
    ['Isi Ulang Galon', 'Lainnya', 6000, 4000, 40, 10, 'galon', '8860002'],
    ['Tissue Gulung', 'Lainnya', 6000, 4500, 26, 8, 'pcs', '8860003'],
    ['Baterai AA (2)', 'Lainnya', 12000, 9000, 20, 6, 'pak', '8860004']
  ];

  const PELANGGAN = [
    ['Bu Ratna', '0812-1111-2222', 240, 0, 'Langganan kopi pagi'],
    ['Pak Dedi', '0813-3333-4444', 120, 0, 'Sering bon rokok'],
    ['Mas Yoga', '0857-5555-6666', 80, 45000, 'Bon mingguan, bayar Jumat'],
    ['Mbak Sari', '0899-7777-8888', 310, 0, 'Pesan nasi goreng tiap siang'],
    ['Bu Wati', '0821-9999-0000', 45, 0, ''],
    ['Pak Hendra', '0818-2222-3333', 15, 12000, 'Anak sekolah, kadang bon']
  ];

  function build(nowTs) {
    const rand = mulberry32(20261028);
    const now = nowTs || Date.now();
    const pick = arr => arr[Math.floor(rand() * arr.length)];
    const int = (a, b) => a + Math.floor(rand() * (b - a + 1));

    const produk = PRODUK.map((p, i) => {
      const [nama, kategori, harga, hpp, stok, minStok, satuan, barcode] = p;
      const item = {
        id: 'p' + String(i + 1).padStart(3, '0'),
        nama, kategori, harga, hpp, stok, minStok, satuan, barcode,
        aktif: true,
        dibuat: now - (60 - i) * 86400000,
        batch: []
      };
      // batch untuk barang yang bisa kedaluwarsa
      if (['Minuman', 'Snack', 'Makanan'].includes(kategori)) {
        const n = int(1, 3);
        let sisa = stok;
        for (let b = 0; b < n; b++) {
          const qty = b === n - 1 ? sisa : Math.round(sisa * (0.3 + rand() * 0.4));
          sisa -= qty;
          if (qty <= 0) continue;
          item.batch.push({
            id: item.id + '-b' + (b + 1),
            qty,
            hpp: Math.round(hpp * (0.94 + rand() * 0.12)),
            exp: now + (b === 0 ? int(2, 12) : int(20, 150)) * 86400000
          });
        }
        item.stok = item.batch.reduce((s, b) => s + b.qty, 0);
      }
      return item;
    });

    // stok rendah & habis untuk demo peringatan
    const low = ['p010', 'p026', 'p037'];
    low.forEach(id => {
      const p = produk.find(x => x.id === id);
      if (!p) return;
      p.stok = Math.max(1, Math.round(p.minStok * 0.6));
      if (p.batch.length) p.batch[0].qty = p.stok;
    });
    const out = produk.find(x => x.id === 'p019');
    if (out) { out.stok = 0; out.batch = []; }

    const pelanggan = PELANGGAN.map((c, i) => ({
      id: 'c' + String(i + 1).padStart(3, '0'),
      nama: c[0], telp: c[1], poin: c[2], piutang: c[3], catatan: c[4],
      dibuat: now - (90 - i * 7) * 86400000
    }));

    /* ---------- riwayat penjualan 21 hari ---------- */
    const penjualan = [];
    const gerakanStok = [];
    const shift = [];
    const metode = [
      ['Tunai', 0.54], ['QRIS', 0.29], ['Debit', 0.12], ['Transfer', 0.05]
    ];
    function pilihMetode() {
      const r = rand();
      let acc = 0;
      for (const [m, w] of metode) { acc += w; if (r <= acc) return m; }
      return 'Tunai';
    }

    let nota = 1;
    const hari = 21;
    for (let d = hari - 1; d >= 0; d--) {
      const dayStart = new Date(now);
      dayStart.setDate(dayStart.getDate() - d);
      dayStart.setHours(0, 0, 0, 0);
      const dow = dayStart.getDay();
      const weekend = dow === 0 || dow === 6;
      const nTrx = weekend ? int(18, 30) : int(11, 22);
      const shiftId = 's' + Util.dayKey(dayStart.getTime());

      if (d > 0) {
        shift.push({
          id: shiftId,
          buka: dayStart.getTime() + 7.5 * 3600000,
          tutup: dayStart.getTime() + 21.5 * 3600000,
          modalAwal: 200000,
          kasir: dow % 2 === 0 ? 'Agna' : 'Rina',
          hitung: null, selisih: null, pecahan: null,
          demo: true
        });
      }

      for (let t = 0; t < nTrx; t++) {
        // jam sibuk: 11-13, 17-20
        let jam;
        const r = rand();
        if (r < 0.22) jam = int(7, 10);
        else if (r < 0.52) jam = int(11, 13);
        else if (r < 0.72) jam = int(14, 16);
        else jam = int(17, 20);
      const at = dayStart.getTime() + jam * 3600000 + int(0, 59) * 60000 + int(0, 59) * 1000;
      if (at > now - 120000) continue; // jangan buat transaksi di masa depan

      const nItem = rand() < 0.45 ? 1 : rand() < 0.8 ? 2 : int(3, 5);
        const items = [];
        const dipakai = new Set();
        for (let k = 0; k < nItem; k++) {
          const p = pick(produk.filter(x => x.aktif));
          if (dipakai.has(p.id)) continue;
          dipakai.add(p.id);
          const qty = p.harga < 8000 && rand() < 0.4 ? int(2, 3) : 1;
          items.push({
            pid: p.id, nama: p.nama, qty,
            harga: p.harga, hpp: p.hpp, diskon: 0,
            kategori: p.kategori
          });
        }
        if (!items.length) continue;
        const subtotal = items.reduce((s, it) => s + it.harga * it.qty, 0);
        const diskon = rand() < 0.08 ? Math.round(subtotal * 0.1 / 500) * 500 : 0;
        const total = subtotal - diskon;
        const metodeBayar = pilihMetode();
        const bayar = metodeBayar === 'Tunai'
          ? Math.ceil(total / 5000) * 5000
          : total;
        const pel = rand() < 0.18 ? pick(pelanggan) : null;
        penjualan.push({
          id: 'trx' + String(nota).padStart(5, '0'),
          no: 'SK-' + Util.dayKey(at).slice(2).replace(/-/g, '') + '-' + String(nota).padStart(4, '0'),
          at,
          items,
          subtotal, diskon, diskonKet: diskon ? 'Promo 10%' : '',
          pajak: 0, service: 0, pembulatan: 0, total,
          bayar: [{ metode: metodeBayar, nominal: bayar }],
          kembali: bayar - total,
          kasir: dow % 2 === 0 ? 'Agna' : 'Rina',
          shiftId,
          pelangganId: pel ? pel.id : null,
          status: 'lunas',
          catatan: ''
        });
        nota++;

        items.forEach(it => {
          if (d - 6 >= 0) {
            gerakanStok.push({
              id: Util.uid('g'), at, pid: it.pid, qty: -it.qty, tipe: 'jual',
              ref: 'trx' + String(nota - 1).padStart(5, '0'), catatan: '', saldo: null
            });
          }
        });
      }
    }

    // beberapa produk lambat laku (dead stock) — tetap tanpa penjualan
    const stokMasuk = [
      { pid: 'p001', qty: 60, hpp: 1800, hari: 6, expHari: 30, supplier: 'Pasar Induk' },
      { pid: 'p013', qty: 20, hpp: 12000, hari: 4, expHari: 14, supplier: 'Dapur' },
      { pid: 'p022', qty: 24, hpp: 7000, hari: 3, expHari: 90, supplier: 'CV Snack Jaya' },
      { pid: 'p030', qty: 10, hpp: 62000, hari: 9, expHari: 240, supplier: 'Toko Beras Makmur' },
      { pid: 'p039', qty: 20, hpp: 22000, hari: 2, expHari: 365, supplier: 'Distributor Rokok' }
    ];
    stokMasuk.forEach(s => {
      gerakanStok.push({
        id: Util.uid('g'), at: now - s.hari * 86400000, pid: s.pid, qty: s.qty,
        tipe: 'masuk', ref: 'PO-' + s.hari, catatan: s.supplier,
        hpp: s.hpp, exp: now + s.expHari * 86400000, saldo: null
      });
    });

    // satu shift aktif hari ini
    const shiftAktif = {
      id: 's' + Util.dayKey(now) + '-aktif',
      buka: Util.startOfDay(now) + 7.5 * 3600000,
      tutup: null,
      modalAwal: 250000,
      kasir: 'Agna',
      hitung: null, selisih: null, pecahan: null,
      demo: true
    };
    // pindahkan transaksi hari ini ke shift aktif
    penjualan.forEach(s => { if (Util.dayKey(s.at) === Util.dayKey(now)) s.shiftId = shiftAktif.id; });
    shift.push(shiftAktif);

    // rapikan saldo kartu stok
    gerakanStok.sort((a, b) => a.at - b.at);

    return {
      v: 1,
      dibuat: now,
      toko: {
        nama: 'Warung Sikar',
        alamat: 'Jl. Melati No. 12, Bandung',
        telp: '0812-3456-7890',
        footer: 'Terima kasih sudah mampir 🙏',
        pajakOn: false, pajak: 11,
        serviceOn: false, service: 5,
        bulatkan: true,
        pin: '1234',
        kasir: 'Agna',
        qris: '',
        cetak: 80,
        demo: true
      },
      produk, pelanggan, penjualan, gerakanStok, shift,
      tahan: [],
      counter: { nota: nota, trx: penjualan.length },
      riwayatPiutang: [
        { id: 'd1', at: now - 5 * 86400000, pelangganId: 'c003', tipe: 'bon', nominal: 45000, ref: 'trx00087' },
        { id: 'd2', at: now - 3 * 86400000, pelangganId: 'c006', tipe: 'bon', nominal: 12000, ref: 'trx00104' }
      ]
    };
  }

  global.Seed = { build, PRODUK, PELANGGAN };
})(window);
