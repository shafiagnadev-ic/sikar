/* ============================================================
   app.js — shell, rute, pintasan keyboard, tema, PWA
   ============================================================ */
(function (global) {
  'use strict';

  const ROUTES = {
    kasir: { judul: 'Kasir', sub: 'Transaksi cepat' },
    transaksi: { judul: 'Transaksi', sub: 'Riwayat & pelanggan' },
    produk: { judul: 'Produk', sub: 'Katalog & harga' },
    stok: { judul: 'Stok', sub: 'Persediaan & kedaluwarsa' },
    laporan: { judul: 'Laporan', sub: 'Laba & performa' },
    shift: { judul: 'Shift kasir', sub: 'Buka & tutup laci' },
    pengaturan: { judul: 'Pengaturan', sub: 'Toko & data' }
  };

  const App = {
    route: 'kasir',
    current: null,
    installPrompt: null,

    boot() {
      Store.init();
      initTheme();
      initChrome();
      initNav();
      initKeys();
      Store.sub(() => App.onStore());
      window.addEventListener('hashchange', () => App.fromHash());
      App.fromHash();
      App.clock();
      setInterval(App.clock, 1000);
      App.onStore();
      setTimeout(() => {
        const boot = document.getElementById('boot');
        const app = document.getElementById('app');
        if (boot) boot.hidden = true;
        if (app) app.hidden = false;
        App.afterPaint();
      }, 60);
      App.pwa();
    },

    afterPaint() {
      const v = document.getElementById('view');
      if (v) v.focus({ preventScroll: true });
      if (Store.s.toko.demo) {
        setTimeout(() => Util.toast('Data demo aktif — ganti di Pengaturan', 'warn', 4200), 900);
      }
    },

    /* ---------------- rute ---------------- */
    fromHash() {
      const raw = (location.hash || '').replace(/^#\/?/, '').split('?')[0];
      const route = ROUTES[raw] ? raw : 'kasir';
      App.go(route, true);
    },

    go(route, fromHash) {
      if (!ROUTES[route]) route = 'kasir';
      App.route = route;
      if (!fromHash && location.hash !== '#/' + route) {
        history.replaceState(null, '', '#/' + route);
      }
      const view = document.getElementById('view');
      if (!view) return;
      view.dataset.view = route;
      view.innerHTML = '';
      const fn = global.Views && global.Views[route];
      App.current = fn ? fn(view) || null : null;
      view.scrollTop = 0;
      document.querySelectorAll('.nav-item').forEach(b => {
        const on = b.dataset.route === route;
        b.classList.toggle('is-active', on);
        if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
      });
      const tb = document.getElementById('tb-sub');
      if (tb) tb.textContent = ROUTES[route].sub;
      document.title = 'Sikar — ' + ROUTES[route].judul;
      App.tutupRail();
      App.chrome();
    },

    onStore() {
      App.chrome();
      if (App.current && typeof App.current.refresh === 'function') {
        try { App.current.refresh(); } catch (e) { console.error('refresh', e); }
      }
    },

    /* ---------------- chrome ---------------- */
    chrome() {
      const s = Store.s;
      const tb = document.getElementById('tb-toko');
      if (tb) tb.textContent = s.toko.nama || 'Toko';
      const pill = document.getElementById('pill-shift');
      const txt = document.getElementById('pill-shift-text');
      const sh = Store.shiftAktif();
      if (pill && txt) {
        pill.classList.toggle('is-open', !!sh);
        txt.textContent = sh ? 'Kasir buka · ' + sh.kasir : 'Shift belum dibuka';
        pill.title = sh ? 'Shift dibuka ' + Util.fmtTime(sh.buka) : 'Klik untuk membuka kasir';
      }
      const badge = document.getElementById('nav-stok-badge');
      if (badge) {
        const n = Store.stokKritis().length;
        badge.textContent = n;
        badge.hidden = !n;
      }
    },

    clock() {
      const el = document.getElementById('clock');
      if (!el) return;
      const d = new Date();
      el.textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      el.title = Util.fmtDateFull(d.getTime());
    },

    /* ---------------- tema ---------------- */
    theme(mode) {
      let cur = mode || localStorage.getItem('sikar.tema') || 'terang';
      if (mode === 'toggle' || !mode) cur = document.documentElement.dataset.theme === 'gelap' ? 'terang' : 'gelap';
      document.documentElement.dataset.theme = cur;
      try { localStorage.setItem('sikar.tema', cur); } catch (e) {}
      const ic = document.querySelector('#ic-tema use');
      if (ic) ic.setAttribute('href', cur === 'gelap' ? '#i-sun' : '#i-moon');
      document.querySelectorAll('[data-act="tema"]').forEach(b => {
        b.title = cur === 'gelap' ? 'Mode terang' : 'Mode gelap';
      });
    },

    /* ---------------- rail mobile ---------------- */
    bukaRail() {
      const r = document.getElementById('rail');
      if (!r) return;
      r.dataset.open = 'true';
      if (!document.getElementById('rail-scrim')) {
        const sc = document.createElement('div');
        sc.className = 'scrim';
        sc.id = 'rail-scrim';
        sc.style.zIndex = '69';
        sc.addEventListener('click', App.tutupRail);
        document.getElementById('overlay-root').appendChild(sc);
      }
    },
    tutupRail() {
      const r = document.getElementById('rail');
      if (r) r.dataset.open = 'false';
      const sc = document.getElementById('rail-scrim');
      if (sc) sc.remove();
    },

    /* ---------------- panduan ---------------- */
    panduan() {
      const rows = [
        ['F1', 'Ke layar kasir'],
        ['F2', 'Buka pembayaran (di kasir)'],
        ['F3', 'Cari produk / fokus kolom cari'],
        ['F4', 'Tahan pesanan (open bill)'],
        ['Alt + 1…7', 'Pindah menu'],
        ['Enter', 'Tambah produk teratas / selesaikan bayar'],
        ['Esc', 'Tutup dialog'],
        ['Scanner USB', 'Langsung tembak ke halaman kasir']
      ];
      const body =
        '<div class="grid grid-2" style="gap:18px">' +
        '<div><div class="card-title" style="margin-bottom:8px">Pintasan</div>' +
        rows.map(r => '<div class="kbd-row"><span>' + Util.esc(r[1]) + '</span><kbd>' + Util.esc(r[0]) + '</kbd></div>').join('') +
        '<div class="card-title mt-4" style="margin-bottom:8px">Alur harian</div>' +
        '<ol class="small dim" style="padding-left:18px;list-style:decimal;display:flex;flex-direction:column;gap:6px">' +
        '<li><strong>Buka kasir</strong> dengan modal awal (uang kembalian).</li>' +
        '<li>Jual seperti biasa: scan / klik produk, lalu F2 untuk bayar.</li>' +
        '<li>Catat <strong>stok masuk</strong> saat barang datang — HPP ikut menyesuaikan.</li>' +
        '<li>Cek <strong>Laporan</strong> untuk laba, produk mati, dan jam sibuk.</li>' +
        '<li><strong>Tutup kasir</strong>: hitung laci, sistem tampilkan selisih, cetak Z-report.</li></ol></div>' +
        '<div><div class="card-title" style="margin-bottom:8px">Yang bikin Sikar beda</div>' +
        '<ul class="small dim" style="display:flex;flex-direction:column;gap:8px">' +
        '<li>• <strong>Laba asli</strong>, bukan omzet: setiap item membawa HPP.</li>' +
        '<li>• <strong>FEFO</strong> — batch hampir kedaluwarsa otomatis dijual dulu.</li>' +
        '<li>• <strong>Split payment</strong> & bon pelanggan, lengkap dengan poin.</li>' +
        '<li>• <strong>Refund & void</strong> ber-PIN dengan jejak alasan.</li>' +
        '<li>• <strong>Excel asli</strong> 5 sheet tanpa internet, tanpa langganan.</li>' +
        '<li>• <strong>Offline penuh</strong>: data di perangkat, tidak butuh server.</li></ul>' +
        '<div class="alert-strip info mt-4">' + Util.icon('help') +
        '<span class="grow">Butuh bantuan? Semua data bisa di-backup dari Pengaturan → Data.</span></div>' +
        '</div></div>';
      Util.modal({ title: 'Panduan Sikar', sub: 'Semua yang perlu kamu tahu dalam satu layar.', body, wide: true, actions: [{ label: 'Mengerti', class: 'btn-primary' }] });
    },

    /* ---------------- PWA ---------------- */
    pwa() {
      if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
        navigator.serviceWorker.register('sw.js').catch(() => {});
      }
      window.addEventListener('beforeinstallprompt', e => {
        e.preventDefault();
        App.installPrompt = e;
      });
    },

    install() {
      if (App.installPrompt) {
        App.installPrompt.prompt();
        App.installPrompt = null;
      } else {
        Util.toast('Buka menu browser → "Install app" / "Tambahkan ke layar utama"', 'warn', 5000);
      }
    }
  };

  function initTheme() {
    let tema = 'terang';
    try { tema = localStorage.getItem('sikar.tema') || 'terang'; } catch (e) {}
    document.documentElement.dataset.theme = tema === 'gelap' ? 'gelap' : 'terang';
    const ic = document.querySelector('#ic-tema use');
    if (ic) ic.setAttribute('href', tema === 'gelap' ? '#i-sun' : '#i-moon');
  }

  function initChrome() {
    document.addEventListener('click', e => {
      const t = e.target.closest('[data-act]');
      if (!t) return;
      const act = t.dataset.act;
      if (act === 'tema') App.theme('toggle');
      else if (act === 'panduan') App.panduan();
      else if (act === 'menu') App.bukaRail();
      else if (act === 'ke-shift') App.go('shift');
    });
  }

  function initNav() {
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => App.go(btn.dataset.route));
    });
  }

  function initKeys() {
    document.addEventListener('keydown', e => {
      const tag = (e.target.tagName || '').toLowerCase();
      const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
      if (e.altKey && /^[1-7]$/.test(e.key)) {
        e.preventDefault();
        App.go(Object.keys(ROUTES)[Number(e.key) - 1]);
        return;
      }
      if (e.key === 'F1') { e.preventDefault(); App.go('kasir'); return; }
      if (e.key === 'F2') { e.preventDefault(); if (App.route === 'kasir' && App.current && App.current.bayar) App.current.bayar(); return; }
      if (e.key === 'F3') {
        e.preventDefault();
        if (App.route !== 'kasir') App.go('kasir');
        setTimeout(() => { if (App.current && App.current.focusCari) App.current.focusCari(); }, 40);
        return;
      }
      if (e.key === 'F4') { e.preventDefault(); if (App.route === 'kasir' && App.current && App.current.tahan) App.current.tahan(); return; }
      if (e.key === 'F5') { e.preventDefault(); return; }
      if (e.key === 'Escape') {
        if (Util._layers.length) return; // ditangani layer
        const k = document.getElementById('keranjang');
        if (k && k.dataset.open === 'true') { k.dataset.open = 'false'; return; }
        App.tutupRail();
        return;
      }
      if (!typing && (e.key === '?' || (e.shiftKey && e.key === '/'))) { e.preventDefault(); App.panduan(); }
    });
  }

  global.App = App;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', App.boot);
  else App.boot();
})(window);
