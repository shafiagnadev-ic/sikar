/* ============================================================
   scan.js — pemindai barcode kamera + deteksi scanner USB
   ============================================================ */
(function (global) {
  'use strict';

  const Scan = {
    supported() { return 'BarcodeDetector' in window; },

    async open(cb) {
      const has = Scan.supported();
      const h = Util.modal({
        title: 'Scan barcode',
        sub: has ? 'Arahkan kamera ke barcode produk.' : 'Browser ini belum mendukung kamera scan. Ketik kode secara manual.',
        narrow: true,
        body:
          '<div id="scan-box" style="position:relative;border-radius:12px;overflow:hidden;background:#000;aspect-ratio:4/3">' +
          (has ? '<video id="scan-video" playsinline muted style="width:100%;height:100%;object-fit:cover"></video>' +
            '<div style="position:absolute;inset:18% 12%;border:2px solid rgba(255,255,255,.85);border-radius:10px;box-shadow:0 0 0 999px rgba(0,0,0,.25)"></div>' :
            '<div class="center" style="height:100%;color:#8b95a1;font-size:13px;flex-direction:column;gap:8px">' +
            Util.icon('cam', 'ic-lg') + '<span>Kamera tidak tersedia</span></div>') +
          '</div>' +
          '<div class="field mt-4"><label class="label" for="scan-manual">Atau ketik kode / nama produk</label>' +
          '<div class="row"><input id="scan-manual" class="input grow" placeholder="contoh: 8810004" autocomplete="off">' +
          '<button class="btn btn-primary" id="scan-go">Cari</button></div></div>' +
          '<p class="hint mt-2">Scanner USB (barcode gun) juga bisa langsung dipakai: cukup tembak ke halaman kasir.</p>',
        actions: [{ label: 'Tutup', class: 'btn-ghost' }],
        onClose: () => Scan.stop()
      });

      const manual = h.node.querySelector('#scan-manual');
      const go = () => {
        const v = (manual.value || '').trim();
        if (!v) return;
        Scan.stop();
        h.close();
        cb(v);
      };
      h.node.querySelector('#scan-go').addEventListener('click', go);
      manual.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
      setTimeout(() => manual.focus(), 80);

      if (has) {
        try {
          Scan.video = h.node.querySelector('#scan-video');
          Scan.stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment', width: { ideal: 1280 } }
          });
          Scan.video.srcObject = Scan.stream;
          await Scan.video.play();
          Scan.detector = new window.BarcodeDetector({
            formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'upc_e', 'qr_code', 'itf']
          });
          Scan.loop(cb, h.close);
        } catch (e) {
          Util.toast('Kamera tidak bisa dibuka: ' + (e.message || 'izin ditolak'), 'warn', 4200);
        }
      }
    },

    loop(cb, close) {
      const tick = async () => {
        if (!Scan.video || !Scan.detector || Scan.stopped) return;
        try {
          const codes = await Scan.detector.detect(Scan.video);
          if (codes && codes.length) {
            const val = codes[0].rawValue;
            Scan.stop();
            close();
            if (navigator.vibrate) navigator.vibrate(40);
            cb(val);
            return;
          }
        } catch (e) {}
        Scan._raf = requestAnimationFrame(tick);
      };
      Scan._raf = requestAnimationFrame(tick);
    },

    stop() {
      Scan.stopped = true;
      if (Scan._raf) cancelAnimationFrame(Scan._raf);
      if (Scan.stream) { Scan.stream.getTracks().forEach(t => t.stop()); Scan.stream = null; }
      Scan.video = null;
      Scan.detector = null;
    },

    /* deteksi barcode gun: ketikan cepat diakhiri Enter */
    wedge(input, cb) {
      let buf = '';
      let last = 0;
      input.addEventListener('keydown', e => {
        const now = Date.now();
        if (now - last > 120) buf = '';
        last = now;
        if (e.key === 'Enter') {
          if (buf.length >= 5) { e.preventDefault(); cb(buf); buf = ''; }
          return;
        }
        if (e.key.length === 1) buf += e.key;
      });
    }
  };

  global.Scan = Scan;
})(window);
