/* Service worker Sikar — offline penuh setelah kunjungan pertama */
const CACHE = 'sikar-v1';
const ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './assets/css/tokens.css',
  './assets/css/base.css',
  './assets/css/layout.css',
  './assets/css/components.css',
  './assets/css/views.css',
  './assets/js/util.js',
  './assets/js/xlsx.js',
  './assets/js/seed.js',
  './assets/js/store.js',
  './assets/js/print.js',
  './assets/js/scan.js',
  './assets/js/views/kasir.js',
  './assets/js/views/katalog.js',
  './assets/js/views/stok.js',
  './assets/js/views/riwayat.js',
  './assets/js/views/laporan.js',
  './assets/js/views/shift.js',
  './assets/js/views/pengaturan.js',
  './assets/js/app.js',
  './assets/icon.svg'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(
    caches.match(req).then(hit => {
      if (hit) {
        fetch(req).then(res => { if (res && res.ok) caches.open(CACHE).then(c => c.put(req, res.clone())); }).catch(() => {});
        return hit;
      }
      return fetch(req).then(res => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
        return res;
      }).catch(() => caches.match('./index.html'));
    })
  );
});
